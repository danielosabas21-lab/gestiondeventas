from __future__ import annotations

import base64
import hmac
import os
import sys
from http.server import ThreadingHTTPServer

from data_engine import Handler, IMPORT_AVAILABLE, VERSION

IS_HOSTED = bool(os.environ.get("PORT"))
HOST = os.environ.get("HOST", "0.0.0.0" if IS_HOSTED else "127.0.0.1")
PORT = int(os.environ.get("PORT", "8920"))
ACCESS_USER = os.environ.get("EMA_ACCESS_USER", "")
ACCESS_PASSWORD = os.environ.get("EMA_ACCESS_PASSWORD", "")

if IS_HOSTED and (not ACCESS_USER or not ACCESS_PASSWORD):
    raise RuntimeError("Falta configurar EMA_ACCESS_USER y EMA_ACCESS_PASSWORD; el panel no arrancará públicamente sin contraseña.")


class ProtectedHandler(Handler):
    """Protege la interfaz y todas las API con HTTP Basic Auth sobre HTTPS del proveedor."""

    def _authorized(self) -> bool:
        # Render usa este endpoint para health checks; solo devuelve estado técnico mínimo.
        if IS_HOSTED and self.path.split("?", 1)[0] == "/api/health":
            return True
        # En modo local se conserva el funcionamiento original de la app.
        if not IS_HOSTED:
            return True
        value = self.headers.get("Authorization", "")
        scheme, _, encoded = value.partition(" ")
        valid = False
        if scheme.lower() == "basic" and encoded:
            try:
                credentials = base64.b64decode(encoded, validate=True).decode("utf-8")
                user, separator, password = credentials.partition(":")
                valid = bool(separator) and hmac.compare_digest(user, ACCESS_USER) and hmac.compare_digest(password, ACCESS_PASSWORD)
            except (ValueError, UnicodeDecodeError):
                valid = False
        if valid:
            return True
        body = b"Acceso restringido. Ingresa las credenciales asignadas por el administrador.\n"
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="EMA MAYOREO WEB", charset="UTF-8"')
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)
        return False

    def do_GET(self):
        if self._authorized():
            return super().do_GET()

    def do_POST(self):
        if self._authorized():
            return super().do_POST()

    def do_DELETE(self):
        if self._authorized():
            return super().do_DELETE()


class PublicWebServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64


def main() -> int:
    try:
        server = PublicWebServer((HOST, PORT), ProtectedHandler)
    except Exception as exc:
        print(f"No se pudo iniciar EMA MAYOREO WEB: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        return 1
    print(f"EMA MAYOREO WEB v{VERSION} escuchando en {HOST}:{server.server_address[1]}", flush=True)
    print(f"Importación Excel: {'disponible' if IMPORT_AVAILABLE else 'no disponible'}", flush=True)
    print(f"Modo: {'alojado con contraseña' if IS_HOSTED else 'local en esta computadora'}", flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("Cerrando servidor…", flush=True)
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

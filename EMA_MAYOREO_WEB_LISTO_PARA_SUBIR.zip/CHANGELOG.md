# EMA MAYOREO WEB · Cambios de versión

## V64.0.0 · Renovación visual y comparativo mensual

- Rediseño de colores, contenedores, estados, controles, historial, modales, tablas y responsive.
- Nuevo módulo de comparación mensual basado en cifras reales del historial: facturación, preventa, diferencia y cumplimiento.
- Exportación del comparativo completo a CSV con vendedores, rutas, calidad del conjunto y fecha del archivo.
- Clic en una barra para cambiar al mes guardado correspondiente.
- Mejoras de accesibilidad, foco visible, soporte para reducción de movimiento e impresión del comparativo.
- Caché, rutas de recursos y puerto actualizados para separar esta edición de las versiones anteriores.


## V64 · Correcciones reales de gráficas
- Las barras horizontales reservan espacio para mostrar el importe completo y admiten diferencias positivas/negativas con línea cero.
- La vista de columnas ahora define sus propios degradados SVG (antes podían quedar transparentes al cambiar de vista).
- La navegación por ancla al comparativo deja el título y controles debajo del encabezado fijo.
- La importación identifica hojas a partir de su contenido; se comprobó con nombres de hoja modificados.
- Se quitó la restricción del selector que miraba la extensión/nombre; el servidor inspecciona los bytes, las hojas, los encabezados y las fechas reales del libro.
- Actualizados los textos del asistente de importación para no exigir nombres fijos de pestañas.

## Ajuste final de paquete
- Alineación de la identificación HTTP con la versión 64.0.0 en el servidor local.

from __future__ import annotations
import os, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'data'
TARGET = Path(os.environ.get('EMA_DATA_DIR', str(ROOT / 'data'))).expanduser().resolve()
FILES = ('canonical.json', 'audit.json', 'locations.json', 'ventas_consolidado_canonical.csv')

def main() -> int:
    TARGET.mkdir(parents=True, exist_ok=True)
    for name in FILES:
        src, dst = SOURCE / name, TARGET / name
        if not dst.exists() and src.is_file():
            shutil.copy2(src, dst)
    hist = TARGET / 'history'
    hist.mkdir(parents=True, exist_ok=True)
    index = hist / 'index.json'
    if not index.exists():
        seed = SOURCE / 'history' / 'index.json'
        if seed.is_file(): shutil.copy2(seed, index)
        else: index.write_text('{"months": []}\n', encoding='utf-8')
    print(f'Datos inicializados en {TARGET}; no se sobrescribieron datos existentes.', flush=True)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

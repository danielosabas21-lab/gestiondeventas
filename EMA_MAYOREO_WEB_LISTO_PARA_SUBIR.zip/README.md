# EMA MAYOREO WEB — versión para publicar

Aplicación web con interfaz completa, servidor Python, importación de Excel, API e historial. El paquete está preparado para un servicio Python como Render; **GitHub Pages por sí solo no ejecuta el servidor**.

## Publicación
1. Extrae este ZIP y sube todo su contenido a la raíz de tu repositorio GitHub (no subas solo el ZIP si quieres que Render lea `render.yaml`).
2. En Render, crea un **Blueprint** conectado a ese repositorio. Render detectará `render.yaml`.
3. Espera a que el servicio esté `Live`. La URL será la que Render muestre, normalmente `https://ema-mayoreo-web.onrender.com` si ese nombre está disponible.
4. Consulta `EMA_ACCESS_USER` y `EMA_ACCESS_PASSWORD` en las variables de entorno del servicio. La contraseña se genera automáticamente. No la publiques ni la incluyas en GitHub.
5. Prueba con un Excel de prueba antes de importar información real. Reinicia el servicio y confirma que el historial persiste.

## Seguridad y datos
- Este paquete no contiene el Excel original ni la base histórica de ventas.
- Los datos empiezan vacíos; los archivos necesarios se inicializan en el disco persistente `/var/data`.
- Mantén los archivos comerciales reales fuera del repositorio público. Revisa los permisos de acceso y haz copias de seguridad del disco.
- El plan de Render configurado es `starter` para disponer de disco persistente; el servicio de hosting puede generar cargos.

## Archivos principales
- `web/`: interfaz, estilos y recursos.
- `web_server.py`, `data_engine.py`: servidor y lógica de la aplicación.
- `init_persistent_data.py`: inicializa datos vacíos sin sobrescribir archivos existentes.
- `render.yaml`: configuración del servicio y del disco persistente.

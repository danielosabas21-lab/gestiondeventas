'use strict';

/* Presenta el informe de validación local sin interpretar ni ejecutar contenido recibido. */
(() => {
  const panel = document.getElementById('qualityAssistant');
  if (!panel) return;

  const headline = document.getElementById('qualityHeadline');
  const count = document.getElementById('qualityCount');
  const score = document.getElementById('qualityScore');
  const gauge = document.getElementById('qualityGauge');
  const list = document.getElementById('qualityChecks');
  const toggle = document.getElementById('qualityToggle');
  const monthNames = new Intl.DateTimeFormat('es-GT', { month: 'long', year: 'numeric', timeZone: 'UTC' });

  toggle.addEventListener('click', () => {
    const expanded = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!expanded));
    list.hidden = expanded;
    toggle.innerHTML = expanded
      ? 'Ver comprobaciones <span aria-hidden="true">⌄</span>'
      : 'Ocultar comprobaciones <span aria-hidden="true">⌃</span>';
  });

  function describeMonth(value) {
    const match = /^(\d{4})-(\d{2})$/.exec(String(value || ''));
    if (!match) return '';
    const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, 1));
    return monthNames.format(date);
  }

  function render(report, month) {
    const checks = Array.isArray(report?.checks) ? report.checks : [];
    const total = Number.isFinite(Number(report?.checks_total)) ? Number(report.checks_total) : checks.length;
    const passed = Number.isFinite(Number(report?.checks_passed))
      ? Number(report.checks_passed)
      : checks.filter(item => item?.ok).length;
    const normalizedScore = Number.isFinite(Number(report?.score))
      ? Math.max(0, Math.min(100, Math.round(Number(report.score))))
      : null;
    const verified = report?.status === 'verified' && normalizedScore === 100;

    panel.classList.toggle('is-verified', verified);
    panel.classList.toggle('is-review', Boolean(report) && !verified);
    panel.style.setProperty('--quality-score', `${normalizedScore ?? 0}%`);
    score.textContent = normalizedScore === null ? '—' : `${normalizedScore}%`;
    gauge.setAttribute('aria-label', normalizedScore === null
      ? 'Calidad de los datos pendiente'
      : `Calidad de los datos: ${normalizedScore} por ciento`);

    if (!report) {
      headline.textContent = 'No hay una revisión guardada para este periodo.';
      count.textContent = 'Las comprobaciones aparecerán al cargar los datos.';
      toggle.disabled = true;
      toggle.setAttribute('aria-expanded', 'false');
      toggle.innerHTML = 'Ver comprobaciones <span aria-hidden="true">⌄</span>';
      list.hidden = true;
      list.replaceChildren();
      return;
    }

    const label = describeMonth(month);
    const base = typeof report.headline === 'string' ? report.headline : 'Revisión de consistencia completada.';
    headline.textContent = label ? `${base} Periodo: ${label}.` : base;
    count.textContent = `${passed} de ${total} comprobaciones correctas${report.findings?.length ? ` · ${report.findings.length} por revisar` : ''}`;
    toggle.disabled = checks.length === 0;

    const rows = checks.map(check => {
      const item = document.createElement('li');
      item.className = `quality-check${check?.ok ? ' is-ok' : ' is-failed'}`;
      const icon = document.createElement('span');
      icon.className = 'quality-check-icon';
      icon.setAttribute('aria-hidden', 'true');
      icon.textContent = check?.ok ? '✓' : '!';
      const copy = document.createElement('span');
      copy.className = 'quality-check-copy';
      const title = document.createElement('strong');
      title.textContent = typeof check?.title === 'string' ? check.title : 'Comprobación';
      const detail = document.createElement('span');
      detail.textContent = typeof check?.detail === 'string' ? check.detail : 'Sin detalle disponible.';
      copy.append(title, detail);
      item.append(icon, copy);
      return item;
    });
    list.replaceChildren(...rows);

    if (list.hidden) {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.innerHTML = 'Ver comprobaciones <span aria-hidden="true">⌄</span>';
    }

    const previousScore = Number(gauge.dataset.score);
    if (normalizedScore !== null && !window.matchMedia('(prefers-reduced-motion: reduce)').matches
      && gauge.animate && Number.isFinite(previousScore) && previousScore !== normalizedScore) {
      gauge.animate(
        [{ transform: 'scale(.96)' }, { transform: 'scale(1)' }],
        { duration: 360, easing: 'cubic-bezier(.2,.8,.2,1)' }
      );
    }
    if (normalizedScore !== null) gauge.dataset.score = String(normalizedScore);
  }

  window.EmaQualityAssistant = Object.freeze({ render });
})();

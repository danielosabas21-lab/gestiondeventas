'use strict';

/* El escritorio funciona sin CDN; las animaciones usan Web Animations local. */
window.EmaGsapReady = Promise.resolve(false);

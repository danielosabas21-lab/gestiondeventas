'use strict';

const CACHE_NAME = 'ema-mayoreo-static-v64-0-0';
const SHELL = [
  '/',
  '/styles.css',
  '/command-center.css',
  '/premium-overrides.css',
  '/app.js',
  '/monthly-comparison.js',
  '/motion-engine.js',
  '/loaders.js',
  '/quality-assistant.js',
  '/gsap-loader.js',
  '/command-center.js',
  '/manifest.webmanifest',
  '/icon.svg',
  '/ema-logo.jpg',
  '/guatemala-map.svg',
  '/warehouse-silhouette.svg'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('ema-mayoreo-static-') && key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || url.pathname.startsWith('/api/') || !SHELL.includes(url.pathname)) return;

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(response => {
      if (!response.ok) return response;
      return caches.open(CACHE_NAME).then(cache => cache.put('/', response.clone())).then(() => response);
    }).catch(async () => (await caches.match('/')) || Response.error()));
    return;
  }

  event.respondWith(fetch(request).then(response => {
    if (!response.ok || response.type !== 'basic') return response;
    return caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone())).then(() => response);
  }).catch(async () => (await caches.match(request)) || Response.error()));
});



/* EMA MAYOREO 64 · monthly comparison. Local data only; chart views are selectable. */
(() => {
  'use strict';
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const number = value => Number.isFinite(Number(value)) ? Number(value) : 0;
  const fmt = value => new Intl.NumberFormat('es-GT', {minimumFractionDigits:2, maximumFractionDigits:2}).format(number(value));
  const money = value => `Q ${fmt(value)}`;
  const compactMoney = value => `Q ${new Intl.NumberFormat('es-GT', {notation:'compact', maximumFractionDigits:1}).format(number(value))}`;
  const percent = value => `${fmt(value)}%`;
  const monthLong = key => {
    const match = /^(\d{4})-(\d{2})$/.exec(String(key || ''));
    if (!match) return String(key || 'Periodo sin fecha');
    return new Intl.DateTimeFormat('es-GT', {month:'long', year:'numeric'}).format(new Date(Number(match[1]), Number(match[2])-1, 1));
  };
  const monthShort = key => {
    const match = /^(\d{4})-(\d{2})$/.exec(String(key || ''));
    if (!match) return String(key || '');
    const month = new Intl.DateTimeFormat('es-GT', {month:'short'}).format(new Date(Number(match[1]),Number(match[2])-1,1)).replace('.', '');
    return `${month.charAt(0).toLocaleUpperCase('es-GT')}${month.slice(1)} ${match[1].slice(-2)}`;
  };
  const METRICS = {
    facturacion_gtq:{label:'Facturación',type:'money',value:item=>number(item.official_controls?.facturacion_gtq)},
    preventa_gtq:{label:'Preventa',type:'money',value:item=>number(item.official_controls?.preventa_gtq)},
    diferencia_gtq:{label:'Diferencia',type:'money',value:item=>number(item.official_controls?.diferencia_gtq)},
    cumplimiento_pct:{label:'Cumplimiento',type:'percent',value:item=>number(item.official_controls?.cumplimiento_pct)}
  };
  const model = {history:[], selectedMonth:'', metric:'facturacion_gtq', view:'horizontal'};
  let wired = false;
  const activeMeta = () => METRICS[model.metric] || METRICS.facturacion_gtq;
  function getMonths() {
    const seen = new Set();
    return [...model.history].filter(item => /^\d{4}-\d{2}$/.test(String(item.month||'')) && !seen.has(item.month) && seen.add(item.month))
      .sort((a,b)=>String(a.month).localeCompare(String(b.month)));
  }
  function getActiveContext(months) {
    if (!months.length) return {active:null,previous:null,index:-1};
    let index=months.findIndex(item=>item.month===model.selectedMonth);
    if(index<0) index=months.length-1;
    return {active:months[index],previous:index>0?months[index-1]:null,index};
  }
  function formatMetric(value) { return activeMeta().type==='percent' ? percent(value) : money(value); }
  function renderStats(months,context) {
    const host=$('#monthCompareStats'); if(!host)return;
    const {active,previous}=context;
    if(!active){
      const cards=[['Meses guardados','0','El historial está vacío'],['Última facturación','—','Importa un Excel mensual válido'],['Cambio mensual','—','Se habilita con dos periodos'],['Cumplimiento','—','Se calcula a partir de las cifras oficiales']];
      host.innerHTML=cards.map(([label,value,note])=>`<article class="compare-stat"><span class="compare-stat-label">${label}</span><strong>${value}</strong><small>${note}</small></article>`).join('');return;
    }
    const c=active.official_controls||{},bill=number(c.facturacion_gtq),prev=previous?number(previous.official_controls?.facturacion_gtq):null,delta=prev===null?null:bill-prev;
    const deltaClass=delta===null?'is-neutral':delta>0?'is-positive':delta<0?'is-negative':'is-neutral';
    const deltaValue=delta===null?'—':`${delta>0?'+':delta<0?'−':''}${money(Math.abs(delta))}`;
    const note=delta===null?'Importa otro mes para comparar':`${monthLong(previous.month)} · ${Math.abs(prev)>0?`${fmt(Math.abs(delta/prev*100))}% de variación`:'sin base porcentual'}`;
    const cards=[
      {label:'Meses guardados',value:String(months.length),note:'Periodos únicos archivados',cls:'is-neutral'},
      {label:`Facturación · ${monthLong(active.month)}`,value:money(bill),note:'Total oficial del periodo activo',cls:'is-neutral'},
      {label:'Cambio frente al mes anterior',value:deltaValue,note,cls:deltaClass},
      {label:'Cumplimiento del periodo',value:percent(c.cumplimiento_pct),note:'Facturación en relación con preventa',cls:'is-neutral'}
    ];
    host.innerHTML=cards.map((card,i)=>`<article class="compare-stat" style="--card-order:${i}"><span class="compare-stat-label">${escapeHtml(card.label)}</span><strong class="${card.cls}">${escapeHtml(card.value)}</strong><small>${escapeHtml(card.note)}</small></article>`).join('');
  }
  function drawEmpty(host){host.innerHTML='<div class="compare-empty compare-empty-state"><span class="compare-empty-icon">▤</span><strong>No hay meses para comparar todavía</strong><span>Importa un Excel mensual y aquí aparecerá la facturación oficial por periodo.</span><a href="#historial" class="button button-outline">Ir a insertar Excel</a></div>';}
  function chartGridHorizontal(W,H,left,right,top,bottom,maxAbs,meta,negative){
    const x0=left,x1=W-right,plotW=x1-x0,zero=negative?x0+plotW/2:x0;
    const ticks=negative?[-1,-.5,0,.5,1]:[0,.25,.5,.75,1];
    return {zero,plotW,grid:ticks.map(f=>{const value=negative?f*maxAbs:f*maxAbs,x=negative?zero+f*plotW/2: x0+f*plotW;const text=meta.type==='percent'?percent(value):compactMoney(value);return `<g class="chart-tick"><line class="compare-grid-line" x1="${x.toFixed(2)}" y1="${top}" x2="${x.toFixed(2)}" y2="${H-bottom}"/><text class="compare-axis-label" x="${x.toFixed(2)}" y="${H-bottom+17}" text-anchor="middle">${escapeHtml(text)}</text></g>`;}).join('')};
  }
  function renderHorizontal(host,months,meta){
    const rows=months.length, W=1020, rowH=43, top=24, bottom=34, H=Math.max(215,top+rows*rowH+bottom), left=190,right=34, plotW=W-left-right;
    const values=months.map(meta.value), negative=model.metric==='diferencia_gtq', maxAbs=Math.max(1,...values.map(Math.abs))*(negative?1.50:1.32), zero=negative?left+plotW/2:left, usable=negative?plotW/2:plotW;
    const ticks=negative?[-1,-.5,0,.5,1]:[0,.25,.5,.75,1];
    const grid=ticks.map(f=>{const x=negative?zero+f*usable: left+f*plotW;const value=f*maxAbs;return `<g><line class="compare-grid-line" x1="${x}" y1="${top-9}" x2="${x}" y2="${H-bottom}"/><text class="compare-axis-label" x="${x}" y="${H-9}" text-anchor="middle">${escapeHtml(meta.type==='percent'?percent(value):compactMoney(value))}</text></g>`;}).join('');
    const rowsSvg=months.map((item,i)=>{
      const value=values[i],cy=top+i*rowH+rowH/2,selected=item.month===model.selectedMonth;
      const barWidth=Math.max(Math.abs(value)/maxAbs*usable,Math.abs(value)>0?2:0),x=value<0?zero-barWidth:zero,barY=cy-8;
      const label=meta.type==='percent'?percent(value):(negative?`${value>0?'+':value<0?'−':''}${money(Math.abs(value))}`:money(value));
      let textX,textAnchor;
      if(negative){
        // Reserve space on both sides of the zero line, including the minus sign and full amount.
        if(value<0){textX=Math.max(left+6,x-9);textAnchor=textX<=left+8?'start':'end';}
        else{textX=Math.min(W-right-6,x+barWidth+9);textAnchor='start';}
      }else{
        textX=x+barWidth+10;
        textAnchor='start';
      }
      return `<g class="compare-data-row ${selected?'is-active':''}" data-month="${escapeHtml(item.month)}" tabindex="0" role="button" aria-label="Abrir ${escapeHtml(monthLong(item.month))}, ${escapeHtml(label)}" style="--row-delay:${Math.min(i*.035,.35)}s"><title>${escapeHtml(monthLong(item.month))}: ${escapeHtml(label)}</title><rect class="compare-row-highlight" x="6" y="${cy-rowH/2+1}" width="${W-12}" height="${rowH-2}" rx="8"/><text class="compare-period-label" x="12" y="${cy+4}">${escapeHtml(monthLong(item.month))}</text><rect class="compare-track" x="${negative?left:zero}" y="${barY}" width="${usable}" height="16" rx="5"/><rect class="compare-horizontal-bar${selected?' is-active':''}${value<0?' is-negative':''}" x="${x.toFixed(2)}" y="${barY}" width="${barWidth.toFixed(2)}" height="16" rx="5"/><text class="compare-horizontal-value" x="${textX.toFixed(2)}" y="${cy+4}" text-anchor="${textAnchor}">${escapeHtml(label)}</text></g>`;
    }).join('');
    const zeroLine=negative?`<line class="compare-zero-line" x1="${zero}" y1="${top-9}" x2="${zero}" y2="${H-bottom}"/>`:'';
    host.innerHTML=`<svg class="monthly-svg monthly-horizontal" viewBox="0 0 ${W} ${H}" role="img" aria-label="${escapeHtml(meta.label)} mensual en barras horizontales" preserveAspectRatio="xMidYMin meet"><defs><linearGradient id="emaMonthBar" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#269edb"/><stop offset="100%" stop-color="#65e5d2"/></linearGradient><linearGradient id="emaMonthBarSelected" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#48c3f4"/><stop offset="100%" stop-color="#83f1d6"/></linearGradient></defs>${grid}${zeroLine}${rowsSvg}</svg>`;
  }
  function renderColumns(host,months,meta){
    const rows=months.length,W=1020,H=330,left=72,right=22,top=32,bottom=62,plotW=W-left-right,plotH=H-top-bottom,values=months.map(meta.value),negative=model.metric==='diferencia_gtq';
    let min=negative?Math.min(0,...values):0,max=negative?Math.max(0,...values):Math.max(1,...values);if(meta.type==='percent')min=0;if(Math.abs(max-min)<1e-9)max=min+1;
    const pad=(max-min)*.1;min-=negative?pad:0;max+=pad;const y=v=>top+(max-v)/(max-min)*plotH,zero=y(0),slot=plotW/months.length,barW=Math.min(52,Math.max(10,slot*.54));
    const ticks=Array.from({length:5},(_,i)=>max-(max-min)*i/4);
    const grid=ticks.map(v=>`<g><line class="compare-grid-line" x1="${left}" y1="${y(v)}" x2="${W-right}" y2="${y(v)}"/><text class="compare-axis-label" x="${left-10}" y="${y(v)+4}" text-anchor="end">${escapeHtml(meta.type==='percent'?percent(v):compactMoney(v))}</text></g>`).join('');
    const bars=months.map((item,i)=>{const v=values[i],cx=left+slot*(i+.5),vy=y(v),ry=Math.min(zero,vy),rh=Math.max(1,Math.abs(zero-vy)),selected=item.month===model.selectedMonth,label=meta.type==='percent'?percent(v):compactMoney(v);const ly=v>=0?Math.max(top+13,ry-8):Math.min(H-bottom-4,ry+rh+14);return `<g class="compare-column-group ${selected?'is-active':''}" data-month="${escapeHtml(item.month)}" tabindex="0" role="button" aria-label="Abrir ${escapeHtml(monthLong(item.month))}, ${escapeHtml(meta.type==='percent'?percent(v):money(v))}"><title>${escapeHtml(monthLong(item.month))}: ${escapeHtml(meta.type==='percent'?percent(v):money(v))}</title><rect class="compare-column-hit" x="${cx-slot/2}" y="${top}" width="${slot}" height="${plotH}" rx="6"/><rect class="compare-column-bar${selected?' is-active':''}${v<0?' is-negative':''}" x="${cx-barW/2}" y="${ry}" width="${barW}" height="${rh}" rx="5"/><text class="compare-column-value" x="${cx}" y="${ly}" text-anchor="middle">${escapeHtml(label)}</text><text class="compare-month-label" x="${cx}" y="${H-24}" text-anchor="middle">${escapeHtml(monthShort(item.month))}</text></g>`;}).join('');
    host.innerHTML=`<svg class="monthly-svg monthly-columns" viewBox="0 0 ${W} ${H}" role="img" aria-label="${escapeHtml(meta.label)} mensual en columnas" preserveAspectRatio="xMidYMid meet"><defs><linearGradient id="emaMonthBar" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#65e5d2"/><stop offset="100%" stop-color="#269edb"/></linearGradient><linearGradient id="emaMonthBarSelected" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#83f1d6"/><stop offset="100%" stop-color="#48c3f4"/></linearGradient></defs>${grid}<line class="compare-zero-line" x1="${left}" y1="${zero}" x2="${W-right}" y2="${zero}"/>${bars}</svg>`;
  }
  function renderLine(host,months,meta){
    const W=1020,H=330,left=72,right=26,top=34,bottom=62,plotW=W-left-right,plotH=H-top-bottom,values=months.map(meta.value),negative=model.metric==='diferencia_gtq';
    let min=negative?Math.min(0,...values):0,max=negative?Math.max(0,...values):Math.max(1,...values);if(meta.type==='percent')min=0;if(Math.abs(max-min)<1e-9)max=min+1;const pad=(max-min)*.1;min-=negative?pad:0;max+=pad;
    const x=i=>left+(months.length===1?plotW/2:i/(months.length-1)*plotW),y=v=>top+(max-v)/(max-min)*plotH,zero=y(0);
    const ticks=Array.from({length:5},(_,i)=>max-(max-min)*i/4),grid=ticks.map(v=>`<g><line class="compare-grid-line" x1="${left}" y1="${y(v)}" x2="${W-right}" y2="${y(v)}"/><text class="compare-axis-label" x="${left-10}" y="${y(v)+4}" text-anchor="end">${escapeHtml(meta.type==='percent'?percent(v):compactMoney(v))}</text></g>`).join('');
    const points=values.map((v,i)=>`${x(i)},${y(v)}`).join(' '),area=`${left},${y(min)} ${points} ${x(months.length-1)},${y(min)}`;
    const nodes=months.map((item,i)=>{const v=values[i],selected=item.month===model.selectedMonth;return `<g class="compare-line-point-group ${selected?'is-active':''}" data-month="${escapeHtml(item.month)}" tabindex="0" role="button" aria-label="Abrir ${escapeHtml(monthLong(item.month))}, ${escapeHtml(meta.type==='percent'?percent(v):money(v))}"><title>${escapeHtml(monthLong(item.month))}: ${escapeHtml(meta.type==='percent'?percent(v):money(v))}</title><circle class="compare-line-point-hit" cx="${x(i)}" cy="${y(v)}" r="12"/><circle class="compare-line-point${selected?' is-active':''}" cx="${x(i)}" cy="${y(v)}" r="5"/><text class="compare-month-label" x="${x(i)}" y="${H-24}" text-anchor="middle">${escapeHtml(monthShort(item.month))}</text></g>`;}).join('');
    const line = months.length===1?`M ${x(0)} ${y(values[0])}`:`M ${points.replaceAll(' ', ' L ')}`;
    host.innerHTML=`<svg class="monthly-svg monthly-line" viewBox="0 0 ${W} ${H}" role="img" aria-label="${escapeHtml(meta.label)} mensual en línea" preserveAspectRatio="xMidYMid meet"><defs><linearGradient id="emaMonthlyLineArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#63e5d2" stop-opacity=".22"/><stop offset="100%" stop-color="#63e5d2" stop-opacity="0"/></linearGradient></defs>${grid}${negative?`<line class="compare-zero-line" x1="${left}" y1="${zero}" x2="${W-right}" y2="${zero}"/>`:''}<polygon class="compare-line-area" points="${area}"/><path class="compare-line-path" d="${line}"/>${nodes}</svg>`;
  }
  function renderChart(months){
    const host=$('#monthCompareChart'),title=$('#monthCompareChartTitle'),hint=$('#monthCompareChartHint');if(!host)return;
    const meta=activeMeta();if(title)title.textContent=`${meta.label} por mes`;
    if(!months.length){drawEmpty(host);if(hint)hint.textContent='Cuando cargues meses, la gráfica se actualizará con los importes oficiales.';return;}
    const visible=months.slice(-12);
    if(hint){const range=months.length>12?`Se muestran los 12 periodos más recientes de ${months.length}. `:'';const desc=model.view==='horizontal'?'Barras horizontales: mes a la izquierda e importe completo a la derecha.':model.view==='line'?'Línea cronológica para ver la evolución entre meses.':'Columnas para comparar el tamaño de cada periodo.';hint.textContent=range+desc+' Selecciona cualquier periodo para abrirlo.';}
    if(model.view==='line')renderLine(host,visible,meta);else if(model.view==='columns')renderColumns(host,visible,meta);else renderHorizontal(host,visible,meta);
  }
  function renderTable(months){
    const body=$('#monthCompareTbody'),count=$('#monthCompareCount');if(!body)return;
    if(count)count.textContent=`${months.length} ${months.length===1?'periodo':'periodos'}`;
    if(!months.length){body.innerHTML='<tr><td colspan="6" class="compare-empty">Todavía no hay meses guardados.</td></tr>';return;}
    body.innerHTML=[...months].reverse().map(item=>{const c=item.official_controls||{},q=item.quality_report||{},active=item.month===model.selectedMonth,score=number(q.score),good=q.status==='verified';return `<tr class="${active?'is-selected-month':''}"><td class="period-cell">${escapeHtml(monthLong(item.month))}${active?' <span class="compare-delta neutral">· activo</span>':''}</td><td class="num">${escapeHtml(money(c.preventa_gtq))}</td><td class="num">${escapeHtml(money(c.facturacion_gtq))}</td><td class="num">${escapeHtml((number(c.diferencia_gtq)>0?'+':number(c.diferencia_gtq)<0?'−':'')+money(Math.abs(number(c.diferencia_gtq))))}</td><td class="num">${escapeHtml(percent(c.cumplimiento_pct))}</td><td><span class="compare-quality${good?'':' review'}">${good?'✓ Verificado':`! Revisar · ${Math.round(score)}%`}</span></td></tr>`;}).join('');
  }
  function render(){const months=getMonths();renderStats(months,getActiveContext(months));renderChart(months);renderTable(months);}
  function csvCell(value){return `"${String(value??'').replace(/"/g,'""')}"`;}
  function exportCsv(){
    const months=getMonths();if(!months.length){window.alert('No hay periodos guardados para exportar.');return;}
    const rows=[['Periodo','Preventa (Q)','Facturación (Q)','Diferencia (Q)','Cumplimiento (%)','Vendedores','Rutas','Calidad (%)','Estado de calidad','Archivo fuente','Fecha de importación'],...[...months].reverse().map(item=>{const c=item.official_controls||{},counts=item.counts||{},q=item.quality_report||{};return[monthLong(item.month),number(c.preventa_gtq).toFixed(2),number(c.facturacion_gtq).toFixed(2),number(c.diferencia_gtq).toFixed(2),number(c.cumplimiento_pct).toFixed(4),number(counts.sellers),number(counts.routes),number(q.score),q.status||'unknown',item.source_file||'',item.imported_at||''];})];
    const content='\ufeff'+rows.map(row=>row.map(csvCell).join(';')).join('\r\n'),url=URL.createObjectURL(new Blob([content],{type:'text/csv;charset=utf-8;'}));const a=document.createElement('a');a.href=url;a.download=`EMA-comparativo-mensual-${new Date().toISOString().slice(0,10)}.csv`;a.style.display='none';document.body.appendChild(a);a.click();a.remove();window.setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function openMonth(month){const selector=$('#monthSelector');if(!selector)return;selector.value=month;selector.dispatchEvent(new Event('change',{bubbles:true}));}
  function wire(){
    if(wired)return;wired=true;
    $('#monthCompareMetric')?.addEventListener('change',event=>{model.metric=METRICS[event.target.value]?event.target.value:'facturacion_gtq';render();});
    $('#monthCompareView')?.addEventListener('change',event=>{model.view=['horizontal','columns','line'].includes(event.target.value)?event.target.value:'horizontal';render();});
    $('#exportMonthCompareBtn')?.addEventListener('click',exportCsv);
    $('#monthCompareChart')?.addEventListener('click',event=>{const group=event.target.closest('[data-month]');if(group?.dataset.month)openMonth(group.dataset.month);});
    $('#monthCompareChart')?.addEventListener('keydown',event=>{if(!['Enter',' '].includes(event.key))return;const group=event.target.closest('[data-month]');if(group?.dataset.month){event.preventDefault();openMonth(group.dataset.month);}});
    window.addEventListener('ema:history-updated',event=>{const data=event.detail||{};model.history=Array.isArray(data.history)?data.history:[];model.selectedMonth=String(data.selectedMonth||'');render();});
    fetch('/api/history',{cache:'no-store'}).then(response=>response.ok?response.json():null).then(data=>{if(!data||!Array.isArray(data.months))return;if(!model.history.length){model.history=data.months;const selector=$('#monthSelector');model.selectedMonth=selector?.value||'';render();}}).catch(()=>{});
  }
  wire();window.EmaMonthlyComparison={render,exportCsv};
})();

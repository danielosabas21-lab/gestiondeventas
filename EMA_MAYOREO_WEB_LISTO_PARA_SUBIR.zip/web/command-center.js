'use strict';

(() => {
  const root = document.documentElement;
  const query = selector => document.querySelector(selector);
  const byId = id => document.getElementById(id);
  let controller = null;
  let navObserver = null;
  let previousFocus = null;
  let commands = [];
  let visibleCommands = [];
  let selectedIndex = 0;
  let paletteOpen = false;
  let drawerOpen = false;

  const text = key => typeof window.emaT === 'function' ? window.emaT(key) : key;
  const storage = {
    get(key) { try { return localStorage.getItem(key); } catch (_) { return null; } },
    set(key, value) { try { localStorage.setItem(key, value); } catch (_) {} }
  };
  const reducedBySystem = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reducedByPreference = () => false;

  function updateTheme(){
    root.dataset.theme = 'dark';
    const meta = query('meta[name="theme-color"]');
    if (meta) meta.content = '#09110d';
  }

  function updateSidebar(collapsed, persist = false) {
    const value = Boolean(collapsed);
    document.querySelectorAll('.nav-link').forEach(link => link.setAttribute('aria-label', navLabel(link)));
    root.classList.toggle('sidebar-collapsed', value);
    if (persist) storage.set('ema-panel-sidebar', value ? 'collapsed' : 'expanded');
    const key = value ? 'expandSidebar' : 'collapseSidebar';
    const label = text(key);
    const button = byId('sidebarToggle');
    if (button) {
      button.setAttribute('aria-pressed', String(value));
      button.setAttribute('aria-label', label);
      button.title = label;
      const visible = button.querySelector('.sidebar-toggle-label');
      if (visible) visible.textContent = label;
    }
  }

  function updateMotionPreference(persist = false) {
    const system = reducedBySystem();
    const reduced = system;
    root.dataset.motion = reduced ? 'reduced' : 'full';
    window.EmaMotion?.setReducedMotion(reduced);
    if (persist) storage.set('ema-panel-motion', reduced ? 'reduce' : 'full');
  }

  function localizePreferences() {
    updateTheme();
    updateSidebar(root.classList.contains('sidebar-collapsed'));
    updateMotionPreference();
  }

  function navLabel(link) { return link.querySelector('[data-i18n]')?.textContent.trim() || link.textContent.trim(); }

  function buildCommands() {
    const links = [...document.querySelectorAll('.nav-link')];
    links.forEach(link => link.setAttribute('aria-label', navLabel(link)));
    commands = links.map(link => ({
      title: navLabel(link),
      keywords: `section section navigate ${link.getAttribute('href')}`,
      icon: link.querySelector('svg')?.outerHTML || '',
      run: () => { closePalette(false); navigate(link.getAttribute('href')); }
    }));
    commands.push(
      { title: text('searchLabel'), keywords: 'vendedor buscar', icon: '⌕', run: () => { closePalette(false); navigate('#vendedores', false); byId('searchInput')?.focus(); } },
      { title: text('filterRegionLabel'), keywords: 'región filtrar', icon: '⌖', run: () => { closePalette(false); navigate('#vendedores', false); byId('regionSelect')?.focus(); } },
      { title: text('refresh'), keywords: 'actualizar recargar', icon: '↻', run: () => { closePalette(false); byId('refreshBtn')?.click(); } },
      { title: text('fullscreen'), keywords: 'pantalla completa', icon: '⛶', run: () => { closePalette(false); byId('fullscreenBtn')?.click(); } },
    );
    const regionSelect = byId('regionSelect');
    [...(regionSelect?.options || [])].filter(option => option.value).forEach(option => {
      commands.push({
        title: `${text('filterRegionLabel')}: ${option.textContent.trim()}`,
        keywords: `región ${option.value} ${option.textContent} filtrar`,
        icon: '⌖',
        run: () => {
          closePalette(false);
          regionSelect.value = option.value;
          regionSelect.dispatchEvent(new Event('change', { bubbles: true }));
          navigate('#vendedores', false);
        }
      });
    });
  }

  function normalize(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase(root.lang || 'es');
  }

  function renderCommands() {
    const input = byId('commandSearch'), list = byId('commandResults');
    if (!input || !list) return;
    buildCommands();
    const value = normalize(input.value);
    visibleCommands = commands.filter(command => normalize(`${command.title} ${command.keywords}`).includes(value));
    selectedIndex = Math.max(0, Math.min(selectedIndex, visibleCommands.length - 1));
    if (!visibleCommands.length) {
      list.innerHTML = `<div class="command-empty">${escapeHTML(text('commandNoResults'))}</div>`;
      byId('commandStatus').textContent = text('commandNoResults');
      return;
    }
    list.innerHTML = visibleCommands.map((command, index) => `<button id="command-option-${index}" class="command-option${index === selectedIndex ? ' is-selected' : ''}" type="button" role="option" aria-selected="${index === selectedIndex}" data-command-index="${index}"><span class="command-option-icon" aria-hidden="true">${command.icon}</span><span class="command-option-title">${escapeHTML(command.title)}</span><kbd>↵</kbd></button>`).join('');
    byId('commandSearch').setAttribute('aria-activedescendant', `command-option-${selectedIndex}`);
    byId('commandStatus').textContent = `${visibleCommands.length} ${text('commandResultsLabel')}`;
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  }

  function openPalette() {
    if (paletteOpen || !byId('commandPalette')) return;
    if (!byId('welcomeOverlay')?.classList.contains('hidden') || !byId('sellerModal')?.classList.contains('hidden')) return;
    previousFocus = document.activeElement;
    if (drawerOpen) closeDrawer(false);
    paletteOpen = true;
    const modal = byId('commandPalette');
    modal.classList.remove('hidden');
    document.body.classList.add('dialog-open');
    byId('inicio')?.setAttribute('inert', '');
    byId('control')?.setAttribute('inert', '');
    byId('mobileMenuBtn')?.setAttribute('inert', '');
    document.querySelector('.mobile-bottom-nav')?.setAttribute('inert', '');
    const input = byId('commandSearch');
    input.value = '';
    selectedIndex = 0;
    renderCommands();
    requestAnimationFrame(() => input.focus());
  }

  function closePalette(restore = true) {
    if (!paletteOpen) return;
    paletteOpen = false;
    byId('commandPalette')?.classList.add('hidden');
    ['inicio', 'control', 'mobileMenuBtn'].forEach(id => byId(id)?.removeAttribute('inert'));
    document.querySelector('.mobile-bottom-nav')?.removeAttribute('inert');
    if (!drawerOpen && byId('sellerModal')?.classList.contains('hidden')) document.body.classList.remove('dialog-open');
    if (restore && previousFocus?.isConnected) previousFocus.focus();
  }

  function navigate(hash, closeDrawerAfter = true) {
    const id = String(hash || '').replace(/^#/, '');
    const target = id === 'inicio' ? byId('inicio') : byId(id);
    if (!target) return;
    if (closeDrawerAfter) closeDrawer(false);
    const behavior = root.dataset.motion === 'reduced' ? 'auto' : 'smooth';
    if (id === 'inicio') window.scrollTo({ top: 0, behavior });
    else target.scrollIntoView({ behavior, block: 'start' });
    history.replaceState(null, '', `#${id}`);
    const focusTarget = target.matches('main') ? byId('heroTitle') : target.querySelector('h2, h1');
    window.setTimeout(() => focusTarget?.focus({ preventScroll: true }), behavior === 'smooth' ? 380 : 0);
  }


  function runCommand(index = selectedIndex) {
    const command = visibleCommands[index];
    if (command) command.run();
  }

  function focusPaletteOption(index) {
    if (!visibleCommands.length) return;
    selectedIndex = (index + visibleCommands.length) % visibleCommands.length;
    renderCommands();
    const selected = byId('commandResults')?.querySelector('.is-selected');
    selected?.scrollIntoView({ block: 'nearest' });
  }

  function openDrawer() {
    if (window.matchMedia('(min-width: 761px)').matches || drawerOpen) return;
    drawerOpen = true;
    const sidebar = byId('mainSidebar'), backdrop = byId('drawerBackdrop'), trigger = byId('mobileMenuBtn');
    sidebar?.classList.add('is-open');
    sidebar?.setAttribute('role', 'dialog');
    sidebar?.setAttribute('aria-modal', 'true');
    byId('inicio')?.setAttribute('inert', '');
    document.querySelector('.mobile-bottom-nav')?.setAttribute('inert', '');
    backdrop?.classList.add('is-visible');
    if (backdrop) backdrop.tabIndex = 0;
    trigger?.setAttribute('aria-expanded', 'true');
    document.body.classList.add('drawer-open');
    requestAnimationFrame(() => sidebar?.querySelector('.nav-link')?.focus());
  }

  function closeDrawer(restore = true) {
    if (!drawerOpen) return;
    drawerOpen = false;
    const sidebar = byId('mainSidebar'), backdrop = byId('drawerBackdrop'), trigger = byId('mobileMenuBtn');
    sidebar?.classList.remove('is-open');
    sidebar?.removeAttribute('role');
    sidebar?.removeAttribute('aria-modal');
    byId('inicio')?.removeAttribute('inert');
    document.querySelector('.mobile-bottom-nav')?.removeAttribute('inert');
    backdrop?.classList.remove('is-visible');
    if (backdrop) backdrop.tabIndex = -1;
    trigger?.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('drawer-open');
    if (!paletteOpen && byId('sellerModal')?.classList.contains('hidden')) document.body.classList.remove('dialog-open');
    if (restore) trigger?.focus();
  }

  function handleKeydown(event) {
    const tag = document.activeElement?.tagName;
    const editing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(tag) || document.activeElement?.isContentEditable;
    if (event.key === 'Escape') {
      if (paletteOpen) { event.preventDefault(); closePalette(); return; }
      if (drawerOpen) { event.preventDefault(); closeDrawer(); return; }
    }
    if (!byId('welcomeOverlay')?.classList.contains('hidden')) return;
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      if (paletteOpen) closePalette(); else openPalette();
      return;
    }
    if (paletteOpen) {
      if (event.key === 'ArrowDown') { event.preventDefault(); focusPaletteOption(selectedIndex + 1); }
      else if (event.key === 'ArrowUp') { event.preventDefault(); focusPaletteOption(selectedIndex - 1); }
      else if (event.key === 'Enter' && document.activeElement === byId('commandSearch')) { event.preventDefault(); runCommand(); }
      else if (event.key === 'Tab') {
        const focusable = [...byId('commandPalette').querySelectorAll('input:not([disabled]),button:not([disabled])')];
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
      return;
    }
    if (drawerOpen && event.key === 'Tab') {
      const focusable = [...byId('mainSidebar').querySelectorAll('a[href],button:not([disabled]),select,input')].filter(node => node.offsetParent !== null);
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      return;
    }
    if (event.key === '/' && !editing && !event.ctrlKey && !event.metaKey) { event.preventDefault(); byId('searchInput')?.focus(); }
  }

  function observeSections() {
    navObserver?.disconnect();
    if (!('IntersectionObserver' in window)) return;
    const sections = ['comparativo', 'analisis', 'mapa', 'vendedores', 'control'].map(byId).filter(Boolean);
    navObserver = new IntersectionObserver(entries => {
      const current = entries.filter(entry => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (!current) return;
      document.querySelectorAll('.nav-link[href^="#"], .mobile-nav-link[href^="#"]').forEach(link => {
        const selected = link.getAttribute('href') === `#${current.target.id}`;
        link.classList.toggle('active', selected);
        if (selected) link.setAttribute('aria-current', 'location'); else link.removeAttribute('aria-current');
      });
    }, { rootMargin: '-18% 0px -67% 0px', threshold: [0, .15, .35] });
    sections.forEach(section => navObserver.observe(section));
  }

  function updateActiveNavigation() {
    const id = location.hash.slice(1) || 'inicio';
    document.querySelectorAll('.nav-link[href^="#"], .mobile-nav-link[href^="#"]').forEach(link => {
      const selected = link.getAttribute('href') === `#${id}`;
      link.classList.toggle('active', selected);
      if (selected) link.setAttribute('aria-current', 'location'); else link.removeAttribute('aria-current');
    });
  }

  function init() {
    if (controller) return;
    controller = new AbortController();
    const { signal } = controller;
    updateTheme();
    updateSidebar(storage.get('ema-panel-sidebar') === 'collapsed');
    updateMotionPreference();
    observeSections();
    updateActiveNavigation();
    document.querySelectorAll('.nav-link[href],.mobile-nav-link[href]').forEach(link => {
      link.addEventListener('click', () => closeDrawer(false), { signal });
    });
    byId('commandOpenBtn')?.addEventListener('click', openPalette, { signal });
    byId('commandSearch')?.addEventListener('input', () => { selectedIndex = 0; renderCommands(); }, { signal });
    byId('commandResults')?.addEventListener('click', event => {
      const option = event.target.closest('[data-command-index]');
      if (option) runCommand(Number(option.dataset.commandIndex));
    }, { signal });
    byId('commandPalette')?.addEventListener('click', event => {
      if (event.target.dataset.commandClose) closePalette();
    }, { signal });
    byId('sidebarToggle')?.addEventListener('click', () => updateSidebar(!root.classList.contains('sidebar-collapsed'), true), { signal });
    byId('mobileMenuBtn')?.addEventListener('click', openDrawer, { signal });
    byId('mobileMoreBtn')?.addEventListener('click', openDrawer, { signal });
    byId('drawerBackdrop')?.addEventListener('click', () => closeDrawer(), { signal });
    document.addEventListener('keydown', handleKeydown, { signal });
    window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener?.('change', () => updateMotionPreference(), { signal });
    window.addEventListener('hashchange', updateActiveNavigation, { signal });
    if ('serviceWorker' in navigator && window.isSecureContext) navigator.serviceWorker.register('/sw.js?v=64.0.0').catch(() => {});
    localizePreferences();
  }

  function destroy() {
    controller?.abort();
    controller = null;
    navObserver?.disconnect();
    navObserver = null;
    closePalette(false);
    closeDrawer(false);
  }

  window.EmaCommandCenter = { init, destroy, openPalette, closePalette, updateSidebar };
  init();
})();

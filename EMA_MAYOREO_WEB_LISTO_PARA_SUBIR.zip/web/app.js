'use strict';

const translations = {
  es: {
    skipContent:'Saltar al contenido', mainNavigation:'Navegación principal', sectionsNavigation:'Secciones', brandHome:'EMA MAYOREO, inicio', appDescription:'Panel ejecutivo de ventas, facturación y vendedores de EMA MAYOREO.', brandSubtitle:'Panel ejecutivo', navOverview:'Resumen', navAnalysis:'Análisis', navRoutes:'Vendedores', navAudit:'Auditoría', sourceLabel:'FUENTE FINANCIERA', sourceNote:'Los importes oficiales del panel se toman de esta hoja.', loading:'Cargando…', pageEyebrow:'PANEL EJECUTIVO', pageTitle:'Ventas y facturación', loadingPeriod:'Cargando periodo…', languageLabel:'Idioma', checking:'Verificando', refresh:'Actualizar', fullscreen:'Pantalla completa', exitFullscreen:'Salir de pantalla completa', heroEyebrow:'UNA VISTA CLARA DE LA OPERACIÓN', heroTitle:'Cada cifra en su contexto.', heroDescription:'Compara la preventa con la facturación, revisa el resultado por vendedor y consulta los ajustes por separado.', viewRoutes:'Ver vendedores', printSummary:'Imprimir resumen', shareLink:'Compartir enlace', officialDifference:'DIFERENCIA OFICIAL', differenceCaption:'Facturación menos preventa, según el control oficial.', officialCompletion:'Cumplimiento oficial', qualityOk:'Conciliado', qualityReview:'Revisar cifras', mainMetrics:'Indicadores principales', kpiBilling:'Facturación oficial', kpiBillingNote:'Incluye {{amount}} de ajuste oficial sin ruta.', kpiPreventa:'Preventa consolidada', kpiPreventaNote:'Importes de {{count}} vendedores incluidos.', kpiCompletion:'Cumplimiento', kpiCompletionNote:'Facturación dividida entre preventa.', kpiDifference:'Diferencia oficial', kpiDifferenceNote:'Facturación menos preventa.', keyHighlights:'Puntos destacados', bestRegionLabel:'REGIÓN CON MÁS FACTURACIÓN', bestRegionNote:'{{amount}} facturados', topRoute:'VENDEDOR CON MÁS FACTURACIÓN', topSellerNote:'{{amount}} facturados', attentionRoute:'MAYOR BRECHA NEGATIVA POR VENDEDOR', attentionSellerNote:'{{amount}} frente a preventa', activeDaysLabel:'DÍAS DEL PERIODO', activeDaysCaption:'Con actividad en el consolidado', trendEyebrow:'TENDENCIA', trendTitle:'Preventa y facturación', trendNote:'Importes diarios del periodo oficial.', preventa:'Preventa', billing:'Facturación', trendChartLabel:'Tendencia diaria de preventa y facturación', regionEyebrow:'DISTRIBUCIÓN', regionTitle:'Facturación por región', regionNote:'Distribución de la facturación por región.', regionPreventa:'Preventa {{amount}}', reconciliationEyebrow:'CONTROL FINANCIERO', reconciliationTitle:'Conciliación de cifras', reconciliationNote:'El total oficial conserva los ajustes sin ruta.', routePreventa:'Preventa asignada a vendedores', routeBilling:'Facturación asignada a vendedores', routeAdjustments:'Ajustes oficiales sin ruta', officialBilling:'Facturación oficial', officialPreventa:'Preventa oficial', officialDiff:'Diferencia oficial', reconciliationCallout:'El ajuste de {{amount}} no se asigna a vendedores. Se muestra por separado para conciliar el total oficial.', focusEyebrow:'LECTURA EJECUTIVA', focusTitle:'Qué conviene mirar', focusNote:'Claves para interpretar los datos del panel.', focusOneTitle:'El total oficial es la referencia', focusOneBody:'La facturación oficial incluye el ajuste sin ruta; el panel lo muestra por separado.', focusTwoTitle:'Compara cada vendedor con su preventa', focusTwoBody:'La tabla suma los registros de cada vendedor y muestra su diferencia y cumplimiento.', focusThreeTitle:'Las excepciones se mantienen visibles', focusThreeBody:'Las diferencias de origen se detallan en Auditoría y no se incorporan a los KPI.', routesEyebrow:'RENDIMIENTO', routesTitle:'Rendimiento por vendedor', routesNote:'Cada fila suma los registros del vendedor. Los ajustes que no tienen vendedor se muestran por separado.', searchPlaceholder:'Buscar vendedor o región', searchLabel:'Buscar vendedor o región', allRegions:'Todas las regiones', filterRegionLabel:'Filtrar por región', sortRoutesLabel:'Ordenar vendedores', sortBilling:'Mayor facturación', sortGap:'Mayor brecha', sortCompletion:'Mayor cumplimiento', sortSeller:'Vendedor A–Z', downloadCsv:'Descargar CSV', clearFilters:'Limpiar', scrollTable:'Desplazar tabla horizontalmente para ver más columnas', route:'Ruta', seller:'Vendedor', region:'Región', difference:'Diferencia', completion:'Cumplimiento', rowActions:'Acciones', showingSellers:'Mostrando {{shown}} de {{total}} vendedores', filteredTotals:'Facturación {{billing}} · Preventa {{preventa}}', noSellers:'No hay vendedores que coincidan con estos filtros.', noData:'No hay datos disponibles para el periodo.', routeDays:'{{count}} días', detail:'Detalle', auditEyebrow:'TRANSPARENCIA', auditTitle:'Origen y control de datos', auditNote:'Las verificaciones explican el origen de los importes y mantienen las excepciones visibles.', auditSourceTitle:'Fuente financiera oficial', auditSourceBody:'Los KPI financieros se toman de VENTAS CONSOLIDADO. Las hojas diarias ayudan a identificar vendedores y contrastar datos.', auditReconTitle:'Conciliación completada', auditReconBody:'La preventa asignada a vendedores coincide con el control oficial. La facturación restante se muestra como ajuste sin asignar.', auditLabelsTitle:'Etiquetas de vendedor corregidas', auditLabelsBody:'{{details}}', auditVarianceTitle:'Diferencia frente a hoja diaria', auditVarianceBody:'Ruta {{route}} · {{date}}: consolidado {{official}}; hoja diaria {{daily}}. No modifica los KPI oficiales.', auditExtraTitle:'Ruta fuera del consolidado', auditExtraBody:'Ruta {{route}} · {{seller}} · {{amount}}. Se mantiene fuera de los KPI oficiales.', auditMixTitle:'Fórmulas con más de un origen', auditMixBody:'Ruta {{route}} combina columnas {{sources}} en las fórmulas de facturación; el importe mostrado sigue siendo el valor oficial del consolidado.', sellerDetail:'DETALLE DE VENDEDOR', close:'Cerrar', closeDetail:'Cerrar detalle de vendedor', routePreventaShort:'Preventa', routeBillingShort:'Facturación', routeDiffShort:'Diferencia', routeCompletionShort:'Cumplimiento', detailDataNote:'Este detalle suma los registros del vendedor por día. Las diferencias con otras hojas se documentan en Auditoría.', date:'Fecha', ready:'Listo', updating:'Actualizando…', updatedAt:'Actualizado · {{time}}', verified:'Datos verificados', checkingData:'Leyendo datos locales', loadIssue:'Revisar datos locales', loadError:'No se pudieron cargar los datos locales. Consulta el detalle del error y vuelve a actualizar.', copied:'Enlace copiado', shareFailed:'No se pudo compartir el enlace.', csvSaved:'Descargando el consolidado oficial en CSV.', dataCountDays:'{{count}} días con datos · {{routes}} vendedores', missingApi:'EMA MAYOREO no pudo leer sus datos locales.'
  },
  en: {
    skipContent:'Skip to content', mainNavigation:'Main navigation', sectionsNavigation:'Sections', brandHome:'EMA MAYOREO home', appDescription:'EMA MAYOREO executive dashboard for sales, billing, and routes.', brandSubtitle:'Executive dashboard', navOverview:'Overview', navAnalysis:'Analysis', navRoutes:'Routes', navAudit:'Audit', sourceLabel:'FINANCIAL SOURCE', sourceNote:'The dashboard takes official amounts from this worksheet.', loading:'Loading…', pageEyebrow:'EXECUTIVE DASHBOARD', pageTitle:'Sales and billing', loadingPeriod:'Loading period…', languageLabel:'Language', checking:'Checking', refresh:'Refresh', fullscreen:'Full screen', exitFullscreen:'Exit full screen', heroEyebrow:'A CLEAR VIEW OF OPERATIONS', heroTitle:'Every number in context.', heroDescription:'Explore sales, daily trends, and route performance, with adjustments clearly separated.', viewRoutes:'Explore routes', printSummary:'Print summary', shareLink:'Share link', officialDifference:'OFFICIAL DIFFERENCE', differenceCaption:'Billing minus presales, based on the official control.', officialCompletion:'Official completion', qualityOk:'Reconciled', qualityReview:'Review figures', mainMetrics:'Key metrics', kpiBilling:'Official billing', kpiBillingNote:'Includes {{amount}} in official unassigned adjustments.', kpiPreventa:'Consolidated presales', kpiPreventaNote:'{{count}} routes included in the consolidated sheet.', kpiCompletion:'Completion', kpiCompletionNote:'Billing divided by presales.', kpiDifference:'Official difference', kpiDifferenceNote:'Billing minus presales.', keyHighlights:'Key highlights', bestRegionLabel:'REGION WITH HIGHEST BILLING', bestRegionNote:'{{amount}} billed', topRoute:'ROUTE WITH HIGHEST BILLING', topSellerNote:'{{amount}} facturados', attentionRoute:'LARGEST ROUTE GAP', attentionRouteNote:'{{amount}} vs. presales', activeDaysLabel:'DAYS IN PERIOD', activeDaysCaption:'With activity in the consolidated sheet', trendEyebrow:'TREND', trendTitle:'Presales and billing', trendNote:'Daily amounts for the official period.', preventa:'Presales', billing:'Billing', trendChartLabel:'Daily presales and billing trend', regionEyebrow:'DISTRIBUTION', regionTitle:'Billing by region', regionNote:'Share of the route total.', regionPreventa:'Presales {{amount}}', reconciliationEyebrow:'FINANCIAL CONTROL', reconciliationTitle:'Figures reconciliation', reconciliationNote:'The official total retains unassigned adjustments.', routePreventa:'Presales from {{count}} routes', routeBilling:'Billing from {{count}} routes', routeAdjustments:'Official unassigned adjustments', officialBilling:'Official billing', officialPreventa:'Official presales', officialDiff:'Official difference', reconciliationCallout:'The {{amount}} adjustment is not assigned to sellers. It stays separate to reconcile the official total.', focusEyebrow:'EXECUTIVE READOUT', focusTitle:'What to look at', focusNote:'A few cues for reading the dashboard.', focusOneTitle:'Use the official total as the reference', focusOneBody:'Official billing includes unassigned adjustments; the dashboard shows them separately.', focusTwoTitle:'Compare each route with its presales', focusTwoBody:'The table summarizes the {{count}} included routes and shows their difference and completion.', focusThreeTitle:'Exceptions stay visible', focusThreeBody:'Source differences are documented in Audit and are not included in the KPIs.', routesEyebrow:'PERFORMANCE', routesTitle:'Route detail', routesNote:'The table includes only consolidated routes; the unassigned adjustment remains separate.', searchPlaceholder:'Search route, seller, or region', searchLabel:'Search route, seller, or region', allRegions:'All regions', filterRegionLabel:'Filter by region', sortRoutesLabel:'Sort routes', sortBilling:'Highest billing', sortGap:'Largest gap', sortCompletion:'Highest completion', sortRoute:'Route A–Z', downloadCsv:'Download CSV', clearFilters:'Clear', scrollTable:'Scroll table horizontally to view more columns', route:'Route', seller:'Seller', region:'Region', difference:'Difference', completion:'Completion', rowActions:'Actions', showingRoutes:'Showing {{shown}} of {{total}} routes', filteredTotals:'Billing {{billing}} · Presales {{preventa}}', noRoutes:'No routes match these filters.', noData:'No data available for this period.', routeDays:'{{count}} days', detail:'Details', auditEyebrow:'TRANSPARENCY', auditTitle:'Data source and controls', auditNote:'Checks explain where amounts come from and keep exceptions visible.', auditSourceTitle:'Official financial source', auditSourceBody:'Financial KPIs come from VENTAS CONSOLIDADO. Daily sheets identify routes and provide cross-checks.', auditReconTitle:'Reconciliation complete', auditReconBody:'Route presales match the official control. Remaining billing is identified as an unassigned adjustment.', auditLabelsTitle:'Seller labels corrected', auditLabelsBody:'{{details}}', auditVarianceTitle:'Difference versus daily sheet', auditVarianceBody:'Route {{route}} · {{date}}: consolidated {{official}}; daily sheet {{daily}}. Official KPIs are unchanged.', auditExtraTitle:'Route outside the consolidated sheet', auditExtraBody:'Route {{route}} · {{seller}} · {{amount}}. Excluded from official KPIs.', auditMixTitle:'Formulas use multiple sources', auditMixBody:'Route {{route}} combines columns {{sources}} in billing formulas; the displayed amount remains the official consolidated value.', routeDetail:'ROUTE DETAIL', close:'Close', closeDetail:'Close route detail', routePreventaShort:'Presales', routeBillingShort:'Billing', routeDiffShort:'Difference', routeCompletionShort:'Completion', detailDataNote:'This detail uses the consolidated records for this route. Differences against other sheets are documented in Audit.', date:'Date', ready:'Ready', updating:'Updating…', updatedAt:'Updated · {{time}}', verified:'Data verified', checkingData:'Connecting to data', loadIssue:'Connection issue', loadError:'Could not load data. Check that the dashboard is running and try again.', copied:'Link copied', shareFailed:'Could not share the link.', csvSaved:'Downloading the visible route detail as CSV.', dataCountDays:'{{count}} days with data · {{routes}} official routes', missingApi:'Could not read dashboard data.'
  },
  pt: {
    skipContent:'Pular para o conteúdo', mainNavigation:'Navegação principal', sectionsNavigation:'Seções', brandHome:'EMA MAYOREO, início', appDescription:'Painel executivo de vendas, faturamento e rotas da EMA MAYOREO.', brandSubtitle:'Painel executivo', navOverview:'Resumo', navAnalysis:'Análise', navRoutes:'Rotas', navAudit:'Auditoria', sourceLabel:'FONTE FINANCEIRA', sourceNote:'Os valores oficiais do painel vêm desta planilha.', loading:'Carregando…', pageEyebrow:'PAINEL EXECUTIVO', pageTitle:'Vendas e faturamento', loadingPeriod:'Carregando período…', languageLabel:'Idioma', checking:'Verificando', refresh:'Atualizar', fullscreen:'Tela cheia', exitFullscreen:'Sair da tela cheia', heroEyebrow:'UMA VISÃO CLARA DA OPERAÇÃO', heroTitle:'Cada número em seu contexto.', heroDescription:'Consulte as vendas, a evolução diária e o desempenho por rota, com os ajustes separados.', viewRoutes:'Explorar rotas', printSummary:'Imprimir resumo', shareLink:'Compartilhar link', officialDifference:'DIFERENÇA OFICIAL', differenceCaption:'Faturamento menos pré-venda, conforme o controle oficial.', officialCompletion:'Cumprimento oficial', qualityOk:'Conciliado', qualityReview:'Revisar valores', mainMetrics:'Indicadores principais', kpiBilling:'Faturamento oficial', kpiBillingNote:'Inclui {{amount}} em ajustes oficiais sem rota.', kpiPreventa:'Pré-venda consolidada', kpiPreventaNote:'{{count}} rotas incluídas no consolidado.', kpiCompletion:'Cumprimento', kpiCompletionNote:'Faturamento dividido pela pré-venda.', kpiDifference:'Diferença oficial', kpiDifferenceNote:'Faturamento menos pré-venda.', keyHighlights:'Destaques', bestRegionLabel:'REGIÃO COM MAIOR FATURAMENTO', bestRegionNote:'{{amount}} faturados', topRoute:'ROTA COM MAIOR FATURAMENTO', topSellerNote:'{{amount}} facturados', attentionRoute:'MAIOR DIFERENÇA POR ROTA', attentionRouteNote:'{{amount}} em relação à pré-venda', activeDaysLabel:'DIAS DO PERÍODO', activeDaysCaption:'Com atividade no consolidado', trendEyebrow:'TENDÊNCIA', trendTitle:'Pré-venda e faturamento', trendNote:'Valores diários do período oficial.', preventa:'Pré-venda', billing:'Faturamento', trendChartLabel:'Tendência diária de pré-venda e faturamento', regionEyebrow:'DISTRIBUIÇÃO', regionTitle:'Faturamento por região', regionNote:'Participação no total das rotas.', regionPreventa:'Pré-venda {{amount}}', reconciliationEyebrow:'CONTROLE FINANCEIRO', reconciliationTitle:'Conciliação dos valores', reconciliationNote:'O total oficial mantém os ajustes sem rota.', routePreventa:'Pré-venda das {{count}} rotas', routeBilling:'Faturamento das {{count}} rotas', routeAdjustments:'Ajustes oficiais sem rota', officialBilling:'Faturamento oficial', officialPreventa:'Pré-venda oficial', officialDiff:'Diferença oficial', reconciliationCallout:'O ajuste de {{amount}} não é atribuído aos vendedores. Ele fica separado para conciliar o total oficial.', focusEyebrow:'LEITURA EXECUTIVA', focusTitle:'O que observar', focusNote:'Pontos para interpretar os dados do painel.', focusOneTitle:'Use o total oficial como referência', focusOneBody:'O faturamento oficial inclui ajustes sem rota; o painel os mostra separadamente.', focusTwoTitle:'Compare cada rota com sua pré-venda', focusTwoBody:'A tabela resume as {{count}} rotas incluídas e mostra diferença e cumprimento.', focusThreeTitle:'As exceções permanecem visíveis', focusThreeBody:'Diferenças de origem são descritas na Auditoria e não entram nos KPIs.', routesEyebrow:'DESEMPENHO', routesTitle:'Detalhe por rota', routesNote:'A tabela inclui apenas as rotas do consolidado; o ajuste sem rota permanece separado.', searchPlaceholder:'Buscar rota, vendedor ou região', searchLabel:'Buscar rota, vendedor ou região', allRegions:'Todas as regiões', filterRegionLabel:'Filtrar por região', sortRoutesLabel:'Ordenar rotas', sortBilling:'Maior faturamento', sortGap:'Maior diferença', sortCompletion:'Maior cumprimento', sortRoute:'Rota A–Z', downloadCsv:'Baixar CSV', clearFilters:'Limpar', scrollTable:'Role a tabela horizontalmente para ver mais colunas', route:'Rota', seller:'Vendedor', region:'Região', difference:'Diferença', completion:'Cumprimento', rowActions:'Ações', showingRoutes:'Exibindo {{shown}} de {{total}} rotas', filteredTotals:'Faturamento {{billing}} · Pré-venda {{preventa}}', noRoutes:'Nenhuma rota corresponde a estes filtros.', noData:'Não há dados disponíveis para este período.', routeDays:'{{count}} dias', detail:'Detalhes', auditEyebrow:'TRANSPARÊNCIA', auditTitle:'Origem e controle dos dados', auditNote:'As verificações explicam a origem dos valores e mantêm as exceções visíveis.', auditSourceTitle:'Fonte financeira oficial', auditSourceBody:'Os KPIs financeiros vêm de VENTAS CONSOLIDADO. As planilhas diárias identificam rotas e servem para conferência.', auditReconTitle:'Conciliação concluída', auditReconBody:'A pré-venda das rotas coincide com o controle oficial. O faturamento restante é identificado como ajuste sem rota.', auditLabelsTitle:'Nomes de vendedores corrigidos', auditLabelsBody:'{{details}}', auditVarianceTitle:'Diferença em relação à planilha diária', auditVarianceBody:'Rota {{route}} · {{date}}: consolidado {{official}}; planilha diária {{daily}}. Os KPIs oficiais não mudam.', auditExtraTitle:'Rota fora do consolidado', auditExtraBody:'Rota {{route}} · {{seller}} · {{amount}}. Excluída dos KPIs oficiais.', auditMixTitle:'Fórmulas com mais de uma origem', auditMixBody:'A rota {{route}} combina as colunas {{sources}} nas fórmulas de faturamento; o valor exibido continua sendo o oficial do consolidado.', routeDetail:'DETALHE DA ROTA', close:'Fechar', closeDetail:'Fechar detalhes da rota', routePreventaShort:'Pré-venda', routeBillingShort:'Faturamento', routeDiffShort:'Diferença', routeCompletionShort:'Cumprimento', detailDataNote:'Este detalhe usa os registros do consolidado para esta rota. Diferenças com outras planilhas estão documentadas na Auditoria.', date:'Data', ready:'Pronto', updating:'Atualizando…', updatedAt:'Atualizado · {{time}}', verified:'Dados verificados', checkingData:'Conectando aos dados', loadIssue:'Verifique a conexão', loadError:'Não foi possível carregar os dados. Confira se o painel está iniciado e tente novamente.', copied:'Link copiado', shareFailed:'Não foi possível compartilhar o link.', csvSaved:'Baixando os detalhes visíveis das rotas em CSV.', dataCountDays:'{{count}} dias com dados · {{routes}} rotas oficiais', missingApi:'Não foi possível ler os dados do painel.'
  }
};

const extraTranslations = {
  es: {
    heroEyebrow:'RESUMEN DEL PERIODO', heroTitle:'Tus ventas, claras y bajo control.', heroDescription:'Compara preventa y facturación, revisa el resultado por vendedor y consulta por separado los ajustes no asignados.',
    navMap:'Mapa', viewMap:'Ver mapa', mapEyebrow:'COBERTURA GEOGRÁFICA', mapTitle:'Mapa de ubicaciones', mapNote:'Explora los centros urbanos de referencia y compara las regiones del panel.',
    mapMeasure:'Tamaño por', mapBilling:'Facturación', mapPreventa:'Preventa', mapSellers:'Vendedores', mapSellerCount:'{{count}} vendedores', mapExport:'Descargar ubicaciones', mapPointsLabel:'Puntos geográficos de referencia', mapOffline:'MAPA LOCAL · SIN DEPENDENCIAS EXTERNAS',
    mapSelected:'REGIÓN SELECCIONADA', mapCenter:'Centro urbano de referencia', mapCoordinates:'LATITUD · LONGITUD', mapFilterSellers:'Ver vendedores de la región', mapGoogle:'Google Maps', mapOpenStreet:'OpenStreetMap', mapCopyCoordinates:'Copiar coordenadas', mapRegions:'REGIONES DEL PANEL',
    mapDisclaimer:'El consolidado no incluye coordenadas de cada ruta o vendedor. Los puntos son centros urbanos aproximados, no ubicaciones GPS en vivo ni recorridos reales. El contorno del país es ilustrativo.',
    mapRegionHeader:'Región', mapCityHeader:'Centro urbano', mapLatHeader:'Latitud', mapLonHeader:'Longitud', mapSourceHeader:'Fuente', mapSourceUrlHeader:'Referencia de ubicación', mapCsvSaved:'Descargando ubicaciones de referencia en CSV.', mapCoordinatesCopied:'Coordenadas copiadas.', mapNoLocations:'No hay ubicaciones disponibles.',
    trendModeLabel:'Vista de la gráfica', trendAmount:'Importes', trendDifference:'Diferencia', trendCompletion:'Cumplimiento', trendNote:'Cambia entre importes, diferencia y cumplimiento diario.', trendPrompt:'Enfoca o pasa el cursor por un punto para consultar ese día.', trendDay:'Día', trendBillingValue:'Facturación', trendPreventaValue:'Preventa', trendDifferenceValue:'Diferencia', trendCompletionValue:'Cumplimiento', trendTarget:'Meta 100%',
    regionTitle:'Preventa y facturación por región', regionNote:'Compara ambos importes y el cumplimiento en cada región.', regionBillingShort:'F', regionPreventaShort:'P', regionCompletion:'Cumplimiento {{value}}',
    downloadFilteredCsv:'Descargar vendedores visibles', csvFilteredSaved:'Descargando los vendedores filtrados en CSV.', csvSaved:'Descargando el CSV oficial completo.',
    welcomeEyebrow:'EMA MAYOREO · PANEL EJECUTIVO', welcomeTitle:'Tu operación, en otro nivel.', welcomeDescription:'Consulta las cifras del periodo, compara vendedores y revisa por separado los ajustes no asignados.', welcomeEnter:'Entrar al panel',
    dataToolsEyebrow:'ARCHIVOS DEL PANEL', dataToolsTitle:'Administra los archivos del panel', dataToolsDescription:'Cada carga mensual se guarda en Historial con su Excel original y sus datos procesados. Desde aquí puedes descargar el libro del mes que estás consultando.', downloadDatabase:'Descargar base de datos', downloadSourceExcel:'Descargar Excel original', importExcel:'Insertar archivo Excel', importRequirements:'El nombre y la extensión del archivo no determinan su contenido. Se valida el libro XLSX por dentro · Máximo 30 MB.', importNeedsPython:'Para importar, inicia el panel con Python 3 y openpyxl. Las descargas siguen disponibles.', importConfirm:'El Excel se guardará como un nuevo periodo después de validar «{{filename}}». ¿Quieres continuar?', importWorking:'Validando el libro y guardando el periodo…', importDone:'Periodo guardado: {{filename}} · {{sellers}} vendedores · {{rows}} registros.', importTooLarge:'El archivo supera el límite de 30 MB.', importWrongType:'El archivo no contiene un libro Excel XLSX válido. Se revisa el contenido, no el nombre.', importFailed:'No se pudo guardar el periodo. Los datos anteriores se conservaron.'
  },
  en: {
    heroEyebrow:'COMMERCIAL COMMAND CENTER', heroTitle:'Move operations. Drive results.', heroDescription:'Review period results, compare regions, and find the detail for each route.',
    navMap:'Map', viewMap:'Open map', mapEyebrow:'GEOGRAPHIC COVERAGE', mapTitle:'Location map', mapNote:'Explore reference city centers and compare the regions in the dashboard.',
    mapMeasure:'Size by', mapBilling:'Billing', mapPreventa:'Presales', mapRoutes:'Routes', mapRouteCount:'{{count}} routes', mapExport:'Download locations', mapPointsLabel:'Geographic reference points', mapOffline:'LOCAL MAP · NO EXTERNAL DEPENDENCIES',
    mapSelected:'SELECTED REGION', mapCenter:'Reference city center', mapCoordinates:'LATITUDE · LONGITUDE', mapFilterRoutes:'Filter routes in this region', mapGoogle:'Google Maps', mapOpenStreet:'OpenStreetMap', mapCopyCoordinates:'Copy coordinates', mapRegions:'DASHBOARD REGIONS',
    mapDisclaimer:'The sales file has no coordinates for individual routes or sellers. Markers show approximate city centers, not live GPS positions or actual routes. The country outline is illustrative.',
    mapRegionHeader:'Region', mapCityHeader:'City center', mapLatHeader:'Latitude', mapLonHeader:'Longitude', mapSourceHeader:'Source', mapSourceUrlHeader:'Location reference', mapCsvSaved:'Downloading reference locations as CSV.', mapCoordinatesCopied:'Coordinates copied.', mapNoLocations:'No locations are available.',
    trendModeLabel:'Chart view', trendAmount:'Amounts', trendDifference:'Difference', trendCompletion:'Completion', trendNote:'Switch between daily amounts, difference, and completion.', trendPrompt:'Focus or hover over a point to inspect that day.', trendDay:'Day', trendBillingValue:'Billing', trendPreventaValue:'Presales', trendDifferenceValue:'Difference', trendCompletionValue:'Completion', trendTarget:'100% target',
    regionTitle:'Presales and billing by region', regionNote:'Compare both amounts and completion in each region.', regionBillingShort:'B', regionPreventaShort:'P', regionCompletion:'Completion {{value}}',
    downloadFilteredCsv:'Download visible routes', csvFilteredSaved:'Downloading the filtered routes as CSV.', csvSaved:'Downloading the complete official CSV.',
    welcomeEyebrow:'EMA MAYOREO · EXECUTIVE DASHBOARD', welcomeTitle:'Take your operation further.', welcomeDescription:'Review period performance, compare regions, and find every route in one place.', welcomeEnter:'Enter dashboard',
    dataToolsEyebrow:'DASHBOARD FILES', dataToolsTitle:'Manage your database', dataToolsDescription:'Download the SQLite database or official Excel workbook. Import a compatible workbook to rebuild and update the dashboard.', downloadDatabase:'Download database', downloadSourceExcel:'Download original Excel', importExcel:'Import Excel file', importRequirements:'The file name and extension do not determine its content. The XLSX workbook is validated internally · 30 MB maximum.', importNeedsPython:'To import, start the dashboard with Python 3 and openpyxl. Downloads remain available.', importConfirm:'The local data will be replaced after «{{filename}}» is validated. Continue?', importWorking:'Validating the workbook and rebuilding the dashboard…', importDone:'Import complete: {{filename}} · {{routes}} routes · {{rows}} records.', importTooLarge:'The file exceeds the 30 MB limit.', importWrongType:'The file does not contain a valid XLSX workbook. The contents, not the name, are checked.', importFailed:'The file could not be imported. Current data was preserved.'
  },
  pt: {
    heroEyebrow:'CENTRAL DE OPERAÇÕES COMERCIAIS', heroTitle:'Sua operação. Novos resultados.', heroDescription:'Confira o resultado do período, compare as regiões e consulte cada rota em um só lugar.',
    navMap:'Mapa', viewMap:'Ver mapa', mapEyebrow:'COBERTURA GEOGRÁFICA', mapTitle:'Mapa de locais', mapNote:'Explore os centros urbanos de referência e compare as regiões do painel.',
    mapMeasure:'Tamanho por', mapBilling:'Faturamento', mapPreventa:'Pré-venda', mapRoutes:'Rotas', mapRouteCount:'{{count}} rotas', mapExport:'Baixar locais', mapPointsLabel:'Pontos geográficos de referência', mapOffline:'MAPA LOCAL · SEM DEPENDÊNCIAS EXTERNAS',
    mapSelected:'REGIÃO SELECIONADA', mapCenter:'Centro urbano de referência', mapCoordinates:'LATITUDE · LONGITUDE', mapFilterRoutes:'Filtrar rotas da região', mapGoogle:'Google Maps', mapOpenStreet:'OpenStreetMap', mapCopyCoordinates:'Copiar coordenadas', mapRegions:'REGIÕES DO PAINEL',
    mapDisclaimer:'O consolidado não inclui coordenadas de cada rota ou vendedor. Os pontos indicam centros urbanos aproximados, não posições GPS ao vivo nem trajetos reais. O contorno do país é ilustrativo.',
    mapRegionHeader:'Região', mapCityHeader:'Centro urbano', mapLatHeader:'Latitude', mapLonHeader:'Longitude', mapSourceHeader:'Fonte', mapSourceUrlHeader:'Referência de localização', mapCsvSaved:'Baixando locais de referência em CSV.', mapCoordinatesCopied:'Coordenadas copiadas.', mapNoLocations:'Não há locais disponíveis.',
    trendModeLabel:'Visualização do gráfico', trendAmount:'Valores', trendDifference:'Diferença', trendCompletion:'Cumprimento', trendNote:'Alterne entre valores diários, diferença e cumprimento.', trendPrompt:'Foque ou passe o cursor sobre um ponto para consultar o dia.', trendDay:'Dia', trendBillingValue:'Faturamento', trendPreventaValue:'Pré-venda', trendDifferenceValue:'Diferença', trendCompletionValue:'Cumprimento', trendTarget:'Meta de 100%',
    regionTitle:'Pré-venda e faturamento por região', regionNote:'Compare os valores e o cumprimento de cada região.', regionBillingShort:'F', regionPreventaShort:'P', regionCompletion:'Cumprimento {{value}}',
    downloadFilteredCsv:'Baixar rotas exibidas', csvFilteredSaved:'Baixando as rotas filtradas em CSV.', csvSaved:'Baixando o CSV oficial completo.',
    welcomeEyebrow:'EMA MAYOREO · PAINEL EXECUTIVO', welcomeTitle:'Sua operação em outro nível.', welcomeDescription:'Confira o desempenho do período, compare as regiões e consulte cada rota em um só lugar.', welcomeEnter:'Entrar no painel',
    dataToolsEyebrow:'ARQUIVOS DO PAINEL', dataToolsTitle:'Gerencie sua base de dados', dataToolsDescription:'Baixe o banco SQLite ou o Excel oficial. Importe uma planilha compatível para reconstruir e atualizar o painel.', downloadDatabase:'Baixar banco de dados', downloadSourceExcel:'Baixar Excel original', importExcel:'Inserir arquivo Excel', importRequirements:'O nome e a extensão não determinam o conteúdo. O arquivo XLSX é validado por dentro · Máximo de 30 MB.', importNeedsPython:'Para importar, inicie o painel com Python 3 e openpyxl. Os downloads continuam disponíveis.', importConfirm:'Os dados locais serão substituídos após validar «{{filename}}». Deseja continuar?', importWorking:'Validando a planilha e reconstruindo o painel…', importDone:'Importação concluída: {{filename}} · {{routes}} rotas · {{rows}} registros.', importTooLarge:'O arquivo ultrapassa o limite de 30 MB.', importWrongType:'O arquivo não contém uma planilha XLSX válida. O conteúdo é validado, não o nome.', importFailed:'Não foi possível importar o arquivo. Os dados atuais foram preservados.'
  }
};
Object.keys(extraTranslations).forEach(language=>Object.assign(translations[language],extraTranslations[language]));
Object.assign(translations.es,{
  brandSubtitle:'Centro de inteligencia',
  dataToolsDescription:'Descarga la base activa, agrega una SQLite compatible o reemplaza los datos desde un Excel oficial. Borrar la base deja el panel vacío hasta cargar otra.',
  addDatabase:'Agregar base SQLite',replaceWithExcel:'Reemplazar base con Excel',deleteDatabase:'Borrar base activa',
  managementReady:'SQLite .db con tabla rows compatible o Excel .xlsx oficial · Máximo 30 MB.',
  managementNeedsPython:'No se pudo iniciar el procesador local de EMA. Cierra y vuelve a abrir la aplicación.',
  excelNeedsPython:'Para reemplazar desde Excel, inicia el panel con Python 3 y openpyxl. La carga SQLite sigue disponible.',
  databaseEmpty:'No hay una base activa. Agrega una SQLite compatible o importa un Excel oficial.',
  databaseImportConfirm:'Se reemplazarán los datos actuales con «{{filename}}». El Excel de origen actual se quitará. ¿Continuar?',
  databaseDeleteConfirm:'Se borrarán la base activa y el Excel de origen. El panel quedará vacío hasta que cargues otra base. Descarga una copia antes si necesitas conservarla. ¿Borrar?',
  databaseWorking:'Validando la base SQLite y reconstruyendo el panel…',
  databaseImported:'Base agregada: {{filename}} · {{sellers}} vendedores · {{rows}} registros.',
  databaseDeleted:'Base borrada. El panel está vacío y listo para recibir otra base.',
  databaseWrongType:'Selecciona un archivo .db, .sqlite o .sqlite3.',
  databaseTooLarge:'La base supera el límite de 30 MB.',
  databaseImportFailed:'No se pudo validar la base. Los datos actuales se conservaron.',
  databaseDeleteFailed:'No se pudo borrar la base. Los datos actuales se conservaron.',
  workbookSourceName:'VENTAS CONSOLIDADO',databaseSourceName:'BASE SQLITE IMPORTADA',
  sourceDatabaseNote:'El panel resume los registros validados de la tabla rows.',differenceLabelImported:'DIFERENCIA EN BASE',
  differenceCaptionImported:'Facturación menos preventa, según la base importada.',completionImported:'Cumplimiento en base',
  trendNoteImported:'Importes diarios registrados en la base activa.',routesNoteImported:'La tabla suma por vendedor los registros de la base activa.',
  reconciliationNoteImported:'Los totales se calculan desde las filas SQLite importadas; no incluyen ajustes fuera de esa tabla.',
  auditNoteImported:'La base SQLite se validó y el panel resume su tabla rows. No se importó el libro Excel de origen.',
  kpiBillingImported:'Facturación en base',kpiPreventaImported:'Preventa en base',kpiCompletionImported:'Cumplimiento',kpiDifferenceImported:'Diferencia en base',
  kpiBillingImportedNote:'Suma de filas importadas.',kpiPreventaImportedNote:'Importes de {{count}} vendedores en la base.',
  reconciliationCalloutImported:'No hay ajustes externos en la tabla rows; solo se muestran los importes de sus registros.',
  focusOneTitleImported:'Totales desde registros importados',focusOneBodyImported:'Los indicadores resumen las filas de la tabla rows.',
  focusTwoTitleImported:'Revisa los vendedores de la base',focusTwoBodyImported:'La tabla suma por vendedor los registros disponibles.',
  focusThreeTitleImported:'La base no incluye el Excel de origen',focusThreeBodyImported:'Se muestran los datos disponibles en SQLite, sin auditorías de otras hojas.',
  auditDatabaseSourceTitle:'Base SQLite importada',auditDatabaseSourceBody:'Los importes por vendedor se construyen con los registros validados de la base.',
  auditDatabaseReconTitle:'Totales derivados de la base',auditDatabaseReconBody:'La diferencia es facturación menos preventa. No se sumaron ajustes que no existan en la base.',
  dataCountDaysImported:'{{count}} días con datos · {{routes}} vendedores',csvSaved:'Descargando el CSV completo.',
  routeAdjustmentsImported:'Ajustes externos (no incluidos)',databaseBilling:'Facturación de la base',databasePreventa:'Preventa de la base',databaseDifference:'Diferencia de la base',
  activeDaysCaptionImported:'Días con registros en la base',mapDisclaimerImported:'La base no incluye coordenadas de vendedores o rutas. Los puntos del mapa son centros urbanos de referencia, no ubicaciones en vivo.',
  detailDataNoteImported:'Este detalle suma los registros SQLite del vendedor por día. La base no incluye auditorías del Excel de origen.'
});
Object.assign(translations.en,{
  brandSubtitle:'Command center',
  dataToolsDescription:'Download the active database, add a compatible SQLite file, or replace the data from an official Excel workbook. Deleting the database leaves an empty dashboard until another is loaded.',
  addDatabase:'Add SQLite database',replaceWithExcel:'Replace with Excel',deleteDatabase:'Delete active database',
  managementReady:'Compatible SQLite .db with a rows table, or official .xlsx workbook · 30 MB maximum.',
  managementNeedsPython:'Database management requires starting the dashboard with Python 3. The Windows server can still display data.',
  excelNeedsPython:'To replace data from Excel, start with Python 3 and openpyxl. SQLite upload remains available.',
  databaseEmpty:'No active database. Add a compatible SQLite file or import an official Excel workbook.',
  databaseImportConfirm:'Current data will be replaced with «{{filename}}» and the current source Excel will be removed. Continue?',
  databaseDeleteConfirm:'The active database and source Excel will be deleted. The dashboard will stay empty until you load another database. Download a copy first if you need it. Delete?',
  databaseWorking:'Validating the SQLite database and rebuilding the dashboard…',
  databaseImported:'Database added: {{filename}} · {{routes}} routes · {{rows}} records.',
  databaseDeleted:'Database deleted. The dashboard is empty and ready for another database.',
  databaseWrongType:'Choose a .db, .sqlite, or .sqlite3 file.',
  databaseTooLarge:'The database exceeds the 30 MB limit.',
  databaseImportFailed:'The database could not be validated. Current data was preserved.',
  databaseDeleteFailed:'The database could not be deleted. Current data was preserved.',
  workbookSourceName:'VENTAS CONSOLIDADO',databaseSourceName:'IMPORTED SQLITE DATABASE',
  sourceDatabaseNote:'The dashboard summarizes validated records from the rows table.',differenceLabelImported:'DATABASE DIFFERENCE',
  differenceCaptionImported:'Billing minus presales from the imported database.',completionImported:'Database completion',
  trendNoteImported:'Daily amounts recorded in the active database.',routesNoteImported:'The table shows routes and records from the active database.',
  reconciliationNoteImported:'Totals come from imported SQLite rows; adjustments outside that table are not included.',
  auditNoteImported:'The SQLite database was validated and the dashboard summarizes its rows table. No source workbook was imported.',
  kpiBillingImported:'Database billing',kpiPreventaImported:'Database presales',kpiCompletionImported:'Completion',kpiDifferenceImported:'Database difference',
  kpiBillingImportedNote:'Sum of imported rows.',kpiPreventaImportedNote:'{{count}} routes in the database.',
  reconciliationCalloutImported:'No external adjustments are included in rows; the panel shows the amounts found in its records.',
  focusOneTitleImported:'Totals from imported records',focusOneBodyImported:'The indicators summarize the rows table.',
  focusTwoTitleImported:'Review database routes',focusTwoBodyImported:'The table groups the routes found in the records.',
  focusThreeTitleImported:'The source Excel is not included',focusThreeBodyImported:'The panel shows SQLite data without audits from other worksheets.',
  auditDatabaseSourceTitle:'Imported SQLite database',auditDatabaseSourceBody:'Amounts and routes come from records in the rows table.',
  auditDatabaseReconTitle:'Totals derived from the database',auditDatabaseReconBody:'Difference is billing minus presales. No adjustments outside the database were added.',
  dataCountDaysImported:'{{count}} days with data · {{routes}} routes',csvSaved:'Downloading the complete CSV.',
  routeAdjustmentsImported:'External adjustments (not included)',databaseBilling:'Database billing',databasePreventa:'Database presales',databaseDifference:'Database difference',
  activeDaysCaptionImported:'Days with records in the database',mapDisclaimerImported:'The database has no seller or route coordinates. Map points are reference city centers, not live locations.',
  detailDataNoteImported:'This detail shows SQLite records for the route. The database has no audit comparisons against the source workbook.'
});
Object.assign(translations.pt,{
  brandSubtitle:'Central de inteligência',
  dataToolsDescription:'Baixe o banco ativo, adicione um SQLite compatível ou substitua os dados com uma planilha oficial. Ao excluir o banco, o painel fica vazio até carregar outro.',
  addDatabase:'Adicionar banco SQLite',replaceWithExcel:'Substituir com Excel',deleteDatabase:'Excluir banco ativo',
  managementReady:'SQLite .db compatível com uma tabela rows ou planilha .xlsx oficial · Máximo de 30 MB.',
  managementNeedsPython:'A gestão de bancos requer iniciar o painel com Python 3. O servidor do Windows ainda pode exibir os dados.',
  excelNeedsPython:'Para substituir os dados pelo Excel, inicie com Python 3 e openpyxl. O envio de SQLite continua disponível.',
  databaseEmpty:'Não há banco ativo. Adicione um SQLite compatível ou importe uma planilha oficial.',
  databaseImportConfirm:'Os dados atuais serão substituídos por «{{filename}}» e o Excel de origem atual será removido. Continuar?',
  databaseDeleteConfirm:'O banco ativo e o Excel de origem serão excluídos. O painel ficará vazio até carregar outro banco. Baixe uma cópia antes se precisar dela. Excluir?',
  databaseWorking:'Validando o SQLite e reconstruindo o painel…',
  databaseImported:'Banco adicionado: {{filename}} · {{routes}} rotas · {{rows}} registros.',
  databaseDeleted:'Banco excluído. O painel está vazio e pronto para receber outro banco.',
  databaseWrongType:'Selecione um arquivo .db, .sqlite ou .sqlite3.',
  databaseTooLarge:'O banco ultrapassa o limite de 30 MB.',
  databaseImportFailed:'Não foi possível validar o banco. Os dados atuais foram preservados.',
  databaseDeleteFailed:'Não foi possível excluir o banco. Os dados atuais foram preservados.',
  workbookSourceName:'VENTAS CONSOLIDADO',databaseSourceName:'BANCO SQLITE IMPORTADO',
  sourceDatabaseNote:'O painel resume os registros validados da tabela rows.',differenceLabelImported:'DIFERENÇA NO BANCO',
  differenceCaptionImported:'Faturamento menos pré-venda, segundo o banco importado.',completionImported:'Cumprimento no banco',
  trendNoteImported:'Valores diários registrados no banco ativo.',routesNoteImported:'A tabela mostra rotas e registros do banco ativo.',
  reconciliationNoteImported:'Os totais são calculados das linhas SQLite importadas; não incluem ajustes fora da tabela.',
  auditNoteImported:'O banco SQLite foi validado e o painel resume sua tabela rows. A planilha Excel de origem não foi importada.',
  kpiBillingImported:'Faturamento no banco',kpiPreventaImported:'Pré-venda no banco',kpiCompletionImported:'Cumprimento',kpiDifferenceImported:'Diferença no banco',
  kpiBillingImportedNote:'Soma das linhas importadas.',kpiPreventaImportedNote:'{{count}} rotas no banco.',
  reconciliationCalloutImported:'A tabela rows não inclui ajustes externos; o painel mostra os valores dos registros disponíveis.',
  focusOneTitleImported:'Totais dos registros importados',focusOneBodyImported:'Os indicadores resumem as linhas da tabela rows.',
  focusTwoTitleImported:'Confira as rotas do banco',focusTwoBodyImported:'A tabela agrupa as rotas encontradas nos registros.',
  focusThreeTitleImported:'O Excel de origem não está incluído',focusThreeBodyImported:'O painel mostra os dados SQLite, sem auditoria de outras planilhas.',
  auditDatabaseSourceTitle:'Banco SQLite importado',auditDatabaseSourceBody:'Os valores e as rotas vêm dos registros da tabela rows.',
  auditDatabaseReconTitle:'Totais calculados do banco',auditDatabaseReconBody:'A diferença é faturamento menos pré-venda. Não foram adicionados ajustes externos ao banco.',
  dataCountDaysImported:'{{count}} dias com dados · {{routes}} rotas',csvSaved:'Baixando o CSV completo.',
  routeAdjustmentsImported:'Ajustes externos (não incluídos)',databaseBilling:'Faturamento do banco',databasePreventa:'Pré-venda do banco',databaseDifference:'Diferença do banco',
  activeDaysCaptionImported:'Dias com registros no banco',mapDisclaimerImported:'O banco não contém coordenadas de vendedores ou rotas. Os pontos do mapa são centros urbanos de referência, não locais ao vivo.',
  detailDataNoteImported:'Este detalhe mostra os registros SQLite da rota. O banco não inclui auditorias da planilha Excel de origem.'
});

Object.assign(translations.es,{
  navSettings:'Configuración',collapseSidebar:'Contraer navegación',expandSidebar:'Expandir navegación',openNavigation:'Abrir navegación',closeNavigation:'Cerrar navegación',mobileNavigation:'Navegación rápida',moreSections:'Más secciones',more:'Más',
  commandOpen:'Comandos',commandEyebrow:'EMA MAYOREO · ACCIONES RÁPIDAS',commandTitle:'Centro de comandos',commandSearchLabel:'Buscar comando',commandPlaceholder:'Buscar una acción o sección…',commandResultsLabel:'Comandos disponibles',commandNavigate:'navegar',commandRun:'ejecutar',closeCommands:'Cerrar centro de comandos',commandNoResults:'No hay comandos que coincidan.',
  healthTitle:'ESTADO DEL SISTEMA',healthWaiting:'Esperando comprobación',healthBackend:'Procesador local',healthData:'Datos',healthDatabase:'Base de datos',healthAudit:'Auditoría',healthChecking:'VERIFICANDO',healthOnline:'DISPONIBLE',healthWarning:'ATENCIÓN',healthError:'ERROR',healthEmpty:'SIN DATOS',healthUpdated:'Comprobado · {{time}}',
  dataCoreLabel:'NÚCLEO DE DATOS · VENTAS CONSOLIDADO',dataCoreImported:'NÚCLEO DE DATOS · SQLITE VERIFICADA',settingsEyebrow:'PREFERENCIAS LOCALES',settingsTitle:'Configuración del centro',settingsDescription:'Ajusta la apariencia, la navegación y el movimiento de esta aplicación en este dispositivo.',
  appearanceTitle:'Apariencia',appearanceDescription:'Elige entre el entorno nocturno y el tema claro empresarial.',themeToggle:'Cambiar apariencia',themeLightAction:'Usar tema claro',themeDarkAction:'Usar tema oscuro',navigationDensityTitle:'Navegación compacta',navigationDensityDescription:'Reduce o amplía la barra lateral en pantallas grandes.',
  motionTitle:'Movimiento reducido',motionDescription:'La entrada animada y los revelados están activos; puedes reducirlos aquí.',motionSystemActiveNote:'El sistema pidió menos movimiento; las animaciones siguen activas porque las pediste. Puedes reducirlas aquí.',motionSystemReducedNote:'El panel está respetando el movimiento reducido que elegiste.',motionReduceAction:'Reducir movimiento',motionRestoreAction:'Permitir movimiento',shortcutsTitle:'Atajos de teclado',shortcutCommands:'Abrir comandos',shortcutSearch:'Buscar ruta',shortcutRefresh:'Actualizar',shortcutClose:'Cerrar panel',showCommands:'Ver comandos',welcomeReady:'DATOS VERIFICADOS',welcomeEmpty:'SISTEMA LISTO · SIN DATOS CARGADOS',refreshSuccess:'Los datos se actualizaron correctamente.',
  pageEyebrow:'EMA MAYOREO · RESUMEN EJECUTIVO',pageTitle:'Resumen ejecutivo de ventas',heroEyebrow:'RESUMEN DEL PERIODO',heroTitle:'Tus ventas, claras y bajo control.',heroDescription:'Compara preventa y facturación, revisa el resultado por vendedor y consulta por separado los ajustes no asignados.',welcomeTitle:'EMA MAYOREO. Operación bajo control.',welcomeDescription:'Consulta las cifras del periodo, compara vendedores y revisa por separado los ajustes no asignados.',welcomeEnter:'Entrar al centro',kpiSparklineHint:'Serie diaria · {{amount}}',kpiRouteDifferenceHint:'Diferencia diaria oficial',kpiCompletionSparkHint:'Cumplimiento diario · {{count}} fechas',fullscreenFailed:'El navegador no permitió activar pantalla completa.'
});

Object.assign(translations.es,{
  dataToolsTitle:'Administra los archivos del panel',
  dataToolsDescription:'Cada carga mensual se guarda en Historial con su Excel original y sus datos procesados. Desde aquí puedes descargar el libro del mes que estás consultando.',
  replaceWithExcel:'Ir al historial mensual',
  deleteDatabase:'Borrar copia inicial',
  managementReady:'Los periodos guardados en Historial se conservan.',
  managementNeedsPython:'No se pudo iniciar el servicio local de datos. Cierra y vuelve a abrir la aplicación.',
  excelNeedsPython:'La aplicación necesita su componente de importación. Reinstala EMA MAYOREO y vuelve a intentarlo.',
  databaseEmpty:'No hay datos activos. Carga un Excel oficial para empezar.',
  databaseDeleteConfirm:'Se borrará la copia inicial de datos y su Excel. Los meses guardados en Historial no se borrarán y seguirán disponibles en el panel. ¿Borrar la copia inicial?',
  databaseWorking:'Actualizando los datos del panel…',
  databaseDeleted:'Se borró la copia inicial. Los periodos guardados en Historial siguen disponibles.',
  databaseDeleteFailed:'No se pudieron borrar los datos. Los archivos actuales se conservaron.'
});
Object.assign(translations.en,{
  navSettings:'Settings',collapseSidebar:'Collapse navigation',expandSidebar:'Expand navigation',openNavigation:'Open navigation',closeNavigation:'Close navigation',mobileNavigation:'Quick navigation',moreSections:'More sections',more:'More',
  commandOpen:'Commands',commandEyebrow:'EMA MAYOREO · QUICK ACTIONS',commandTitle:'Command center',commandSearchLabel:'Search commands',commandPlaceholder:'Search an action or section…',commandResultsLabel:'Available commands',commandNavigate:'navigate',commandRun:'run',closeCommands:'Close command center',commandNoResults:'No matching commands.',
  healthTitle:'SYSTEM HEALTH',healthWaiting:'Waiting for check',healthBackend:'Server',healthData:'Data',healthDatabase:'Database',healthAudit:'Audit',healthChecking:'CHECKING',healthOnline:'ONLINE',healthWarning:'ATTENTION',healthError:'ERROR',healthEmpty:'NO DATA',healthUpdated:'Checked · {{time}}',
  dataCoreLabel:'DATA CORE · CONSOLIDATED SALES',dataCoreImported:'DATA CORE · VERIFIED SQLITE',settingsEyebrow:'LOCAL PREFERENCES',settingsTitle:'Command center settings',settingsDescription:'Adjust appearance, navigation, and motion for this app on this device.',
  appearanceTitle:'Appearance',appearanceDescription:'Choose the night workspace or enterprise light theme.',themeToggle:'Change appearance',themeLightAction:'Use light theme',themeDarkAction:'Use dark theme',navigationDensityTitle:'Compact navigation',navigationDensityDescription:'Collapse or expand the sidebar on larger screens.',
  motionTitle:'Reduced motion',motionDescription:'The entrance sequence and reveals are active; reduce them here if you prefer.',motionSystemActiveNote:'Your system requests less motion; animations remain active because you asked for them. Reduce them here any time.',motionSystemReducedNote:'This panel is respecting the reduced motion setting you chose.',motionReduceAction:'Reduce motion',motionRestoreAction:'Allow motion',shortcutsTitle:'Keyboard shortcuts',shortcutCommands:'Open commands',shortcutSearch:'Search routes',shortcutRefresh:'Refresh',shortcutClose:'Close panel',showCommands:'Show commands',welcomeReady:'DATA VERIFIED',welcomeEmpty:'SYSTEM READY · NO DATA LOADED',refreshSuccess:'Data refreshed successfully.',
  pageEyebrow:'EMA MAYOREO · DATA INTELLIGENCE CENTER',pageTitle:'Operations intelligence',heroEyebrow:'DATA INTELLIGENCE CENTER',heroTitle:'The operation, in one view.',heroDescription:'Sales, billing, and route performance connected to the financial source, with reconciliation and exceptions in view.',welcomeTitle:'EMA MAYOREO. Operations under control.',welcomeDescription:'Your local center for sales intelligence, routes, and financial controls is ready.',welcomeEnter:'Enter the center',kpiSparklineHint:'Daily series · {{amount}}',kpiRouteDifferenceHint:'Official daily difference',kpiCompletionSparkHint:'Daily completion · {{count}} dates',fullscreenFailed:'The browser could not enter full screen.'
});
Object.assign(translations.pt,{
  navSettings:'Configurações',collapseSidebar:'Recolher navegação',expandSidebar:'Expandir navegação',openNavigation:'Abrir navegação',closeNavigation:'Fechar navegação',mobileNavigation:'Navegação rápida',moreSections:'Mais seções',more:'Mais',
  commandOpen:'Comandos',commandEyebrow:'EMA MAYOREO · AÇÕES RÁPIDAS',commandTitle:'Central de comandos',commandSearchLabel:'Buscar comando',commandPlaceholder:'Buscar uma ação ou seção…',commandResultsLabel:'Comandos disponíveis',commandNavigate:'navegar',commandRun:'executar',closeCommands:'Fechar central de comandos',commandNoResults:'Nenhum comando correspondente.',
  healthTitle:'SAÚDE DO SISTEMA',healthWaiting:'Aguardando verificação',healthBackend:'Servidor',healthData:'Dados',healthDatabase:'Banco de dados',healthAudit:'Auditoria',healthChecking:'VERIFICANDO',healthOnline:'ONLINE',healthWarning:'ATENÇÃO',healthError:'ERRO',healthEmpty:'SEM DADOS',healthUpdated:'Verificado · {{time}}',
  dataCoreLabel:'NÚCLEO DE DADOS · VENDAS CONSOLIDADAS',dataCoreImported:'NÚCLEO DE DADOS · SQLITE VERIFICADO',settingsEyebrow:'PREFERÊNCIAS LOCAIS',settingsTitle:'Configurações da central',settingsDescription:'Ajuste aparência, navegação e movimento neste dispositivo.',
  appearanceTitle:'Aparência',appearanceDescription:'Escolha entre o ambiente noturno e o tema claro empresarial.',themeToggle:'Alterar aparência',themeLightAction:'Usar tema claro',themeDarkAction:'Usar tema escuro',navigationDensityTitle:'Navegação compacta',navigationDensityDescription:'Recolha ou expanda a barra lateral em telas maiores.',
  motionTitle:'Movimento reduzido',motionDescription:'A entrada animada e as revelações estão ativas; você pode reduzi-las aqui.',motionSystemActiveNote:'O sistema pediu menos movimento; as animações continuam ativas porque você pediu. Reduza-as aqui quando quiser.',motionSystemReducedNote:'Este painel está respeitando a preferência de movimento reduzido que você escolheu.',motionReduceAction:'Reduzir movimento',motionRestoreAction:'Permitir movimento',shortcutsTitle:'Atalhos do teclado',shortcutCommands:'Abrir comandos',shortcutSearch:'Buscar rota',shortcutRefresh:'Atualizar',shortcutClose:'Fechar painel',showCommands:'Ver comandos',welcomeReady:'DADOS VERIFICADOS',welcomeEmpty:'SISTEMA PRONTO · SEM DADOS CARREGADOS',refreshSuccess:'Os dados foram atualizados.',
  pageEyebrow:'EMA MAYOREO · DATA INTELLIGENCE CENTER',pageTitle:'Inteligência operacional',heroEyebrow:'CENTRO DE INTELIGÊNCIA DE DADOS',heroTitle:'A operação, em uma única vista.',heroDescription:'Vendas, faturamento e desempenho por rota conectados à fonte financeira, com conciliação e exceções visíveis.',welcomeTitle:'EMA MAYOREO. Operação sob controle.',welcomeDescription:'Seu centro local de inteligência de vendas, rotas e controle financeiro está pronto.',welcomeEnter:'Entrar na central',kpiSparklineHint:'Série diária · {{amount}}',kpiRouteDifferenceHint:'Diferença diária oficial',kpiCompletionSparkHint:'Cumprimento diário · {{count}} datas',fullscreenFailed:'O navegador não permitiu ativar a tela cheia.'
});

Object.assign(translations.es,{
  dailyEyebrow:'CONTROL DIARIO',dailyTitle:'Preventa y facturación por día',dailyNote:'La facturación diaria se recalcula desde los bloques oficiales. Incluye {{amount}} en ajustes sin ruta para que el total diario concilie con el control mensual; ese importe no se reparte entre vendedores.',dailyNoteImported:'La serie diaria se calcula con las filas de la base SQLite activa; el control del periodo concilia con los totales de esa base.',
  dailyDate:'Fecha',dailyPreventaHeader:'PREVENTA DIARIA · {{period}}',dailyBillingHeader:'FACTURACIÓN DIARIA ERP · {{period}}',dailyDifferenceHeader:'DIFERENCIA FACTURACIÓN - PREVENTA',dailyCompletionHeader:'% FACTURACIÓN VS PREVENTA',dailyTotal:'TOTAL DEL PERIODO',dailyAdjustmentsNote:'Ajustes no asignados incluidos en la serie diaria: {{amount}}. Se mantienen separados de los vendedores.',dailyDownload:'Descargar control diario',dailyCsvSaved:'Descargando el control diario conciliado.',
  dailyFormulaAuditTitle:'Resumen diario del Excel incompleto',dailyFormulaAuditBody:'La fórmula {{cell}} omitía la facturación de las rutas {{routes}} ({{amount}}). El panel recalcula los días desde las columnas oficiales completas.',
  dailyPeriodAuditTitle:'Año del encabezado no coincide',dailyPeriodAuditBody:'El encabezado del Excel dice {{label}}; las fechas de los registros corresponden a {{years}}. El panel muestra el periodo según las fechas reales.',
  dailyAdjustmentsAuditTitle:'Ajustes diarios sin ruta',dailyAdjustmentsAuditBody:'Se incluyen en la facturación diaria y no se asignan a vendedores: {{details}}.'
});
Object.assign(translations.en,{
  dailyEyebrow:'DAILY CONTROL',dailyTitle:'Presales and billing by day',dailyNote:'Daily billing is recalculated from the official blocks. It includes {{amount}} in unassigned adjustments so daily totals reconcile to the monthly control; that amount is not assigned to sellers.',dailyNoteImported:'The daily series comes from rows in the active SQLite database; period totals reconcile to that database.',
  dailyDate:'Date',dailyPreventaHeader:'DAILY PRESALES · {{period}}',dailyBillingHeader:'DAILY ERP BILLING · {{period}}',dailyDifferenceHeader:'BILLING DIFFERENCE - PRESALES',dailyCompletionHeader:'% BILLING VS PRESALES',dailyTotal:'PERIOD TOTAL',dailyAdjustmentsNote:'Unassigned adjustments included in the daily series: {{amount}}. They remain separate from routes.',dailyDownload:'Download daily control',dailyCsvSaved:'Downloading the reconciled daily control.',
  dailyFormulaAuditTitle:'Excel daily summary is incomplete',dailyFormulaAuditBody:'Formula {{cell}} omitted billing for routes {{routes}} ({{amount}}). The dashboard recalculates each day from all official columns.',
  dailyPeriodAuditTitle:'Header year does not match',dailyPeriodAuditBody:'The Excel heading says {{label}}; the records are dated {{years}}. The dashboard labels the period from the actual dates.',
  dailyAdjustmentsAuditTitle:'Daily adjustments without a route',dailyAdjustmentsAuditBody:'They are included in daily billing and remain outside seller totals: {{details}}.'
});
Object.assign(translations.pt,{
  dailyEyebrow:'CONTROLE DIÁRIO',dailyTitle:'Pré-venda e faturamento por dia',dailyNote:'O faturamento diário é recalculado a partir dos blocos oficiais. Inclui {{amount}} em ajustes sem rota para conciliar o controle mensal; esse valor não é atribuído aos vendedores.',dailyNoteImported:'A série diária vem das linhas do banco SQLite ativo; os totais do período conciliam com esse banco.',
  dailyDate:'Data',dailyPreventaHeader:'PRÉ-VENDA DIÁRIA · {{period}}',dailyBillingHeader:'FATURAMENTO DIÁRIO ERP · {{period}}',dailyDifferenceHeader:'DIFERENÇA FATURAMENTO - PRÉ-VENDA',dailyCompletionHeader:'% FATURAMENTO VS PRÉ-VENDA',dailyTotal:'TOTAL DO PERÍODO',dailyAdjustmentsNote:'Ajustes sem rota incluídos na série diária: {{amount}}. Permanecem separados das rotas.',dailyDownload:'Baixar controle diário',dailyCsvSaved:'Baixando o controle diário conciliado.',
  dailyFormulaAuditTitle:'Resumo diário do Excel incompleto',dailyFormulaAuditBody:'A fórmula {{cell}} omitia o faturamento das rotas {{routes}} ({{amount}}). O painel recalcula cada dia com todas as colunas oficiais.',
  dailyPeriodAuditTitle:'Ano do cabeçalho não corresponde',dailyPeriodAuditBody:'O cabeçalho do Excel diz {{label}}; as datas dos registros correspondem a {{years}}. O painel usa o período das datas reais.',
  dailyAdjustmentsAuditTitle:'Ajustes diários sem rota',dailyAdjustmentsAuditBody:'Eles entram no faturamento diário e permanecem fora dos vendedores: {{details}}.'
});

const state = {summary:null, rows:[], daily:[], regions:[], audit:null, locations:null, filtered:[], history:[]};
const localeMap = {es:'es-GT'};
const mapColors = {'ESCUINTLA':'#ff9078','PUERTO DE SAN JOSE':'#5ee7ff','PETEN':'#b59dff','COBAN':'#ffc36b','NUEVA CONCEPCION':'#60e5c1'};
let activeMapRegion='', trendMode='amount', trendData=[];
let locale = 'es', lastFocus = null, toastTimer = 0, loadOK = false, loadInProgress=false, statusKey = 'checking', lastUpdatedTime = null;
let systemHealthSnapshot=null;
let importAvailable=false, databaseManagementAvailable=false, databaseAvailable=false, sourceAvailable=false, baseDatabaseAvailable=false, baseSourceAvailable=false;
let importInProgress=false, importStatusKey='managementReady', importStatusVars={};
let selectedMonth='';

const t=(key,vars={})=>(translations[locale][key]||translations.es[key]||key).replace(/\{\{(\w+)\}\}/g,(_,name)=>String(vars[name]??''));
window.emaT=t;
const esc=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function setFooterStatus(message,options={}){
  if(window.EmaLoaders){window.EmaLoaders.setStatus(message,options);return;}
  const target=document.getElementById('footerStateText')||document.getElementById('footerState');
  if(target)target.textContent=String(message||'');
}
function setImportStatus(key,vars={}){
  importStatusKey=key;importStatusVars=vars;
  const note=document.getElementById('dataImportStatus');if(!note)return;
  note.textContent=t(key,vars);
  note.classList.toggle('is-warning',['importNeedsPython','importFailed','importTooLarge','importWrongType','managementNeedsPython','excelNeedsPython','databaseDeleteFailed'].includes(key));
  note.classList.toggle('is-success',['importDone','databaseDeleted'].includes(key));
  note.classList.toggle('is-busy',['importWorking','databaseWorking'].includes(key));
}
function refreshImportSupport(){
  const historyButton=document.getElementById('historyChooseFileBtn');
  if(historyButton)historyButton.disabled=!importAvailable||importInProgress||loadInProgress;
  const deleteButton=document.getElementById('deleteDatabaseBtn');if(deleteButton)deleteButton.disabled=!databaseManagementAvailable||(!baseDatabaseAvailable&&!baseSourceAvailable&&!state.history.length)||importInProgress||loadInProgress;
  const sourceDownload=document.getElementById('downloadSourceBtn');if(sourceDownload)sourceDownload.disabled=!sourceAvailable;
  if(['managementReady','managementNeedsPython','excelNeedsPython','databaseEmpty'].includes(importStatusKey)){
    const key=!databaseManagementAvailable?'managementNeedsPython':!databaseAvailable&&!sourceAvailable?'databaseEmpty':!importAvailable?'excelNeedsPython':'managementReady';
    setImportStatus(key);
  }
}
const numberFormat=()=>new Intl.NumberFormat(localeMap[locale],{minimumFractionDigits:2,maximumFractionDigits:2});
const compactFormat=()=>new Intl.NumberFormat(localeMap[locale],{notation:'compact',maximumFractionDigits:1});
const fmt=value=>numberFormat().format(Number(value||0));
const gtq=value=>'Q '+fmt(value);
const compactGtq=value=>'Q '+compactFormat().format(Number(value||0));
const signedGtq=value=>{const n=Number(value||0);return(n>0?'+':n<0?'−':'')+gtq(Math.abs(n));};
const pct=value=>numberFormat().format(Number(value||0))+'%';
const shortName=value=>String(value||'').replace(/\s+/g,' ').trim();
const safeNumber=value=>Number.isFinite(Number(value))?Number(value):0;

// Las lecturas de la app instalada pasan por el puente nativo de WebView2.
// El modo navegador conserva fetch para las herramientas de desarrollo web.
const nativeApiPending=new Map();
const nativeDownloadPending=new Map();
if(window.chrome?.webview){
  window.chrome.webview.addEventListener('message',event=>{
    const message=event.data||{};
    const id=String(message.id||'');
    if(message.type==='ema-api-result'){
      const pending=nativeApiPending.get(id);if(!pending)return;
      nativeApiPending.delete(id);window.clearTimeout(pending.timeout);
      if(message.ok)pending.resolve(message.result);
      else pending.reject(new Error(message.error||'El procesador local no pudo completar la operación.'));
      return;
    }
    const transfer=nativeDownloadPending.get(id);if(!transfer)return;
    if(message.type==='ema-download-meta'){
      if(!message.ok){finishNativeDownload(id,new Error(message.error||'No se pudo preparar el archivo local.'));return;}
      transfer.length=Number(message.length)||0;transfer.contentType=message.contentType||'application/octet-stream';
      transfer.contentDisposition=message.contentDisposition||'';
      try{window.chrome.webview.postMessage({type:'ema-download-ack',id,index:-1});}
      catch(error){finishNativeDownload(id,new Error(error?.message||'No se pudo iniciar la descarga local.'));}
      return;
    }
    if(message.type==='ema-download-chunk'){
      if(Number(message.index)!==transfer.nextIndex){finishNativeDownload(id,new Error('La transferencia del archivo llegó incompleta.'));return;}
      try{
        const binary=atob(String(message.data||'')),bytes=new Uint8Array(binary.length);
        for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
        transfer.parts.push(bytes);transfer.loaded+=bytes.byteLength;transfer.nextIndex++;
        transfer.onProgress?.(transfer.loaded,transfer.length);
        window.chrome.webview.postMessage({type:'ema-download-ack',id,index:Number(message.index)});
      }catch(error){
        try{window.chrome.webview.postMessage({type:'ema-download-cancel',id});}catch(_){ }
        finishNativeDownload(id,new Error(error?.message||'No se pudo recibir el archivo local.'));
      }
      return;
    }
    if(message.type==='ema-download-result'){
      if(!message.ok){finishNativeDownload(id,new Error(message.error||'No se pudo descargar el archivo local.'));return;}
      if(transfer.loaded!==transfer.length){finishNativeDownload(id,new Error('La descarga terminó incompleta.'));return;}
      finishNativeDownload(id,null,{parts:transfer.parts,contentType:transfer.contentType,contentDisposition:transfer.contentDisposition});
    }
  });
}
function finishNativeDownload(id,error,result){
  const transfer=nativeDownloadPending.get(id);if(!transfer)return;
  nativeDownloadPending.delete(id);window.clearTimeout(transfer.timeout);
  if(error){try{window.chrome?.webview?.postMessage({type:'ema-download-cancel',id});}catch(_){ }}
  if(error)transfer.reject(error);else transfer.resolve(result);
}
function requestNativeDownload(url,onProgress){
  return new Promise((resolve,reject)=>{
    const bridge=window.chrome?.webview;
    if(!bridge){reject(new Error('El puente local de EMA MAYOREO no está disponible.'));return;}
    const id=window.crypto?.randomUUID?window.crypto.randomUUID():`ema-download-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const transfer={resolve,reject,onProgress,parts:[],loaded:0,length:0,nextIndex:0,contentType:'application/octet-stream',contentDisposition:'',timeout:null};
    transfer.timeout=window.setTimeout(()=>{
      nativeDownloadPending.delete(id);try{bridge.postMessage({type:'ema-download-cancel',id});}catch(_){ }
      reject(new Error('La descarga local tardó demasiado. Vuelve a intentarlo.'));
    },90000);
    nativeDownloadPending.set(id,transfer);
    try{bridge.postMessage({type:'ema-download-request',id,url});}
    catch(error){finishNativeDownload(id,new Error(error?.message||'No se pudo solicitar el archivo local.'));}
  });
}
function requestNativeJson(url,{method='GET',headers={}}={}){
  return new Promise((resolve,reject)=>{
    const bridge=window.chrome?.webview;
    if(!bridge){reject(new Error('El puente local de EMA MAYOREO no está disponible.'));return;}
    const id=window.crypto?.randomUUID?window.crypto.randomUUID():`ema-api-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const timeout=window.setTimeout(()=>{
      nativeApiPending.delete(id);
      reject(new Error(`La consulta local tardó demasiado: ${url}. Cierra y vuelve a abrir EMA MAYOREO.`));
    },30000);
    nativeApiPending.set(id,{resolve,reject,timeout});
    try{bridge.postMessage({type:'ema-api-request',id,method,url,headers});}
    catch(error){window.clearTimeout(timeout);nativeApiPending.delete(id);reject(new Error(`No se pudo consultar los datos locales: ${error?.message||'falló el puente de la aplicación'}.`));}
  });
}

async function getJSON(url){
  const scoped=selectedMonth&&url.startsWith('/api/')&&url!=='/api/history'?`${url}${url.includes('?')?'&':'?'}month=${encodeURIComponent(selectedMonth)}`:url;
  if(window.chrome?.webview)return requestNativeJson(scoped);
  const controller=new AbortController(),timeout=window.setTimeout(()=>controller.abort(),30000);
  try{
    const response=await fetch(scoped,{cache:'no-store',headers:{'Accept':'application/json'},signal:controller.signal});
    if(!response.ok){const detail=await response.json().then(result=>result.error).catch(()=>String(response.statusText||''));throw new Error(detail||`No se pudo consultar ${url} (código ${response.status}).`);}
    return await response.json();
  }catch(error){
    if(error?.name==='AbortError')throw new Error(`La consulta local tardó demasiado: ${url}. Pulsa Actualizar para volver a intentar.`);
    throw error;
  }finally{window.clearTimeout(timeout);}
}

function monthLabel(month){
  if(!/^\d{4}-\d{2}$/.test(month||''))return month||'Periodo sin fecha';
  const [year,number]=month.split('-').map(Number);
  return new Intl.DateTimeFormat('es-GT',{month:'long',year:'numeric',timeZone:'UTC'}).format(new Date(Date.UTC(year,number-1,1)));
}
function currentMonthValue(){
  const now=new Date();
  return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
}
function nextAvailableMonth(){
  const existing=new Set(state.history.map(item=>item.month));
  let candidate=currentMonthValue();
  if(!existing.has(candidate))return candidate;
  let [year,month]=candidate.split('-').map(Number);
  for(let i=0;i<36;i++){month++;if(month>12){month=1;year++;}candidate=`${year}-${String(month).padStart(2,'0')}`;if(!existing.has(candidate))return candidate;}
  return candidate;
}
function pickDefaultHistoryMonth(){
  const picker=document.getElementById('historyMonthInput');if(!picker)return;
  if(!picker.value||state.history.some(item=>item.month===picker.value))picker.value=nextAvailableMonth();
  updateImportModeHelp();
}
function updateImportModeHelp(){
  const month=document.getElementById('historyMonthInput')?.value||'',mode=document.getElementById('historyModeSelect')?.value||'add';
  const exists=state.history.some(item=>item.month===month),help=document.getElementById('historyModeHelp');
  if(!help)return;
  if(!month){help.textContent='Selecciona un mes para ver cómo se guardará el Excel.';return;}
  if(mode==='add'&&exists)help.textContent='Este mes ya existe. Cambia a “Reemplazar” si quieres actualizarlo sin duplicarlo.';
  else if(mode==='replace'&&!exists)help.textContent='Todavía no hay un historial para este mes. Cambia a “Agregar” para crear uno nuevo.';
  else if(mode==='replace')help.textContent='Se sustituirá únicamente el Excel y los datos de este mes. Los demás periodos seguirán intactos.';
  else help.textContent='Se creará un periodo nuevo y se guardará separado de los demás meses.';
}
function publishHistoryToEnhancements(){
  try{
    const snapshot=state.history.map(item=>({
      month:String(item.month||''),
      period:{...(item.period||{})},
      counts:{...(item.counts||{})},
      official_controls:{...(item.official_controls||{})},
      source_file:String(item.source_file||''),
      imported_at:String(item.imported_at||''),
      quality_report:{status:String(item.quality_report?.status||'unknown'),score:Number(item.quality_report?.score||0),checks_passed:Number(item.quality_report?.checks_passed||0),checks_total:Number(item.quality_report?.checks_total||0)}
    }));
    window.dispatchEvent(new CustomEvent('ema:history-updated',{detail:{history:snapshot,selectedMonth:String(selectedMonth||'')}}));
  }catch(error){console.warn('No se pudo actualizar el comparativo mensual.',error);}
}
function renderHistory(){
  const host=document.getElementById('historyList'),label=document.getElementById('currentMonthLabel'),count=document.getElementById('historyCount');if(!host)return;
  if(count)count.textContent=`${state.history.length} ${state.history.length===1?'mes':'meses'}`;
  if(label)label.textContent=selectedMonth?monthLabel(selectedMonth):'Sin periodo seleccionado';
  const monthSelector=document.getElementById('monthSelector');
  if(monthSelector){
    const createOption=`<option value="__new__">＋ Crear nuevo mes · ${esc(monthLabel(nextAvailableMonth()))}</option>`;
    const options=state.history.map(item=>`<option value="${esc(item.month)}">${esc(monthLabel(item.month))}${item.month===selectedMonth?' · ACTIVO':''}</option>`).join('');
    monthSelector.innerHTML=createOption+(options||'');
    monthSelector.value=state.history.some(item=>item.month===selectedMonth)?selectedMonth:'__new__';
    monthSelector.disabled=false;
  }
  const sidebar=document.getElementById('sidebarMonthList'),sideCount=document.getElementById('sidebarMonthCount');
  if(sideCount)sideCount.textContent=String(state.history.length);
  if(sidebar){
    sidebar.innerHTML=state.history.slice(0,6).map(item=>`<button class="sidebar-month${item.month===selectedMonth?' is-active':''}" type="button" data-sidebar-month="${esc(item.month)}" title="Abrir ${esc(monthLabel(item.month))}"><span class="sidebar-month-dot"></span><span>${esc(monthLabel(item.month))}</span><span class="sidebar-month-arrow" aria-hidden="true">↗</span></button>`).join('')||'<span class="sidebar-month-empty">Los meses guardados aparecerán aquí.</span>';
  }
  if(!state.history.length){
    host.innerHTML='<div class="history-empty"><strong>Aún no hay meses guardados</strong><span>Agrega el primer Excel oficial desde el encabezado. Cada periodo se archivará por separado.</span><button class="button button-primary" type="button" data-history-add="true">＋ Agregar primer mes</button></div>';
    pickDefaultHistoryMonth();refreshImportSupport();publishHistoryToEnhancements();return;
  }
  host.innerHTML=state.history.map(item=>{
    const month=String(item.month||''),controls=item.official_controls||{},counts=item.counts||{},active=month===selectedMonth;
    const imported=item.imported_at?new Intl.DateTimeFormat('es-GT',{dateStyle:'medium',timeStyle:'short'}).format(new Date(item.imported_at)):'—';
    const quality=item.quality_report||{};
    return `<article class="history-card${active?' is-current':''}"><div class="history-card-top"><div><span class="history-period">${esc(monthLabel(month))}</span><span class="history-date">Guardado ${esc(imported)}</span></div><span class="history-status${active?' is-live':''}">${active?'En pantalla':'Guardado'}</span></div><div class="history-metrics"><div><span>Facturación oficial</span><strong>${gtq(controls.facturacion_gtq)}</strong></div><div><span>Preventa consolidada</span><strong>${gtq(controls.preventa_gtq)}</strong></div><div><span>Vendedores / rutas</span><strong>${fmt(counts.sellers||counts.routes||0)}</strong></div></div><div class="history-card-meta"><span class="history-file">▣ ${esc(item.source_file||'Excel oficial')}</span><span class="history-quality ${quality.status==='verified'?'is-good':'is-review'}">${quality.status==='verified'?'✓ Datos verificados':'! Revisar datos'}</span></div><div class="history-card-bottom"><div class="history-card-actions"><a class="button button-outline history-download" data-history-download="${esc(month)}" href="/source.xlsx?month=${encodeURIComponent(month)}">↓ Descargar Excel</a><button class="button ${active?'button-outline':'button-primary'} history-open" type="button" data-history-open="${esc(month)}" ${active?'disabled':''}>${active?'Mes abierto':'Ver este mes'}</button><button class="button button-danger history-delete" type="button" data-history-delete="${esc(month)}" aria-label="Eliminar ${esc(monthLabel(month))}" title="Eliminar este mes">⌫ Eliminar</button></div></div></article>`;
  }).join('');
  pickDefaultHistoryMonth();refreshImportSupport();publishHistoryToEnhancements();
}
function openExcelImportModal(mode='add',month=''){
  if(importInProgress)return;
  const modal=document.getElementById('excelImportModal');
  const input=document.getElementById('historyMonthInput'),modeSelect=document.getElementById('historyModeSelect');
  input.value=month||nextAvailableMonth();
  modeSelect.value=mode;
  document.getElementById('historyFileInput').value='';
  showHistoryStatus('El nombre del archivo no importa: se revisará el contenido real, las fechas y las cifras del Excel.');
  updateImportModeHelp();modal.classList.remove('hidden');
  document.body.classList.add('modal-open');
  requestAnimationFrame(()=>input.focus());
}
function closeExcelImportModal(){
  const modal=document.getElementById('excelImportModal');if(!modal||modal.classList.contains('hidden'))return;
  modal.classList.add('hidden');document.body.classList.remove('modal-open');
}
async function deleteHistoryMonth(month){
  if(importInProgress||loadInProgress)return;
  const confirmation=window.prompt(`Vas a eliminar permanentemente el historial de ${monthLabel(month)}. Los demás meses no se tocarán. Escribe BORRAR para confirmar:`);
  if(confirmation!=='BORRAR')return;
  importInProgress=true;refreshImportSupport();
  setFooterStatus(`Eliminando ${monthLabel(month)}…`,{busy:true,progress:null});
  try{
    let result;
    if(window.chrome?.webview)result=await requestNativeJson(`/api/history?month=${encodeURIComponent(month)}`,{method:'DELETE',headers:{'X-EMA-Management':'ema-panel-management'}});
    else{const response=await fetch(`/api/history?month=${encodeURIComponent(month)}`,{method:'DELETE',headers:{'X-EMA-Management':'ema-panel-management'},cache:'no-store'});result=await response.json().catch(()=>({}));if(!response.ok)throw new Error(result.error||'No se pudo eliminar el mes.');}
    if(!result?.ok)throw new Error(result?.error||'No se pudo eliminar el mes.');
    if(selectedMonth===month){selectedMonth='';try{localStorage.removeItem('ema.activeMonth');}catch(_){}const url=new URL(location.href);url.searchParams.delete('month');history.replaceState({},'',url);}
    const ok=await load();if(!ok)throw new Error('El mes se eliminó, pero el panel no pudo actualizar la vista. Pulsa Actualizar.');
    showToast(`${monthLabel(month)} se eliminó del historial.`,'success');
    setFooterStatus('Historial actualizado',{state:'success'});
  }catch(error){showToast(error.message||'No se pudo eliminar el mes.','error');setFooterStatus(error.message||'No se pudo eliminar el mes.',{state:'error'});}
  finally{importInProgress=false;refreshImportSupport();}
}

function syncSelectedMonth(month){
  selectedMonth=month||'';
  try{if(selectedMonth)localStorage.setItem('ema.activeMonth',selectedMonth);else localStorage.removeItem('ema.activeMonth');}catch(_){}
  const url=new URL(location.href);if(selectedMonth)url.searchParams.set('month',selectedMonth);else url.searchParams.delete('month');history.replaceState({},'',url);
  renderHistory();
}
async function openHistoryMonth(month){
  if(loadInProgress||!state.history.some(item=>item.month===month)||month===selectedMonth)return;
  syncSelectedMonth(month);
  if(await load())document.getElementById('inicio').scrollIntoView({behavior:'smooth',block:'start'});
}

function applyLanguage(){
  document.documentElement.lang=locale;
  document.title='EMA MAYOREO · '+t('brandSubtitle');
  document.querySelector('meta[name="description"]').content=t('appDescription');
  document.querySelectorAll('[data-i18n]').forEach(node=>{node.textContent=t(node.dataset.i18n);});
  document.querySelectorAll('[data-i18n-placeholder]').forEach(node=>{node.placeholder=t(node.dataset.i18nPlaceholder);});
  document.querySelectorAll('[data-i18n-aria]').forEach(node=>{node.setAttribute('aria-label',t(node.dataset.i18nAria));});
  document.querySelectorAll('[data-i18n-title]').forEach(node=>{node.title=t(node.dataset.i18nTitle);});
  const button=document.getElementById('fullscreenBtn');
  if(button){button.setAttribute('aria-label',t(document.fullscreenElement?'exitFullscreen':'fullscreen'));button.title=t(document.fullscreenElement?'exitFullscreen':'fullscreen');}
  refreshImportSupport();
  if(loadOK&&state.summary)renderDashboard();
  if(document.getElementById('statusBadge')&&statusKey!=='checking')setStatus(loadOK,statusKey);
  if(lastUpdatedTime)setFooterStatus(t('updatedAt',{time:formatTime(lastUpdatedTime)}),{state:'success'});
  updateSystemHealth();
}
function setStatus(ok,key){
  statusKey=key;
  const badge=document.getElementById('statusBadge');
  badge.classList.toggle('error',!ok);
  badge.innerHTML='<span class="status-dot" aria-hidden="true"></span><span>'+esc(t(key))+'</span>';
  document.getElementById('sideStatus').textContent=t(key);
}
function updateSystemHealth(snapshot=systemHealthSnapshot){
  const stateFor=(id,key)=>{
    const cell=document.getElementById(id);if(!cell)return;
    cell.dataset.health=key;
    const value=cell.querySelector('.health-state');if(value)value.textContent=t({online:'healthOnline',warning:'healthWarning',error:'healthError',empty:'healthEmpty',checking:'healthChecking'}[key]||'healthChecking');
  };
  if(snapshot)systemHealthSnapshot=snapshot;
  const current=systemHealthSnapshot;
  if(!current){for(const id of ['healthBackend','healthData','healthDatabase','healthAudit'])stateFor(id,'checking');return;}
  const rows=Array.isArray(current.rows)?current.rows:null;
  const auditOk=Boolean(current.audit?.official_summary&&current.summary?.internal_reconciliation);
  const auditReconciled=current.summary?.internal_reconciliation?.status==='OK';
  stateFor('healthBackend',current.backendOk?'online':'error');
  stateFor('healthData',!rows?'error':rows.length?'online':'empty');
  const dbAvailable=current.health?.database_available??databaseAvailable;
  stateFor('healthDatabase',current.health?dbAvailable?'online':rows?.length?'warning':'empty':rows?'warning':'error');
  stateFor('healthAudit',!auditOk?'error':auditReconciled?'online':'warning');
  const updated=lastUpdatedTime?t('healthUpdated',{time:formatTime(lastUpdatedTime)}):t('healthWaiting');
  const healthUpdated=document.getElementById('healthUpdated');if(healthUpdated)healthUpdated.textContent=updated;
  const last=document.getElementById('lastUpdatedAt');if(last)last.textContent=updated;
}
function formatDate(iso,options={year:'numeric',month:'short',day:'numeric'}){
  if(!iso)return'—';
  const parts=String(iso).split('-').map(Number);
  if(parts.length!==3||parts.some(n=>!Number.isFinite(n)))return esc(iso);
  return new Intl.DateTimeFormat(localeMap[locale],options).format(new Date(parts[0],parts[1]-1,parts[2],12));
}
function formatTime(date){return new Intl.DateTimeFormat(localeMap[locale],{hour:'2-digit',minute:'2-digit',timeZone:'America/Guatemala'}).format(date);}
function applyDatasetLanguage(){
  if(!state.summary)return;
  const imported=state.summary.source==='SQLite importada';
  const copy={
    sourceName:imported?'databaseSourceName':'workbookSourceName',
    sourceNote:imported?'sourceDatabaseNote':'sourceNote',
    trendNoteText:imported?'trendNoteImported':'trendNote',
    sellersNoteText:imported?'routesNoteImported':'routesNote',
    reconciliationNoteText:imported?'reconciliationNoteImported':'reconciliationNote',
    auditNoteText:imported?'auditNoteImported':'auditNote',
    activeDaysCaption:imported?'activeDaysCaptionImported':'activeDaysCaption',
    mapDisclaimerText:imported?'mapDisclaimerImported':'mapDisclaimer'
  };
  Object.entries(copy).forEach(([id,key])=>{const node=document.getElementById(id);if(node)node.textContent=t(key);});
}
function setHero(){
  const summary=state.summary,controls=summary.official_controls,counts=summary.counts,period=summary.period,rec=summary.internal_reconciliation;
  const imported=summary.source==='SQLite importada';
  document.getElementById('heroCoreLabel').textContent=t(imported?'dataCoreImported':'dataCoreLabel');
  document.getElementById('periodText').textContent=formatDate(period.start)+' – '+formatDate(period.end)+' · '+t(imported?'dataCountDaysImported':'dataCountDays',{count:period.active_days,routes:groupedSellers().length});
  document.getElementById('heroGap').textContent=signedGtq(controls.diferencia_gtq);
  const completion=Math.max(0,safeNumber(controls.cumplimiento_pct)),width=Math.min(100,completion);
  document.getElementById('heroProgress').style.width=width+'%';
  document.getElementById('heroProgressText').textContent=pct(completion);
  const progress=document.getElementById('heroProgressBar');
  progress.setAttribute('aria-valuenow',String(Math.round(width)));
  progress.setAttribute('aria-label',t(imported?'completionImported':'officialCompletion'));
  document.getElementById('differenceLabel').textContent=t(imported?'differenceLabelImported':'officialDifference');
  document.getElementById('differenceCaptionText').textContent=t(imported?'differenceCaptionImported':'differenceCaption');
  document.getElementById('completionLabel').textContent=t(imported?'completionImported':'officialCompletion');
  const badge=document.getElementById('qualityBadge'),healthy=rec.status==='OK';
  badge.classList.toggle('warn',!healthy);badge.textContent=t(healthy?'qualityOk':'qualityReview');
}
function groupedSellers(rows=state.rows){
  const groups=new Map();
  for(const row of rows){
    const seller=shortName(row.seller)||'Sin vendedor';
    if(!groups.has(seller))groups.set(seller,{seller,regions:new Set(),routeIds:new Set(),dates:new Set(),preventa_gtq:0,facturacion_gtq:0,diferencia_gtq:0});
    const item=groups.get(seller);
    if(row.region)item.regions.add(String(row.region));
    if(row.route_id)item.routeIds.add(String(row.route_id));
    if(row.date)item.dates.add(String(row.date));
    item.preventa_gtq+=safeNumber(row.preventa_gtq);
    item.facturacion_gtq+=safeNumber(row.facturacion_gtq);
    item.diferencia_gtq+=safeNumber(row.diferencia_gtq);
  }
  return [...groups.values()].map(item=>{
    const regions=[...item.regions].sort((a,b)=>a.localeCompare(b,'es-GT'));
    return {...item,region:regions.join(' · ')||'Sin región',days:item.dates.size,cumplimiento_pct:item.preventa_gtq?item.facturacion_gtq/item.preventa_gtq*100:0};
  });
}
function renderKpis(){
  const c=state.summary.official_controls,count=groupedSellers().length,adjustment=state.summary.internal_reconciliation.adjustment_gtq,imported=state.summary.source==='SQLite importada';
  const seriesFor=field=>{
    return state.daily.map(day=>safeNumber(day[field]));
  };
  const completionSeries=state.daily.map(day=>safeNumber(day.cumplimiento_pct));
  const sparkline=values=>{
    if(values.length<2)return '';
    const compact=values.length>32?Array.from({length:32},(_,index)=>values[Math.round(index*(values.length-1)/31)]):values;
    const min=compact.reduce((value,item)=>Math.min(value,item),Infinity),max=compact.reduce((value,item)=>Math.max(value,item),-Infinity),range=Math.max(1,max-min),width=120,height=30,pad=2;
    const points=compact.map((value,index)=>`${(pad+index*(width-2*pad)/(compact.length-1)).toFixed(1)},${(height-pad-(value-min)*(height-2*pad)/range).toFixed(1)}`).join(' ');
    return `<svg class="kpi-sparkline" viewBox="0 0 ${width} ${height}" aria-hidden="true" focusable="false"><polyline points="${points}" vector-effect="non-scaling-stroke" /></svg>`;
  };
  const target=(value,prefix='',sign='',finalValue='')=>`data-count-up="true" data-count-target="${safeNumber(value)}" data-count-prefix="${esc(prefix)}" data-count-sign="${sign}" aria-label="${esc(finalValue)}"`;
  const cards=[
    {color:'kpi-green',label:imported?'kpiBillingImported':'kpiBilling',value:gtq(c.facturacion_gtq),amount:c.facturacion_gtq,prefix:'Q ',sign:'',note:t(imported?'kpiBillingImportedNote':'kpiBillingNote',{amount:gtq(adjustment)}),series:seriesFor('facturacion_gtq'),hint:t('kpiSparklineHint',{amount:gtq(c.facturacion_gtq)})},
    {color:'kpi-blue',label:imported?'kpiPreventaImported':'kpiPreventa',value:gtq(c.preventa_gtq),amount:c.preventa_gtq,prefix:'Q ',sign:'',note:t(imported?'kpiPreventaImportedNote':'kpiPreventaNote',{count}),series:seriesFor('preventa_gtq'),hint:t('kpiSparklineHint',{amount:gtq(c.preventa_gtq)})},
    {color:'kpi-violet',label:imported?'kpiCompletionImported':'kpiCompletion',value:pct(c.cumplimiento_pct),amount:c.cumplimiento_pct,prefix:'',sign:'',suffix:'%',note:t('kpiCompletionNote'),series:completionSeries,hint:t('kpiCompletionSparkHint',{count:completionSeries.length}),radial:true},
    {color:'kpi-amber',label:imported?'kpiDifferenceImported':'kpiDifference',value:signedGtq(c.diferencia_gtq),amount:Math.abs(c.diferencia_gtq),prefix:'Q ',sign:c.diferencia_gtq<0?'−':c.diferencia_gtq>0?'+':'',note:t('kpiDifferenceNote'),series:seriesFor('diferencia_gtq'),hint:t('kpiRouteDifferenceHint')}
  ];
  document.getElementById('kpiGrid').innerHTML=cards.map(card=>{
    const radial=card.radial?`<span class="kpi-radial" aria-hidden="true" style="--kpi-progress:${Math.min(100,Math.max(0,safeNumber(card.amount))).toFixed(2)}%"></span>`:'';
    const countAttrs=target(card.amount,card.prefix,card.sign,card.value)+(card.suffix?` data-count-suffix="${card.suffix}"`: '');
    return `<article class="kpi ${card.color}" data-motion="reveal"><div class="kpi-card-head"><div class="kpi-label">${esc(t(card.label))}</div><span class="kpi-indicator" aria-hidden="true"></span></div>${radial}<div class="kpi-value" ${countAttrs}>${esc(card.value)}</div><div class="kpi-sub">${esc(card.note)}</div><div class="kpi-chart-row">${sparkline(card.series)}<span class="kpi-chart-hint">${esc(card.hint)}</span></div></article>`;
  }).join('');
  document.getElementById('kpiGrid').setAttribute('aria-busy','false');
}
function renderInsights(){
  const sellers=groupedSellers();
  const bestRegion=[...state.regions].sort((a,b)=>b.facturacion_gtq-a.facturacion_gtq)[0];
  const bestSeller=[...sellers].sort((a,b)=>b.facturacion_gtq-a.facturacion_gtq)[0];
  const gapSeller=[...sellers].sort((a,b)=>a.diferencia_gtq-b.diferencia_gtq)[0];
  for(const id of ['bestRegion','bestRegionSub','bestSeller','bestSellerSub','gapSeller','gapSellerSub'])document.getElementById(id).textContent='—';
  if(bestRegion){document.getElementById('bestRegion').textContent=bestRegion.region;document.getElementById('bestRegionSub').textContent=t('bestRegionNote',{amount:gtq(bestRegion.facturacion_gtq)});}
  if(bestSeller){document.getElementById('bestSeller').textContent=bestSeller.seller;document.getElementById('bestSellerSub').textContent=t('topSellerNote',{amount:gtq(bestSeller.facturacion_gtq)});}
  if(gapSeller){document.getElementById('gapSeller').textContent=gapSeller.seller;document.getElementById('gapSellerSub').textContent=t('attentionSellerNote',{amount:signedGtq(gapSeller.diferencia_gtq)});}
  document.getElementById('activeDays').textContent=String(state.summary.period.active_days);
}
function drawTrend(){
  trendData=state.daily.map(day=>({date:day.date,pre:safeNumber(day.preventa_gtq),fact:safeNumber(day.facturacion_gtq),diff:safeNumber(day.diferencia_gtq),completion:safeNumber(day.cumplimiento_pct)})).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  const host=document.getElementById('trendChart'),legend=document.getElementById('trendLegend');
  if(!trendData.length){host.innerHTML='<div class="no-data">'+esc(t('noData'))+'</div>';document.getElementById('trendReadout').textContent=t('noData');return;}
  const mode=trendMode,W=1080,H=354,L=88,R=22,T=24,B=49,innerW=W-L-R,innerH=H-T-B;
  const metricKey=mode==='difference'?'diff':mode==='completion'?'completion':'fact';
  const values=trendData.flatMap(item=>mode==='amount'?[item.pre,item.fact]:[item[metricKey]]).filter(Number.isFinite);
  let low=0,high=Math.max(1,...values);
  if(mode==='amount'){high=high*1.1;}
  if(mode==='difference'){const bound=Math.max(1,...values.map(Math.abs))*1.12;low=-bound;high=bound;}
  if(mode==='completion'){
    const min=Math.min(...values),max=Math.max(...values);
    low=Math.max(0,Math.floor((min-5)/10)*10);high=Math.max(low+20,Math.ceil((max+5)/10)*10);
    if(high-low<20){low=Math.max(0,low-10);high+=10;}
  }
  if(!Number.isFinite(low)||!Number.isFinite(high)||high<=low){low=0;high=1;}
  const x=i=>L+(trendData.length===1?innerW/2:i/(trendData.length-1)*innerW);
  const y=value=>T+innerH-(value-low)/(high-low)*innerH;
  const series=mode==='amount'?['pre','fact']:[metricKey];
  // Draw exact observed points with straight segments: avoid overshooting real values with artificial curves.
  const linePath=key=>trendData.map((item,i)=>(i?'L ':'M ')+x(i).toFixed(2)+' '+y(item[key]).toFixed(2)).join(' ');
  const baseline=mode==='difference'?0:mode==='completion'?100:null;
  const areaPath=key=>{
    const base=baseline!==null&&baseline>=low&&baseline<=high?baseline:low;
    const topPath=trendData.map((item,i)=>(i?'L ':'M ')+x(i).toFixed(2)+' '+y(item[key]).toFixed(2)).join(' ');
    return `M ${x(0).toFixed(2)} ${y(base).toFixed(2)} L ${x(0).toFixed(2)} ${y(trendData[0][key]).toFixed(2)} ${topPath.slice(topPath.indexOf('L ')+2)} L ${x(trendData.length-1).toFixed(2)} ${y(base).toFixed(2)} Z`;
  };
  const axis=value=>mode==='completion'?new Intl.NumberFormat(localeMap[locale],{maximumFractionDigits:0}).format(value)+'%':(mode==='difference'?(value<0?'−':value>0?'+':''):'')+'Q '+compactFormat().format(Math.abs(value));
  const grid=[0,.25,.5,.75,1].map(f=>{const value=high-(high-low)*f,yy=y(value);return `<g class="daily-axis-tick"><line class="chart-grid" x1="${L}" y1="${yy.toFixed(2)}" x2="${W-R}" y2="${yy.toFixed(2)}"/><text class="chart-axis-label" x="${L-12}" y="${(yy+4).toFixed(2)}" text-anchor="end">${esc(axis(value))}</text></g>`;}).join('');
  const baselineLine=baseline!==null&&baseline>=low&&baseline<=high?`<g class="chart-baseline"><line x1="${L}" y1="${y(baseline).toFixed(2)}" x2="${W-R}" y2="${y(baseline).toFixed(2)}"/><text class="chart-baseline-label" x="${W-R-3}" y="${(y(baseline)-7).toFixed(2)}" text-anchor="end">${esc(mode==='completion'?t('trendTarget'):'Q 0')}</text></g>`:'';
  const step=Math.max(1,Math.ceil(trendData.length/8));
  const labels=trendData.map((item,i)=>({item,i})).filter(({i})=>i===0||i===trendData.length-1||i%step===0).map(({item,i})=>`<text class="chart-axis-label chart-date-label" x="${x(i).toFixed(2)}" y="${H-13}" text-anchor="middle">${esc(formatDate(item.date,{month:'short',day:'numeric'}))}</text>`).join('');
  const paths=mode==='amount'?`<path class="chart-area" d="${areaPath('fact')}"/><path class="chart-line-pre" d="${linePath('pre')}"/><path class="chart-line-fact" d="${linePath('fact')}"/>`:mode==='difference'?`<path class="chart-area chart-area-diff" d="${areaPath('diff')}"/><path class="chart-line-diff" d="${linePath('diff')}"/>`:`<path class="chart-area chart-area-completion" d="${areaPath('completion')}"/><path class="chart-line-completion" d="${linePath('completion')}"/>`;
  const pointGroups=trendData.map((item,index)=>{
    const left=index===0?L:(x(index-1)+x(index))/2,right=index===trendData.length-1?W-R:(x(index)+x(index+1))/2;
    const date=formatDate(item.date),label=date+' · '+t('trendPreventaValue')+' '+gtq(item.pre)+' · '+t('trendBillingValue')+' '+gtq(item.fact)+' · '+t('trendDifferenceValue')+' '+signedGtq(item.diff)+' · '+t('trendCompletionValue')+' '+pct(item.completion);
    const circles=series.map(key=>`<circle class="chart-point ${key==='pre'?'chart-point-pre':key==='fact'?'chart-point-fact':key==='diff'?'chart-point-diff':'chart-point-completion'}" cx="${x(index).toFixed(2)}" cy="${y(item[key]).toFixed(2)}" r="${trendData.length>20?'2.8':'4.1'}"/>`).join('');
    return `<rect class="chart-hit" data-trend-index="${index}" x="${left.toFixed(2)}" y="${T}" width="${Math.max(1,right-left).toFixed(2)}" height="${innerH}" tabindex="${index===trendData.length-1?'0':'-1'}" role="button" aria-pressed="false" aria-label="${esc(label)}"><title>${esc(label)}</title></rect>${circles}`;
  }).join('');
  host.innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="group" aria-label="${esc(t('trendChartLabel'))}" preserveAspectRatio="none"><defs><linearGradient id="trendArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#62e5cc" stop-opacity=".24"/><stop offset="100%" stop-color="#62e5cc" stop-opacity="0"/></linearGradient><linearGradient id="differenceArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#ffc878" stop-opacity=".24"/><stop offset="100%" stop-color="#ff8296" stop-opacity=".015"/></linearGradient><linearGradient id="completionArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#62edca" stop-opacity=".24"/><stop offset="100%" stop-color="#62edca" stop-opacity="0"/></linearGradient></defs><g>${grid}${baselineLine}</g><g class="daily-chart-series">${paths}</g><g class="chart-hit-layer">${labels}${pointGroups}</g></svg>`;
  legend.hidden=mode!=='amount';
  host.querySelectorAll('.chart-hit').forEach(hit=>{
    const select=()=>updateTrendReadout(Number(hit.dataset.trendIndex),hit);
    hit.addEventListener('focus',select);hit.addEventListener('pointerenter',select);
    hit.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight'].includes(event.key))return;event.preventDefault();const target=(Number(hit.dataset.trendIndex)+(event.key==='ArrowRight'?1:-1)+trendData.length)%trendData.length;host.querySelector('[data-trend-index="'+target+'"]').focus();});
  });
  updateTrendReadout(trendData.length-1,host.querySelector('.chart-hit:last-of-type'));
}
function updateTrendReadout(index,target){
  const item=trendData[index],host=document.getElementById('trendReadout');if(!item||!host)return;
  document.querySelectorAll('.chart-hit').forEach(node=>{const active=node===target;node.classList.toggle('is-active',active);node.setAttribute('aria-pressed',String(active));node.setAttribute('tabindex',active?'0':'-1');});
  host.innerHTML='<strong class="chart-readout-date">'+esc(formatDate(item.date))+'</strong><span><i class="legend-dot legend-pre" aria-hidden="true"></i>'+esc(t('trendPreventaValue'))+' <b>'+esc(gtq(item.pre))+'</b></span><span><i class="legend-dot legend-fact" aria-hidden="true"></i>'+esc(t('trendBillingValue'))+' <b>'+esc(gtq(item.fact))+'</b></span><span class="readout-difference">'+esc(t('trendDifferenceValue'))+' <b>'+esc(signedGtq(item.diff))+'</b></span><span class="readout-completion">'+esc(t('trendCompletionValue'))+' <b>'+esc(pct(item.completion))+'</b></span>';
}
function renderDailyControl(){
  const periodStart=state.summary.period.start,period=periodStart?formatDate(periodStart,{month:'long',year:'numeric'}).toLocaleUpperCase(localeMap[locale]):'';
  const imported=state.summary.source==='SQLite importada',adjustment=safeNumber(state.summary.internal_reconciliation.adjustment_gtq);
  const noteKey=imported?'dailyNoteImported':'dailyNote';
  document.getElementById('dailyNoteText').textContent=t(noteKey,{amount:gtq(adjustment)});
  const host=document.getElementById('dailyControlTable');
  if(!state.daily.length){host.innerHTML='<div class="no-data">'+esc(t('noData'))+'</div>';document.getElementById('dailyDownloadBtn').disabled=true;return;}
  const controls=state.summary.official_controls;
  const header='<table class="daily-control-table"><thead><tr><th scope="col">'+esc(t('dailyDate'))+'</th><th scope="col" class="num">'+esc(t('dailyPreventaHeader',{period}))+'</th><th scope="col" class="num">'+esc(t('dailyBillingHeader',{period}))+'</th><th scope="col" class="num">'+esc(t('dailyDifferenceHeader'))+'</th><th scope="col" class="num">'+esc(t('dailyCompletionHeader'))+'</th></tr></thead><tbody>';
  const body=state.daily.map(day=>'<tr><td>'+esc(formatDate(day.date,{day:'2-digit',month:'2-digit',year:'numeric'}))+'</td><td class="num">'+esc(gtq(day.preventa_gtq))+'</td><td class="num">'+esc(gtq(day.facturacion_gtq))+'</td><td class="num '+(day.diferencia_gtq>=0?'delta-pos':'delta-neg')+'">'+esc(signedGtq(day.diferencia_gtq))+'</td><td class="num">'+esc(pct(day.cumplimiento_pct))+'</td></tr>').join('');
  const footer='<tfoot><tr><th scope="row">'+esc(t('dailyTotal'))+'</th><td class="num">'+esc(gtq(controls.preventa_gtq))+'</td><td class="num">'+esc(gtq(controls.facturacion_gtq))+'</td><td class="num '+(controls.diferencia_gtq>=0?'delta-pos':'delta-neg')+'">'+esc(signedGtq(controls.diferencia_gtq))+'</td><td class="num">'+esc(pct(controls.cumplimiento_pct))+'</td></tr></tfoot></table>';
  host.innerHTML=header+body+'</tbody>'+footer;
  document.getElementById('dailyDownloadBtn').disabled=false;
}
function downloadDailyCsv(){
  if(!state.daily.length)return;
  const columns=['date','preventa_gtq','facturacion_gtq','diferencia_gtq','cumplimiento_pct'];
  const rows=state.daily.map(day=>columns.map(key=>day[key]));
  const csv='\uFEFF'+[columns,...rows].map(row=>row.map(csvField).join(',')).join('\r\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),link=document.createElement('a');
  link.href=url;link.download='ema_mayoreo_control_diario.csv';document.body.appendChild(link);link.click();link.remove();
  window.setTimeout(()=>URL.revokeObjectURL(url),1000);announceDownload(t('dailyCsvSaved'));
}
function renderRegions(){
  const max=Math.max(1,...state.regions.flatMap(region=>[safeNumber(region.facturacion_gtq),safeNumber(region.preventa_gtq)]));
  document.getElementById('regionList').innerHTML=[...state.regions].sort((a,b)=>safeNumber(b.facturacion_gtq)-safeNumber(a.facturacion_gtq)).map(region=>{
    const billing=safeNumber(region.facturacion_gtq),preventa=safeNumber(region.preventa_gtq),completion=preventa?billing/preventa*100:0;
    const bar=(key,label,value,color)=>'<div class="region-bar-row" title="'+esc(t(label)+': '+gtq(value))+'"><span class="region-bar-label '+color+'" aria-hidden="true">'+esc(t(key))+'</span><span class="region-track" role="img" aria-label="'+esc(region.region+' · '+t(label)+' '+gtq(value))+'"><span class="region-fill '+color+'" style="width:'+Math.max(0,Math.min(100,value/max*100)).toFixed(1)+'%"></span></span><span class="region-bar-value">'+esc(compactGtq(value))+'</span></div>';
    return'<article class="region-item"><div class="region-heading"><span class="region-name">'+esc(region.region)+'</span><span class="region-completion">'+esc(t('regionCompletion',{value:pct(completion)}))+'</span></div><div class="region-bars">'+bar('regionBillingShort','billing',billing,'region-billing')+bar('regionPreventaShort','preventa',preventa,'region-preventa')+'</div></article>';
  }).join('');
}
function getMapEntries(){
  const locations=state.locations?.locations||[],bounds=state.locations?.map_bounds||{};
  if(!locations.length)return[];
  const sellers=groupedSellers(),seen=new Set();
  return locations.map((location,index)=>{
    const lat=Number(location.latitude),lon=Number(location.longitude),stats=state.regions.find(item=>item.region===location.region);
    const sellerCount=sellers.filter(seller=>seller.region===location.region).length;
    if(!stats||!Number.isFinite(lat)||!Number.isFinite(lon)||seen.has(location.region))return null;
    seen.add(location.region);
    const x=((lon-Number(bounds.west))/(Number(bounds.east)-Number(bounds.west)))*100;
    const y=((Number(bounds.north)-lat)/(Number(bounds.north)-Number(bounds.south)))*100;
    if(!Number.isFinite(x)||!Number.isFinite(y)||x<0||x>100||y<0||y>100)return null;
    return{location,stats,sellerCount,x,y,index,color:mapColors[location.region]||'#5ee7ff'};
  }).filter(Boolean);
}
function mapMetric(entry,metric){
  return metric==='sellers'?entry.sellerCount:safeNumber(entry.stats[metric==='preventa'?'preventa_gtq':'facturacion_gtq']);
}
function mapCoordinateText(location){
  const lat=Number(location.latitude),lon=Number(location.longitude),west=locale==='es'||locale==='pt'?'O':'W';
  return Math.abs(lat).toFixed(5)+'° '+(lat>=0?'N':'S')+' · '+Math.abs(lon).toFixed(5)+'° '+(lon<0?west:'E');
}
function renderMap(){
  const markerHost=document.getElementById('mapMarkers'),listHost=document.getElementById('mapPlaceList');
  if(!markerHost||!listHost)return;
  let entries=getMapEntries();
  if(!entries.length){
    markerHost.replaceChildren();listHost.replaceChildren();
    document.getElementById('mapFocus').innerHTML='<div class="map-focus-city">'+esc(t('mapNoLocations'))+'</div>';
    document.getElementById('mapRegionCount').textContent='0';return;
  }
  const metric=document.getElementById('mapMetricSelect').value||'billing';
  entries=entries.map(entry=>({...entry,value:mapMetric(entry,metric)}));
  const maxValue=Math.max(1,...entries.map(entry=>entry.value));
  const regionFilter=document.getElementById('regionSelect').value;
  if(regionFilter&&entries.some(entry=>entry.location.region===regionFilter))activeMapRegion=regionFilter;
  if(!entries.some(entry=>entry.location.region===activeMapRegion))activeMapRegion=[...entries].sort((a,b)=>b.stats.facturacion_gtq-a.stats.facturacion_gtq)[0].location.region;
  entries.sort((a,b)=>b.stats.facturacion_gtq-a.stats.facturacion_gtq);
  markerHost.innerHTML=entries.map(entry=>{
    const size=19+Math.sqrt(Math.max(0,entry.value)/maxValue)*18;
    const display=metric==='sellers'?t('mapSellerCount',{count:entry.sellerCount}):compactFormat().format(entry.value);
    const selected=entry.location.region===activeMapRegion;
    const label=entry.location.city+' · '+entry.location.region+' · '+mapCoordinateText(entry.location);
    return'<button class="map-marker'+(selected?' is-selected':'')+'" type="button" data-map-region="'+esc(entry.location.region)+'" aria-pressed="'+selected+'" aria-label="'+esc(label)+'" title="'+esc(label)+'" style="--map-x:'+entry.x.toFixed(3)+'%;--map-y:'+entry.y.toFixed(3)+'%;--pin-size:'+size.toFixed(1)+'px;--pin-color:'+entry.color+'"><span class="map-marker-symbol" aria-hidden="true"></span><span class="map-marker-label" aria-hidden="true"><strong>'+esc(entry.location.city)+'</strong><small>'+esc(display)+'</small></span></button>';
  }).join('');
  listHost.innerHTML=entries.map(entry=>{
    const selected=entry.location.region===activeMapRegion;
    return'<button class="map-place-button'+(selected?' is-selected':'')+'" type="button" data-map-region="'+esc(entry.location.region)+'" aria-pressed="'+selected+'" style="--pin-color:'+entry.color+'"><span class="map-place-name"><i class="map-place-dot" aria-hidden="true"></i><span>'+esc(entry.location.city)+'</span></span><span class="map-place-meta">'+esc(t('mapSellerCount',{count:entry.sellerCount}))+'</span></button>';
  }).join('');
  document.getElementById('mapRegionCount').textContent=String(entries.length);
  renderMapFocus(entries.find(entry=>entry.location.region===activeMapRegion),entries);
  window.EmaMotion?.refresh();
}
function renderMapFocus(entry,entries=getMapEntries()){
  const host=document.getElementById('mapFocus');if(!host||!entry)return;
  const location=entry.location,stats=entry.stats;
  host.innerHTML=`
    <div class="map-focus-top"><div><span class="eyebrow">${esc(t('mapSelected'))}</span><h3 class="map-focus-city">${esc(location.city)}</h3><div class="map-focus-region">${esc(location.region)} · ${esc(t('mapCenter'))}</div></div><span class="map-place-dot" style="--pin-color:${entry.color}" aria-hidden="true"></span></div>
    <div class="map-coordinate-row"><div><div class="map-coordinate-label">${esc(t('mapCoordinates'))}</div><div class="map-focus-coordinate">${esc(mapCoordinateText(location))}</div></div><button class="button button-icon-only map-copy-inline" type="button" data-copy-coordinates="${esc(location.region)}" aria-label="${esc(t('mapCopyCoordinates'))}" title="${esc(t('mapCopyCoordinates'))}">⧉</button></div>
    <div class="map-stat-grid"><div class="map-stat accent"><span>${esc(t('mapBilling'))}</span><strong>${esc(gtq(stats.facturacion_gtq))}</strong></div><div class="map-stat"><span>${esc(t('mapPreventa'))}</span><strong>${esc(gtq(stats.preventa_gtq))}</strong></div><div class="map-stat"><span>${esc(t('mapSellers'))}</span><strong>${esc(String(entry.sellerCount))}</strong></div><div class="map-stat"><span>${esc(t('difference'))}</span><strong>${esc(signedGtq(stats.diferencia_gtq))}</strong></div></div>
    <div class="map-focus-actions"><a class="button button-outline map-filter-button" href="#vendedores" data-map-filter="${esc(location.region)}">${esc(t('mapFilterSellers'))} <span aria-hidden="true">↘</span></a></div>`;
}
function downloadMapCsv(){
  const entries=getMapEntries();if(!entries.length){showToast(t('mapNoLocations'));return;}
  const escapeCell=value=>'"'+String(value??'').replace(/"/g,'""')+'"';
  const rows=[[t('mapRegionHeader'),t('mapCityHeader'),t('mapLatHeader'),t('mapLonHeader'),t('mapSourceHeader'),t('mapSourceUrlHeader')],...entries.map(({location})=>[location.region,location.city,Number(location.latitude).toFixed(5),Number(location.longitude).toFixed(5),location.source,location.source_url])];
  const csv='\ufeff'+rows.map(row=>row.map(escapeCell).join(',')).join('\r\n'),url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),link=document.createElement('a');
  link.href=url;link.download='ema_mayoreo_centros_urbanos_referencia.csv';document.body.appendChild(link);link.click();link.remove();window.setTimeout(()=>URL.revokeObjectURL(url),1000);announceDownload(t('mapCsvSaved'));
}
async function copyMapCoordinates(region){
  const entry=getMapEntries().find(item=>item.location.region===region);if(!entry)return;
  try{await navigator.clipboard.writeText(Number(entry.location.latitude).toFixed(5)+', '+Number(entry.location.longitude).toFixed(5));showToast(t('mapCoordinatesCopied'));}
  catch(_){showToast(t('shareFailed'));}
}
function selectMapRegion(region){
  if(!getMapEntries().some(entry=>entry.location.region===region))return;
  activeMapRegion=region;renderMap();
}
function renderReconciliation(){
  const c=state.summary.official_controls,r=state.summary.internal_reconciliation,count=state.summary.counts.routes,imported=state.summary.source==='SQLite importada';
  const lines=[
    [t('routePreventa',{count}),gtq(r.route_preventa_sum_gtq),''],
    [t('routeBilling',{count}),gtq(r.route_facturacion_sum_gtq),''],
    [t(imported?'routeAdjustmentsImported':'routeAdjustments'),gtq(r.adjustment_gtq),'muted-line'],
    [t(imported?'databaseBilling':'officialBilling'),gtq(c.facturacion_gtq),'total'],
    [t(imported?'databasePreventa':'officialPreventa'),gtq(c.preventa_gtq),''],
    [t(imported?'databaseDifference':'officialDiff'),signedGtq(c.diferencia_gtq),'total']
  ];
  document.getElementById('reconBox').innerHTML='<div class="recon-lines">'+lines.map(([label,value,cls])=>'<div class="recon-line '+cls+'"><span>'+esc(label)+'</span><strong>'+esc(value)+'</strong></div>').join('')+'</div><div class="recon-callout">'+esc(t(imported?'reconciliationCalloutImported':'reconciliationCallout',{amount:gtq(r.adjustment_gtq)}))+'</div>';
}
function renderFocus(){
  const count=state.summary.counts.routes,imported=state.summary.source==='SQLite importada';
  const items=imported?[['1','focusOneTitleImported','focusOneBodyImported'],['2','focusTwoTitleImported','focusTwoBodyImported'],['3','focusThreeTitleImported','focusThreeBodyImported']]:[['1','focusOneTitle','focusOneBody'],['2','focusTwoTitle','focusTwoBody'],['3','focusThreeTitle','focusThreeBody']];
  document.getElementById('focusBox').innerHTML=items.map(([n,title,body])=>'<div class="focus-item"><div class="focus-icon" aria-hidden="true">'+n+'</div><div><strong>'+esc(t(title))+'</strong><span>'+esc(t(body,{count}))+'</span></div></div>').join('');
}
function populateRegions(){
  const select=document.getElementById('regionSelect'),selected=select.value;
  select.innerHTML='<option value="">'+esc(t('allRegions'))+'</option>'+state.regions.map(r=>'<option value="'+esc(r.region)+'">'+esc(r.region)+'</option>').join('');
  if([...select.options].some(option=>option.value===selected))select.value=selected;
}
function normalize(value){return String(value??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase(localeMap[locale]);}
function getFilteredSellers(){
  const query=normalize(document.getElementById('searchInput').value.trim());
  const region=document.getElementById('regionSelect').value;
  const sort=document.getElementById('sortSelect').value;
  const sourceRows=region?state.rows.filter(row=>row.region===region):state.rows;
  const sellers=groupedSellers(sourceRows).filter(item=>!query||normalize(item.seller+' '+item.region).includes(query));
  if(sort==='gap-asc')sellers.sort((a,b)=>a.diferencia_gtq-b.diferencia_gtq);
  else if(sort==='pct-desc')sellers.sort((a,b)=>b.cumplimiento_pct-a.cumplimiento_pct);
  else if(sort==='seller-asc')sellers.sort((a,b)=>a.seller.localeCompare(b.seller,'es-GT',{sensitivity:'base'}));
  else sellers.sort((a,b)=>b.facturacion_gtq-a.facturacion_gtq);
  return sellers;
}
function renderTable(){
  const data=getFilteredSellers(),all=groupedSellers();state.filtered=data;
  const billing=data.reduce((sum,item)=>sum+item.facturacion_gtq,0),preventa=data.reduce((sum,item)=>sum+item.preventa_gtq,0);
  document.getElementById('tableSummary').innerHTML='<span>'+esc(t('showingSellers',{shown:data.length,total:all.length}))+'</span><span>'+esc(t('filteredTotals',{billing:gtq(billing),preventa:gtq(preventa)}))+'</span>';
  document.getElementById('filteredCsvBtn').disabled=data.length===0;
  const body=document.querySelector('#sellersTable tbody');
  body.setAttribute('aria-busy','false');
  if(!data.length){body.innerHTML='<tr><td colspan="7" class="no-data">'+esc(t('noSellers'))+'</td></tr>';window.EmaMotion?.refresh();return;}
  body.innerHTML=data.map((seller,index)=>{
    const good=seller.cumplimiento_pct>=100;
    return'<tr class="seller-row" style="--row-order:'+Math.min(index,12)+'"><td class="seller-cell">'+esc(seller.seller)+'</td><td><span class="region-chip">'+esc(seller.region)+'</span></td><td class="num">'+esc(gtq(seller.preventa_gtq))+'</td><td class="num">'+esc(gtq(seller.facturacion_gtq))+'</td><td class="num '+(seller.diferencia_gtq>=0?'delta-pos':'delta-neg')+'">'+esc(signedGtq(seller.diferencia_gtq))+'</td><td class="num"><span class="pct-chip '+(good?'good':'low')+'">'+esc(pct(seller.cumplimiento_pct))+'</span></td><td class="num"><button class="row-btn" type="button" data-seller="'+esc(seller.seller)+'">'+esc(t('detail'))+'</button></td></tr>';
  }).join('');
  window.EmaMotion?.refresh();
}
function addAuditCard(type,icon,titleKey,bodyKey,vars={}){
  const article=document.createElement('article');article.className='audit-card '+type;
  article.innerHTML='<div class="audit-title"><span class="audit-icon" aria-hidden="true">'+esc(icon)+'</span>'+esc(t(titleKey))+'</div><div class="audit-body">'+esc(t(bodyKey,vars))+'</div>';
  document.getElementById('auditBox').appendChild(article);
}
function renderAudit(){
  const audit=state.audit,imported=state.summary.source==='SQLite importada';
  const items=imported?[['good','✓','auditDatabaseSourceTitle','auditDatabaseSourceBody'],['good','✓','auditDatabaseReconTitle','auditDatabaseReconBody']]:[['good','✓','auditSourceTitle','auditSourceBody'],[state.summary.internal_reconciliation.status==='OK'?'good':'warn','✓','auditReconTitle','auditReconBody']];
  if(audit.label_corrections?.length){
    const details=audit.label_corrections.map(item=>String(item.route_id)+': '+String(item.was)+' → '+String(item.now)).join(' · ');
    items.push(['warn','↔','auditLabelsTitle','auditLabelsBody',{details}]);
  }
  const host=document.getElementById('auditBox');host.replaceChildren();
  items.forEach(item=>addAuditCard(...item));
  const variance=audit.preventa_discrepancies_vs_daily?.[0];
  if(variance)addAuditCard('warn','!','auditVarianceTitle','auditVarianceBody',{route:variance.route_id,date:formatDate(variance.date),official:gtq(variance.official_preventa_gtq),daily:gtq(variance.raw_daily_importe_vendedor_gtq)});
  const extra=audit.extra_raw_routes_not_in_consolidado?.[0];
  if(extra)addAuditCard('warn','i','auditExtraTitle','auditExtraBody',{route:extra.route_id,seller:shortName(extra.seller),amount:gtq(extra.preventa_gtq)});
  const mix=audit.mixed_fact_sources?.[0];
  if(mix)addAuditCard('warn','↔','auditMixTitle','auditMixBody',{route:mix.route_id,sources:(mix.sources||[]).join(', ')});
  const formulaIssue=audit.daily_billing_formula_issues?.[0];
  if(formulaIssue)addAuditCard('warn','Σ','dailyFormulaAuditTitle','dailyFormulaAuditBody',{cell:formulaIssue.cell,routes:(formulaIssue.missing_routes||[]).join(', '),amount:gtq(formulaIssue.missing_facturacion_gtq)});
  const periodIssue=audit.period_label_issues?.[0];
  if(periodIssue)addAuditCard('warn','⌁','dailyPeriodAuditTitle','dailyPeriodAuditBody',{label:periodIssue.source_label,years:(periodIssue.actual_years||[]).join(', ')});
  const unassigned=audit.unassigned_adjustments||[];
  if(unassigned.length){
    const details=unassigned.map(item=>[item.label||item.region||'Sin etiqueta',item.region&&item.label?' · '+item.region:'',': ',gtq(item.facturacion_gtq)].join('')).join(' · ');
    addAuditCard('warn','↗','dailyAdjustmentsAuditTitle','dailyAdjustmentsAuditBody',{details});
  }
}
function openSeller(sellerName,trigger){
  const rows=state.rows.filter(row=>(shortName(row.seller)||'Sin vendedor')===sellerName);
  const seller=groupedSellers(rows).find(item=>item.seller===sellerName);
  if(!rows.length||!seller)return;
  lastFocus=trigger||document.activeElement;
  const dailyMap=new Map();
  for(const row of rows){
    const key=String(row.date||'');
    if(!dailyMap.has(key))dailyMap.set(key,{date:key,preventa_gtq:0,facturacion_gtq:0,diferencia_gtq:0});
    const day=dailyMap.get(key);
    day.preventa_gtq+=safeNumber(row.preventa_gtq);day.facturacion_gtq+=safeNumber(row.facturacion_gtq);day.diferencia_gtq+=safeNumber(row.diferencia_gtq);
  }
  const daily=[...dailyMap.values()].sort((a,b)=>a.date.localeCompare(b.date));
  document.getElementById('modalTitle').textContent=seller.seller;
  const metrics=[['routePreventaShort',gtq(seller.preventa_gtq)],['routeBillingShort',gtq(seller.facturacion_gtq)],['routeDiffShort',signedGtq(seller.diferencia_gtq)],['routeCompletionShort',pct(seller.cumplimiento_pct)]];
  const totals='<div class="region-chip">'+esc(seller.region)+'</div><div class="detail-grid">'+metrics.map(([label,value])=>'<div class="detail-card"><div class="label">'+esc(t(label))+'</div><div class="value">'+esc(value)+'</div></div>').join('')+'</div>';
  const note='<div class="detail-note">'+esc(t(state.summary.source==='SQLite importada'?'detailDataNoteImported':'detailDataNote'))+'</div>';
  const tableHead='<div class="daily-mini" tabindex="0"><table><thead><tr><th scope="col">'+esc(t('date'))+'</th><th scope="col" class="num">'+esc(t('preventa'))+'</th><th scope="col" class="num">'+esc(t('billing'))+'</th><th scope="col" class="num">'+esc(t('difference'))+'</th><th scope="col" class="num">'+esc(t('completion'))+'</th></tr></thead><tbody>';
  const tableBody=daily.map(row=>'<tr><td>'+esc(formatDate(row.date))+'</td><td class="num">'+esc(gtq(row.preventa_gtq))+'</td><td class="num">'+esc(gtq(row.facturacion_gtq))+'</td><td class="num '+(row.diferencia_gtq>=0?'delta-pos':'delta-neg')+'">'+esc(signedGtq(row.diferencia_gtq))+'</td><td class="num">'+esc(pct(row.preventa_gtq?row.facturacion_gtq/row.preventa_gtq*100:0))+'</td></tr>').join('');
  document.getElementById('modalBody').innerHTML=totals+note+tableHead+tableBody+'</tbody></table></div>';
  const modal=document.getElementById('sellerModal');modal.classList.remove('hidden');document.body.style.overflow='hidden';
  requestAnimationFrame(()=>modal.querySelector('.modal-close').focus());
}
function closeModal(){
  const modal=document.getElementById('sellerModal');if(modal.classList.contains('hidden'))return;
  modal.classList.add('hidden');document.body.style.overflow='';
  if(lastFocus?.focus)lastFocus.focus();
}
function showToast(message,type='info'){
  const toast=document.getElementById('toast');
  const icons={success:'✓',info:'i',warning:'!',error:'×'},icon=document.createElement('span'),copy=document.createElement('span');
  icon.className='toast-icon';icon.setAttribute('aria-hidden','true');icon.textContent=icons[type]||icons.info;
  copy.className='toast-copy';copy.textContent=String(message||'');toast.replaceChildren(icon,copy);toast.dataset.type=type;toast.classList.add('visible');
  window.clearTimeout(toastTimer);toastTimer=window.setTimeout(()=>toast.classList.remove('visible'),2600);
}
function announceDownload(message){
  window.EmaLoaders?.announce(message);
  showToast(message,'success');
}
async function downloadServerFile(path,fallbackName,message){
  const controller=new AbortController(),timeout=window.setTimeout(()=>controller.abort(),90000);
  setFooterStatus(message,{busy:true,progress:null});
  try{
    let chunks=[],contentType='application/octet-stream',disposition='',total=0;
    if(window.chrome?.webview){
      const native=await requestNativeDownload(path,(loaded,length)=>{
        total=length;
        const value=length?Math.min(100,Math.round(loaded/length*100)):null;
        setFooterStatus(value===null?message:`${message} · ${value}%`,{busy:true,progress:value});
      });
      chunks=native.parts;contentType=native.contentType;disposition=native.contentDisposition;total=native.parts.reduce((sum,part)=>sum+part.byteLength,0);
      setFooterStatus(total?`${message} · 100%`:message,{busy:true,progress:total?100:null});
    }else{
      const response=await fetch(path,{cache:'no-store',signal:controller.signal});
      if(!response.ok)throw new Error('EMA MAYOREO no pudo preparar el archivo local.');
      const rawLength=Number(response.headers.get('Content-Length'));
      total=Number.isFinite(rawLength)&&rawLength>0?rawLength:0;
      let loaded=0,lastPaint=0;
      if(response.body?.getReader){
        const reader= response.body.getReader();
        while(true){
          const part=await reader.read();if(part.done)break;
          if(part.value){chunks.push(part.value);loaded+=part.value.byteLength;}
          const now=performance.now();
          if(now-lastPaint>=80||loaded===total){
            const value=total?Math.min(100,Math.round(loaded/total*100)):null;
            setFooterStatus(value===null?message:`${message} · ${value}%`,{busy:true,progress:value});
            lastPaint=now;
          }
        }
      }else{
        const buffer=await response.arrayBuffer();chunks.push(buffer);loaded=buffer.byteLength;
        setFooterStatus(total?`${message} · 100%`:message,{busy:true,progress:total?100:null});
      }
      contentType=response.headers.get('Content-Type')||contentType;
      disposition=response.headers.get('Content-Disposition')||'';
    }
    const suggested=disposition.match(/filename\*?=(?:UTF-8''|\")?([^\";]+)/i)?.[1];
    const filename=suggested?decodeURIComponent(suggested.replace(/"/g,'')):fallbackName;
    const blob=new Blob(chunks,{type:contentType});
    const url=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=url;link.download=filename;document.body.appendChild(link);link.click();link.remove();
    window.setTimeout(()=>URL.revokeObjectURL(url),30000);
    window.EmaLoaders?.announce('Archivo preparado para descargar.');
    showToast('Archivo preparado para descargar.','success');
  }catch(error){
    if(error?.name==='AbortError')error=new Error('La descarga tardó demasiado. Vuelve a intentarlo.');
    setFooterStatus(error.message||'No se pudo descargar el archivo.',{state:'error'});
    showToast(error.message||'No se pudo descargar el archivo.','error');
  }finally{window.clearTimeout(timeout);}
}
function downloadCsv(){
  const query=selectedMonth?`?month=${encodeURIComponent(selectedMonth)}`:'';
  downloadServerFile(`/ventas_consolidado_canonical.csv${query}`,'ventas_consolidado_canonical.csv',t('csvSaved'));
}
function csvField(value){return'"'+String(value??'').replace(/"/g,'""')+'"';}
function downloadFilteredCsv(){
  if(!state.filtered.length){showToast(t('noSellers'));return;}
  const columns=['Vendedor','Región','Preventa (Q)','Facturación (Q)','Diferencia (Q)','Cumplimiento (%)','Días con datos'];
  const rows=state.filtered.map(item=>[item.seller,item.region,item.preventa_gtq,item.facturacion_gtq,item.diferencia_gtq,item.cumplimiento_pct,item.days]);
  const csv='\uFEFF'+[columns,...rows].map(row=>row.map(csvField).join(',')).join('\r\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),link=document.createElement('a');
  link.href=url;link.download='ema_mayoreo_vendedores_filtrados.csv';document.body.appendChild(link);link.click();link.remove();
  window.setTimeout(()=>URL.revokeObjectURL(url),1000);announceDownload(t('csvFilteredSaved'));
}
const nativeUploadTransfers=new Map();
if(window.chrome?.webview){
  window.chrome.webview.addEventListener('message',event=>{
    const message=event.data||{},transfer=nativeUploadTransfers.get(String(message.id||''));
    if(!transfer)return;
    if(message.type==='ema-upload-ack'){
      if(Number(message.index)===transfer.waitingIndex&&transfer.acknowledge){
        const acknowledge=transfer.acknowledge;transfer.acknowledge=null;transfer.waitingIndex=-1;acknowledge();
      }
      return;
    }
    if(message.type==='ema-upload-result'){
      if(transfer.acknowledge){const acknowledge=transfer.acknowledge;transfer.acknowledge=null;acknowledge(false);}
      nativeUploadTransfers.delete(String(message.id));
      transfer.resolve({ok:Boolean(message.ok),result:message.result||{ok:false,error:message.error||'No se pudo importar el Excel.'}});
    }
  });
}
function readChunkAsBase64(blob){
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onerror=()=>reject(new Error('No se pudo leer el Excel seleccionado.'));
    reader.onload=()=>resolve(String(reader.result||'').split(',')[1]||'');
    reader.readAsDataURL(blob);
  });
}
function uploadHistoryWorkbook(file,month,mode){
  const bridge=window.chrome?.webview;
  // En el navegador normal, la carga usa la API local del servidor web.
  // La aplicación instalada conserva su transferencia por bloques en WebView2.
  if(!bridge)return uploadHistoryWorkbookFromBrowser(file,month,mode);
  return new Promise((resolve,reject)=>{
    if(!file.size){reject(new Error('El archivo Excel está vacío. Selecciona otro archivo.'));return;}
    const id=window.crypto?.randomUUID?window.crypto.randomUUID():`ema-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const chunkBytes=512*1024,count=Math.ceil(file.size/chunkBytes);
    const transfer={resolve,reject,acknowledge:null,waitingIndex:-1,cancelled:false,uploadComplete:false};
    nativeUploadTransfers.set(id,transfer);
    const abortError=()=>{const error=new Error('Carga cancelada. No se modificaron los datos.');error.name='AbortError';return error;};
    const cancel=()=>{
      if(transfer.uploadComplete)return;
      transfer.cancelled=true;nativeUploadTransfers.delete(id);
      try{bridge.postMessage({type:'ema-upload-cancel',id});}catch(_){ }
      if(transfer.acknowledge){const acknowledge=transfer.acknowledge;transfer.acknowledge=null;acknowledge(false);}
      reject(abortError());
    };
    window.EmaLoaders?.showOverlay({title:'Importando Excel',message:'Preparando el libro…',detail:'0% · Puedes cancelar durante la transferencia.',progress:0,cancelText:'Cancelar carga',onCancel:cancel});
    setFooterStatus('Preparando Excel…',{busy:true,progress:0});

    (async()=>{
      try{
        for(let index=0;index<count;index++){
          if(transfer.cancelled)return;
          const start=index*chunkBytes,end=Math.min(file.size,start+chunkBytes);
          const data=await readChunkAsBase64(file.slice(start,end));
          if(transfer.cancelled)return;
          const acknowledged=new Promise((ackResolve,ackReject)=>{
            transfer.waitingIndex=index;
            transfer.acknowledge=ok=>ok===false?ackReject(abortError()):ackResolve();
          });
          bridge.postMessage({type:'ema-upload-chunk',id,index,count,size:file.size,month,mode,filename:file.name,data});
          if(index===count-1){
            transfer.uploadComplete=true;
            window.EmaLoaders?.updateOverlay({title:'Revisando el libro',message:'Validando datos y totales…',detail:'El archivo llegó. Se están procesando las hojas oficiales.',progress:null,cancelable:false});
            setFooterStatus('Validando y guardando el mes…',{busy:true,progress:null});
          }
          await acknowledged;
          const value=Math.round(end/file.size*100),loaded=new Intl.NumberFormat('es-GT',{maximumFractionDigits:0}).format(end/1024),total=new Intl.NumberFormat('es-GT',{maximumFractionDigits:0}).format(file.size/1024);
          window.EmaLoaders?.updateOverlay({message:`Subiendo el Excel… ${value}%`,detail:`${loaded} KB de ${total} KB transferidos.`,progress:value});
          setFooterStatus(`Subiendo Excel · ${value}%`,{busy:true,progress:value});
        }
        if(transfer.cancelled)return;
      }catch(error){
        nativeUploadTransfers.delete(id);reject(error);
      }
    })();
  });
}
async function uploadHistoryWorkbookFromBrowser(file,month,mode){
  if(!file.size)throw new Error('El archivo Excel está vacío. Selecciona otro archivo.');
  const form=new FormData();
  form.append('file',file,file.name);
  const controller=new AbortController();
  const timeout=window.setTimeout(()=>controller.abort(),180000);
  window.EmaLoaders?.showOverlay({title:'Importando Excel',message:'Subiendo y validando el libro…',detail:'Se comprueban las hojas oficiales, el mes y la conciliación antes de guardar.',progress:null,cancelable:false});
  setFooterStatus('Subiendo y validando Excel…',{busy:true,progress:null});
  try{
    const response=await fetch(`/api/history/import?month=${encodeURIComponent(month)}&mode=${encodeURIComponent(mode||'add')}`,{
      method:'POST',headers:{'X-EMA-Import':'ema-panel-import'},body:form,cache:'no-store',signal:controller.signal
    });
    const result=await response.json().catch(()=>({ok:false,error:'El servidor devolvió una respuesta que no se pudo leer.'}));
    return {ok:response.ok,result};
  }catch(error){
    if(error?.name==='AbortError')throw new Error('La importación tardó demasiado. Los datos anteriores se conservaron.');
    throw new Error(error?.message||'No se pudo conectar con el procesador local.');
  }finally{window.clearTimeout(timeout);}
}
async function importHistoryFile(file){
  if(!file)return;
  if(!importAvailable){setImportStatus('importNeedsPython');return;}
  // Do not trust the filename or extension: the backend validates the actual XLSX bytes and worksheet contents.
  if(file.size>30*1024*1024){setImportStatus('importTooLarge');return;}
  const month=document.getElementById('historyMonthInput').value,mode=document.getElementById('historyModeSelect').value||'add';
  if(!/^\d{4}-\d{2}$/.test(month)){showHistoryStatus('Selecciona primero el mes que corresponde al Excel.','warning');return;}
  const exists=state.history.some(item=>item.month===month);
  if(mode==='add'&&exists){showHistoryStatus('Ese mes ya tiene un historial. Cambia la acción a “Reemplazar el mes guardado” o elige otro mes.','warning');updateImportModeHelp();return;}
  if(mode==='replace'&&!exists){showHistoryStatus('Ese mes aún no existe. Cambia la acción a “Agregar como mes nuevo”.','warning');updateImportModeHelp();return;}
  if(mode==='replace'&&!window.confirm(`Vas a reemplazar los datos y el Excel original de ${monthLabel(month)}. Los demás meses no se modificarán. ¿Continuar?`)){showHistoryStatus('Reemplazo cancelado. No se modificó ningún dato.');return;}
  importInProgress=true;refreshImportSupport();showHistoryStatus('Validando el Excel y guardando el mes…','busy');
  try{
    const response=await uploadHistoryWorkbook(file,month,mode),result=response.result;
    if(!response.ok||!result.ok)throw new Error(result.error||'No se pudo guardar el mes.');
    const historyData=await getJSON('/api/history');
    state.history=Array.isArray(historyData.months)?historyData.months:[];
    syncSelectedMonth(result.month);
    showHistoryStatus(`${monthLabel(result.month)} ${mode==='replace'?'se reemplazó':'quedó guardado'}. Los demás meses se conservaron.`, 'success');
    const loaded=await load();if(!loaded)throw new Error('El mes quedó guardado, pero el panel no pudo cargarlo. Usa Actualizar para volver a intentar.');
    closeExcelImportModal();document.getElementById('historyMonthInput').value='';pickDefaultHistoryMonth();
    setFooterStatus(`${monthLabel(result.month)} ${mode==='replace'?'reemplazado':'guardado'}`,{state:'success'});
  }catch(error){
    const cancelled=error?.name==='AbortError',message=error.message||'No se pudo guardar el mes.';
    showHistoryStatus(message,'warning');showToast(message,cancelled?'info':'error');
    setFooterStatus(message,{state:cancelled?'idle':'error'});
  }
  finally{window.EmaLoaders?.hideOverlay();importInProgress=false;refreshImportSupport();}
}
function showHistoryStatus(message,kind=''){
  const node=document.getElementById('historyStatus');if(!node)return;
  node.textContent=message;node.className=`history-status-note${kind?` is-${kind}`:''}`;
}
async function deleteActiveDatabase(){
  if(!databaseManagementAvailable||importInProgress||loadInProgress||(!baseDatabaseAvailable&&!baseSourceAvailable&&!state.history.length))return;
  const confirmation=window.prompt('Esta acción eliminará TODOS los meses guardados, los Excel originales y la base activa. No se puede deshacer. Escribe BORRAR TODO para confirmar:');
  if(confirmation!=='BORRAR TODO')return;
  importInProgress=true;refreshImportSupport();setImportStatus('databaseWorking');
  window.EmaLoaders?.showOverlay({title:'Reiniciando la base de datos',message:'Eliminando los datos y los historiales mensuales…',detail:'La información de todos los meses se eliminará.',progress:null});
  setFooterStatus('Eliminando toda la base de datos…',{busy:true,progress:null});
  try{
    let result;
    if(window.chrome?.webview)result=await requestNativeJson('/api/database?scope=all',{method:'DELETE',headers:{'X-EMA-Management':'ema-panel-management'}});
    else{const response=await fetch('/api/database?scope=all',{method:'DELETE',headers:{'X-EMA-Management':'ema-panel-management'},cache:'no-store'});result=await response.json().catch(()=>({}));if(!response.ok)throw new Error(result.error||'No se pudo borrar la base de datos.');}
    if(!result?.ok)throw new Error(result?.error||'No se pudo borrar la base de datos.');
    selectedMonth='';try{localStorage.removeItem('ema.activeMonth');}catch(_){}
    const url=new URL(location.href);url.searchParams.delete('month');history.replaceState({},'',url);
    if(!await load())throw new Error('La base se eliminó, pero el panel no pudo actualizar la vista. Pulsa Actualizar.');
    setImportStatus('databaseDeleted');showToast('La base de datos y todos los historiales se eliminaron.','success');
  }catch(error){setImportStatus('databaseDeleteFailed');showToast(error.message||'No se pudo borrar la base de datos.','error');setFooterStatus('No se pudo completar el borrado',{state:'error'});}
  finally{window.EmaLoaders?.hideOverlay();importInProgress=false;refreshImportSupport();}
}

function downloadFile(path){
  const query=selectedMonth?`${path.includes('?')?'&':'?'}month=${encodeURIComponent(selectedMonth)}`:'';
  downloadServerFile(`${path}${query}`,`EMA-MAYOREO-${selectedMonth||'base'}.xlsx`,'Descargando Excel original…');
}
function showWelcome(){
  let seen=false;try{seen=sessionStorage.getItem('ema-panel-welcome')==='seen';}catch(_){}
  if(seen)return;
  const overlay=document.getElementById('welcomeOverlay');overlay.classList.remove('hidden');document.querySelector('.app-shell').setAttribute('inert','');
  requestAnimationFrame(()=>{window.EmaMotion?.animateWelcome();document.getElementById('welcomeEnter').focus();});
}
function closeWelcome(){
  const overlay=document.getElementById('welcomeOverlay');if(overlay.classList.contains('hidden'))return;
  overlay.classList.add('hidden');document.querySelector('.app-shell').removeAttribute('inert');
  try{sessionStorage.setItem('ema-panel-welcome','seen');}catch(_){}
  document.getElementById('inicio').focus({preventScroll:true});
  requestAnimationFrame(()=>window.EmaMotion?.playEntrance(true));
}
function wire(){
  document.getElementById('searchInput').addEventListener('input',renderTable);
  document.getElementById('regionSelect').addEventListener('change',()=>{
    renderTable();const region=document.getElementById('regionSelect').value;if(region)activeMapRegion=region;renderMap();
  });
  document.getElementById('sortSelect').addEventListener('change',renderTable);
  document.getElementById('clearFiltersBtn').addEventListener('click',()=>{
    document.getElementById('searchInput').value='';document.getElementById('regionSelect').value='';document.getElementById('sortSelect').value='fact-desc';activeMapRegion='';renderTable();renderMap();document.getElementById('searchInput').focus();
  });
  document.querySelectorAll('[data-trend-mode]').forEach(button=>button.addEventListener('click',()=>{
    trendMode=button.dataset.trendMode;
    document.querySelectorAll('[data-trend-mode]').forEach(option=>{const active=option===button;option.classList.toggle('is-active',active);option.setAttribute('aria-pressed',String(active));});
    drawTrend();
  }));
  document.getElementById('mapMetricSelect').addEventListener('change',renderMap);
  document.getElementById('mapExportBtn').addEventListener('click',downloadMapCsv);
  for(const hostId of ['mapMarkers','mapPlaceList'])document.getElementById(hostId).addEventListener('click',event=>{
    const button=event.target.closest('[data-map-region]');if(button)selectMapRegion(button.dataset.mapRegion);
  });
  document.getElementById('mapFocus').addEventListener('click',event=>{
    const filter=event.target.closest('[data-map-filter]');
    if(filter){event.preventDefault();const region=filter.dataset.mapFilter;activeMapRegion=region;document.getElementById('regionSelect').value=region;renderMap();renderTable();document.getElementById('vendedores').scrollIntoView({behavior:'smooth',block:'start'});return;}
    const copy=event.target.closest('[data-copy-coordinates]');if(copy)copyMapCoordinates(copy.dataset.copyCoordinates);
  });
  document.getElementById('refreshBtn').addEventListener('click',load);
  document.getElementById('fullscreenBtn').addEventListener('click',async()=>{
    try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen?.();else await document.exitFullscreen?.();}
    catch(_){showToast(t('fullscreenFailed'),'error');}
  });
  document.addEventListener('fullscreenchange',()=>{
    const button=document.getElementById('fullscreenBtn'),key=document.fullscreenElement?'exitFullscreen':'fullscreen';
    button.setAttribute('aria-label',t(key));button.title=t(key);
  });
  document.getElementById('printBtn').addEventListener('click',()=>window.print());
  document.getElementById('shareBtn').addEventListener('click',async()=>{
    try{
      if(navigator.share)await navigator.share({title:document.title,url:location.href});
      else if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(location.href);showToast(t('copied'));}
      else showToast(t('shareFailed'));
    }catch(error){if(error?.name!=='AbortError')showToast(t('shareFailed'));}
  });
  document.getElementById('csvBtn').addEventListener('click',downloadCsv);
  document.getElementById('filteredCsvBtn').addEventListener('click',downloadFilteredCsv);
  document.getElementById('dailyDownloadBtn').addEventListener('click',downloadDailyCsv);
  document.getElementById('historyJumpBtn').addEventListener('click',()=>{document.getElementById('historial').scrollIntoView({behavior:'smooth',block:'start'});});
  document.getElementById('addMonthBtn').addEventListener('click',()=>openExcelImportModal('add',nextAvailableMonth()));
  document.getElementById('insertExcelBtn').addEventListener('click',()=>{const month=selectedMonth||currentMonthValue();openExcelImportModal(state.history.some(item=>item.month===month)?'replace':'add',month);});
  document.getElementById('historyInsertBtn').addEventListener('click',()=>openExcelImportModal('add',nextAvailableMonth()));
  document.getElementById('historyChooseFileBtn').addEventListener('click',()=>{if(importAvailable&&!importInProgress)document.getElementById('historyFileInput').click();});
  document.getElementById('monthSelector').addEventListener('change',event=>{const month=event.target.value;if(month==='__new__'){event.target.value=selectedMonth||state.history[0]?.month||'__new__';openExcelImportModal('add',nextAvailableMonth());return;}if(month)openHistoryMonth(month);});
  document.getElementById('historyModeSelect').addEventListener('change',updateImportModeHelp);
  document.getElementById('excelImportModal').addEventListener('click',event=>{if(event.target.closest('[data-close-import]'))closeExcelImportModal();});
  document.getElementById('historyMonthInput').addEventListener('change',updateImportModeHelp);
  document.getElementById('sidebarMonthList').addEventListener('click',event=>{const button=event.target.closest('[data-sidebar-month]');if(button)openHistoryMonth(button.dataset.sidebarMonth);});
  document.getElementById('historyFileInput').addEventListener('change',event=>{const file=event.target.files?.[0];event.target.value='';importHistoryFile(file);});
  document.getElementById('historyList').addEventListener('click',event=>{
    const add=event.target.closest('[data-history-add]');if(add){openExcelImportModal('add',nextAvailableMonth());return;}
    const remove=event.target.closest('[data-history-delete]');if(remove){deleteHistoryMonth(remove.dataset.historyDelete);return;}
    const download=event.target.closest('[data-history-download]');
    if(download){event.preventDefault();const month=download.dataset.historyDownload;downloadServerFile(`/source.xlsx?month=${encodeURIComponent(month)}`,`EMA-MAYOREO-base-${month}.xlsx`,'Descargando Excel del historial…');return;}
    const button=event.target.closest('[data-history-open]');if(button)openHistoryMonth(button.dataset.historyOpen);
  });
  document.getElementById('deleteDatabaseBtn').addEventListener('click',deleteActiveDatabase);
  document.getElementById('downloadSourceBtn').addEventListener('click',()=>{if(sourceAvailable)downloadFile('/source.xlsx');});
  document.getElementById('welcomeEnter').addEventListener('click',closeWelcome);
  document.getElementById('sellersTable').addEventListener('click',event=>{const button=event.target.closest('[data-seller]');if(button)openSeller(button.dataset.seller,button);});
  document.getElementById('sellerModal').addEventListener('click',event=>{if(event.target.dataset.close)closeModal();});
  document.addEventListener('keydown',event=>{
    const welcome=document.getElementById('welcomeOverlay');
    if(!welcome.classList.contains('hidden')){
      if(event.key==='Escape'){closeWelcome();return;}
      if(event.key==='Tab'){event.preventDefault();document.getElementById('welcomeEnter').focus();}
      return;
    }
    if(event.key==='Escape'){closeModal();closeExcelImportModal();}
    if(event.key.toLowerCase()==='r'&&!['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName)&&!event.ctrlKey&&!event.metaKey&&!event.altKey)load();
    if(event.key==='/'&&!['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName)&&!event.ctrlKey&&!event.metaKey){event.preventDefault();document.getElementById('searchInput').focus();}
    const modal=document.getElementById('sellerModal');
    if(event.key==='Tab'&&!modal.classList.contains('hidden')){
      const focusable=[...modal.querySelectorAll('button:not([disabled]),[tabindex="0"]')];
      if(!focusable.length)return;
      const first=focusable[0],last=focusable[focusable.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
  });
  window.EmaMotion?.init();
}
function renderDashboard(){
  if(!state.summary)return;
  applyDatasetLanguage();
  window.EmaQualityAssistant?.render(state.history.find(item=>item.month===selectedMonth)?.quality_report,selectedMonth);
  setHero();renderKpis();renderInsights();drawTrend();renderDailyControl();renderRegions();populateRegions();renderTable();renderMap();renderReconciliation();renderFocus();renderAudit();
  renderHistory();window.EmaMotion?.refresh();
}
async function load(){
  if(loadInProgress)return false;
  loadInProgress=true;
  const button=document.getElementById('refreshBtn'),isRefresh=Boolean(state.summary);button.classList.add('is-loading');button.disabled=true;button.setAttribute('aria-busy','true');
  refreshImportSupport();
  document.documentElement.classList.add('is-refreshing');
  setFooterStatus('Consultando historial y datos locales…',{busy:true,progress:null});
  if(!state.summary){document.getElementById('kpiGrid').setAttribute('aria-busy','true');document.querySelector('#sellersTable tbody').setAttribute('aria-busy','true');}
  try{
    const historyPayload=await getJSON('/api/history');
    if(!Array.isArray(historyPayload?.months))throw new Error('Invalid history payload');
    state.history=historyPayload.months;
    const availableMonths=new Set(state.history.map(item=>item.month));
    let desiredMonth=new URLSearchParams(location.search).get('month');
    if(!availableMonths.has(desiredMonth)){try{desiredMonth=localStorage.getItem('ema.activeMonth');}catch(_){desiredMonth='';}}
    if(!availableMonths.has(desiredMonth))desiredMonth=availableMonths.has(selectedMonth)?selectedMonth:(state.history[0]?.month||'');
    if(desiredMonth)syncSelectedMonth(desiredMonth);else syncSelectedMonth('');
    const [health,summary,regions,rows,daily,audit,locations]=await Promise.all([getJSON('/api/health'),getJSON('/api/summary'),getJSON('/api/regions'),getJSON('/api/rows'),getJSON('/api/daily'),getJSON('/api/audit'),getJSON('/api/locations')]);
    if(!health?.ok||typeof health.can_import!=='boolean'||typeof health.can_manage_database!=='boolean'||typeof health.database_available!=='boolean'||typeof health.source_available!=='boolean'||typeof health.base_database_available!=='boolean'||typeof health.base_source_available!=='boolean'||!summary?.official_controls||!Array.isArray(rows?.rows)||!Array.isArray(daily?.daily_totals)||!Array.isArray(regions)||!audit?.official_summary||!Array.isArray(locations?.locations))throw new Error('Invalid dashboard payload');
    importAvailable=health.can_import;databaseManagementAvailable=health.can_manage_database;databaseAvailable=health.database_available;sourceAvailable=health.source_available;baseDatabaseAvailable=health.base_database_available;baseSourceAvailable=health.base_source_available;refreshImportSupport();
    state.summary=summary;state.regions=regions;state.rows=rows.rows;state.daily=daily.daily_totals;state.audit=audit;state.locations=locations;loadOK=true;
    renderDashboard();setStatus(true,'verified');
    lastUpdatedTime=new Date();
    updateSystemHealth({backendOk:true,health,summary,rows:rows.rows,audit});
    setFooterStatus(t('updatedAt',{time:formatTime(lastUpdatedTime)}),{state:'success'});
    if(isRefresh)showToast(t('refreshSuccess'),'success');
    const welcomeStatus=document.querySelector('[data-i18n="welcomeReady"]');
    if(welcomeStatus)welcomeStatus.textContent=(state.rows.length||state.history.length)?t('welcomeReady'):t('welcomeEmpty');
    if(!new URLSearchParams(location.search).has('desktop'))showWelcome();
    return true;
  }catch(error){
    const diagnostic=String(error?.message||t('missingApi')).replace(/\s+/g,' ').trim();
    loadOK=false;setStatus(false,'loadIssue');updateSystemHealth({backendOk:false,health:null,summary:state.summary,rows:state.summary?state.rows:null,audit:state.audit});setFooterStatus(diagnostic,{state:'error'});showToast(diagnostic,'error');
    if(!state.summary){
      const grid=document.getElementById('kpiGrid');grid.setAttribute('aria-busy','false');
      const notice=document.createElement('article');notice.className='kpi kpi-load-error';notice.textContent=t('loadError');grid.replaceChildren(notice);
      const body=document.querySelector('#sellersTable tbody');body.setAttribute('aria-busy','false');
      const row=document.createElement('tr'),cell=document.createElement('td');cell.colSpan=7;cell.className='no-data';cell.textContent=t('loadError');row.append(cell);body.replaceChildren(row);
      const historyList=document.getElementById('historyList');historyList.replaceChildren();
      const empty=document.createElement('div');empty.className='history-empty';empty.textContent=t('loadError');historyList.append(empty);
    }
    return false;
  }finally{loadInProgress=false;refreshImportSupport();button.classList.remove('is-loading');button.disabled=false;button.removeAttribute('aria-busy');document.documentElement.classList.remove('is-refreshing');}
}
applyLanguage();
wire();
load();



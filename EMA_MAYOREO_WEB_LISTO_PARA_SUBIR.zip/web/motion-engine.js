'use strict';

(() => {
  const MOTION_DEBUG = false;
  const root = document.documentElement;
  const liveCounters = new Map();
  const runningAnimations = new Set();
  let active = false;
  let controller = null;
  let revealObserver = null;
  let canvas = null;
  let context = null;
  let particles = [];
  let rafId = 0;
  let resizeRaf = 0;
  let lastFrame = 0;
  let scrollRaf = 0;
  let pointerRaf = 0;
  let lastPointer = null;
  let entranceScheduled = false;
  let entrancePlayed = false;
  let entranceToken = 0;
  let entranceTimeline = null;
  let routeTriggers = [];
  let mapRevealTween = null;
  let gsapReady = false;

  const debug = (...args) => { if (MOTION_DEBUG) console.debug('[EMA Motion]', ...args); };
  // El control del panel puede anular la preferencia del sistema a petición del usuario.
  const shouldReduce = () => root.dataset.motion === 'reduced';
  const isFinePointer = () => window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  function reveal(node) {
    if (!node || !node.isConnected || node.classList.contains('is-visible')) return;
    node.classList.add('is-visible');
    node.dataset.motionState = 'visible';
    node.querySelectorAll('[data-count-up="true"]').forEach(animateCounter);
  }

  function animateCounter(node) {
    if (!node || node.dataset.countAnimated === 'true') return;
    node.dataset.countAnimated = 'true';
    if (shouldReduce()) return;
    const target = Number(node.dataset.countTarget);
    if (!Number.isFinite(target)) return;
    const finalText = node.textContent;
    const locale = ({ es: 'es-GT', en: 'en-US', pt: 'pt-BR' })[root.lang] || 'es-GT';
    const formatter = new Intl.NumberFormat(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const prefix = (node.dataset.countSign || '') + (node.dataset.countPrefix || '');
    const suffix = node.dataset.countSuffix || '';
    const start = performance.now();
    const duration = 1050;
    const tick = now => {
      if (!node.isConnected || shouldReduce()) { node.textContent = finalText; liveCounters.delete(node); return; }
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      node.textContent = prefix + formatter.format(target * eased) + suffix;
      if (progress < 1) liveCounters.set(node, requestAnimationFrame(tick));
      else { node.textContent = finalText; liveCounters.delete(node); }
    };
    node.textContent = prefix + formatter.format(0) + suffix;
    liveCounters.set(node, requestAnimationFrame(tick));
  }

  function candidates() {
    return document.querySelectorAll('[data-motion="reveal"], .insight-card, .region-item, .map-place-button, .focus-item, .recon-line, .audit-card, .seller-row');
  }

  function selectedNodes(selector) {
    return [...document.querySelectorAll(selector)].filter(node => getComputedStyle(node).display !== 'none');
  }

  function prepareMotionNode(node) {
    if (node.matches('[data-motion="reveal"]') && !node.classList.contains('is-visible')) reveal(node);
    node.style.willChange = 'transform, opacity';
  }

  function animateFallbackNode(node, delay, duration = 620, x = 0, y = 22) {
    prepareMotionNode(node);
    if (!node.animate) {
      node.style.setProperty('--reveal-delay', `${delay}ms`);
      window.setTimeout(() => node.style.removeProperty('will-change'), delay + duration + 100);
      return;
    }
    const animation = node.animate(
      [
        { opacity: 0, transform: `translate3d(${x}px, ${y}px, 0) scale(.975)`, filter: 'blur(4px)' },
        { opacity: 1, transform: 'translate3d(0, 0, 0) scale(1)', filter: 'blur(0)' }
      ],
      { duration, delay, easing: 'cubic-bezier(.22, 1.22, .36, 1)', fill: 'both' }
    );
    runningAnimations.add(animation);
    animation.onfinish = () => {
      animation.cancel();
      runningAnimations.delete(animation);
      node.style.removeProperty('will-change');
    };
  }

  function runFallbackEntrance() {
    const groups = [
      ['.sidebar .brand-block', 0, 0, -16, 0],
      ['.sidebar .nav-link', 70, 42, -14, 0],
      ['.topbar-title', 100, 0, 0, -14],
      ['.top-actions > *', 145, 42, 0, -10],
      ['.last-updated', 220, 0, 0, 8],
      ['.system-health', 270, 0, 0, 16],
      ['.quality-assistant', 315, 0, 0, 16],
      ['.hero-copy .hero-overline, #heroTitle, .hero-copy > p, .hero-copy > .hero-core-label, .hero-copy .hero-actions .button', 350, 82, 0, 22],
      ['.hero-status', 420, 0, 22, 0],
      ['#kpiGrid .kpi', 540, 88, 0, 24],
      ['.insights-grid .insight-card', 900, 62, 0, 18]
    ];
    groups.forEach(([selector, start, stagger, x, y]) => {
      selectedNodes(selector).forEach((node, index) => animateFallbackNode(node, start + index * stagger, 640, x, y));
    });
  }

  function runGsapEntrance() {
    const gsap = window.gsap;
    if (!gsap || !window.ScrollTrigger) return runFallbackEntrance();
    root.classList.add('motion-gsap');
    gsap.killTweensOf('.sidebar .brand-block, .sidebar .nav-link, .topbar-title, .top-actions > *, .last-updated, .system-health, .quality-assistant, .hero-grid, .hero-status, #kpiGrid .kpi, .insights-grid .insight-card');
    const timeline = gsap.timeline({ defaults: { overwrite: 'auto' } });
    entranceTimeline = timeline;
    const enter = (targets, from, to, position) => {
      const nodes = selectedNodes(targets);
      if (!nodes.length) return;
      nodes.forEach(prepareMotionNode);
      timeline.fromTo(nodes, from, { ...to, immediateRender: false, clearProps: 'filter,transform,opacity' }, position);
    };
    enter('.sidebar .brand-block', { x: -16, autoAlpha: 0 }, { x: 0, autoAlpha: 1, duration: .48, ease: 'power3.out' }, 0);
    enter('.sidebar .nav-link', { x: -14, autoAlpha: 0 }, { x: 0, autoAlpha: 1, duration: .43, stagger: .045, ease: 'power3.out' }, '-=.30');
    enter('.topbar-title', { y: -14, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: .48, ease: 'power3.out' }, '-=.32');
    enter('.top-actions > *', { y: -10, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: .38, stagger: .035, ease: 'power3.out' }, '-=.34');
    enter('.last-updated', { y: 8, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: .36, ease: 'power2.out' }, '-=.22');
    enter('.system-health', { y: 16, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: .52, ease: 'power3.out' }, '-=.12');
    enter('.quality-assistant', { y: 16, scale: .99, autoAlpha: 0 }, { y: 0, scale: 1, autoAlpha: 1, duration: .56, ease: 'back.out(1.12)' }, '-=.10');
    enter('.hero-copy .hero-overline, #heroTitle, .hero-copy > p, .hero-copy > .hero-core-label, .hero-copy .hero-actions .button', { y: 22, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: .58, stagger: .075, ease: 'power3.out' }, '-=.10');
    enter('.hero-status', { x: 22, autoAlpha: 0 }, { x: 0, autoAlpha: 1, duration: .64, ease: 'back.out(1.25)' }, '<');
    enter('#kpiGrid .kpi', { y: 24, scale: .965, autoAlpha: 0 }, { y: 0, scale: 1, autoAlpha: 1, duration: .58, stagger: .085, ease: 'back.out(1.22)' }, '-=.16');
    enter('.insights-grid .insight-card', { y: 18, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: .48, stagger: .055, ease: 'power3.out' }, '-=.24');
    return timeline;
  }

  function scheduleEntrance(force = false) {
    if (shouldReduce() || !document.querySelector('#kpiGrid .kpi')) return;
    if (entranceScheduled && !force) return;
    entranceScheduled = true;
    entrancePlayed = true;
    const token = ++entranceToken;
    if (force) {
      entranceTimeline?.kill();
      runningAnimations.forEach(animation => animation.cancel());
      runningAnimations.clear();
      if (!window.gsap || !window.ScrollTrigger) {
        runFallbackEntrance();
        return;
      }
    }
    const ready = window.EmaGsapReady || Promise.resolve(false);
    Promise.race([ready, new Promise(resolve => window.setTimeout(() => resolve(false), 650))]).then(() => {
      if (!active || shouldReduce() || token !== entranceToken) return;
      if (window.gsap && window.ScrollTrigger) runGsapEntrance();
      else runFallbackEntrance();
    });
  }

  function stopRouteTriggers() {
    routeTriggers.forEach(trigger => trigger.kill());
    routeTriggers = [];
  }

  function setupRouteReveal() {
    stopRouteTriggers();
    if (!gsapReady || shouldReduce() || !window.ScrollTrigger || !window.gsap) return;
    const rows = [...document.querySelectorAll('.seller-row')];
    if (!rows.length) return;
    window.gsap.set(rows, { autoAlpha: 0, y: 10 });
    routeTriggers = window.ScrollTrigger.batch(rows, {
      scroller: document.querySelector('.table-wrap') || window,
      start: 'top 94%',
      interval: .12,
      batchMax: 7,
      once: true,
      onEnter: batch => window.gsap.to(batch, { autoAlpha: 1, y: 0, duration: .46, stagger: .045, ease: 'power2.out', overwrite: 'auto', clearProps: 'transform,opacity' })
    });
    window.ScrollTrigger.refresh();
  }

  function setupMapReveal() {
    mapRevealTween?.scrollTrigger?.kill();
    mapRevealTween?.kill();
    mapRevealTween = null;
    const map = document.querySelector('.map-board .map-art');
    if (!gsapReady || shouldReduce() || !map || !window.ScrollTrigger || !window.gsap) return;
    mapRevealTween = window.gsap.fromTo(map,
      { autoAlpha: .7, scale: .965, y: 12, transformOrigin: '50% 50%' },
      { autoAlpha: 1, scale: 1, y: 0, duration: .82, ease: 'power3.out', overwrite: 'auto', clearProps: 'transform,opacity', immediateRender: false,
        scrollTrigger: { trigger: '.map-board', start: 'top 86%', once: true } }
    );
  }

  function useGSAP() {
    if (!window.gsap || !window.ScrollTrigger) return false;
    window.gsap.registerPlugin(window.ScrollTrigger);
    gsapReady = true;
    root.classList.add('motion-gsap');
    setupRouteReveal();
    setupMapReveal();
    if (active && !entrancePlayed) scheduleEntrance();
    return true;
  }

  function refresh() {
    if (!active) return;
    const reduce = shouldReduce();
    candidates().forEach(node => {
      if (node.dataset.motionObserved === 'true' || node.classList.contains('is-visible')) return;
      node.dataset.motion = 'reveal';
      if (reduce || !revealObserver) reveal(node);
      else {
        node.dataset.motionObserved = 'true';
        revealObserver.observe(node);
      }
    });
    setupRouteReveal();
    scheduleEntrance();
  }

  function updateScrollProgress() {
    if (scrollRaf) return;
    scrollRaf = requestAnimationFrame(() => {
      scrollRaf = 0;
      const progress = document.getElementById('scrollProgress');
      if (!progress) return;
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      const ratio = maxScroll > 0 ? Math.max(0, Math.min(1, window.scrollY / maxScroll)) : 0;
      progress.style.transform = `scaleX(${ratio.toFixed(4)})`;
    });
  }

  function schedulePointer(event) {
    if (!isFinePointer() || event.pointerType === 'touch' || shouldReduce()) return;
    lastPointer = { x: event.clientX, y: event.clientY, target: event.target };
    if (pointerRaf) return;
    pointerRaf = requestAnimationFrame(() => {
      pointerRaf = 0;
      if (!lastPointer) return;
      const { x, y, target } = lastPointer;
      root.style.setProperty('--mx', `${x}px`);
      root.style.setProperty('--my', `${y}px`);
      const cursor = document.getElementById('cursorAura');
      if (cursor) cursor.style.transform = `translate3d(${x}px,${y}px,0)`;
      const hero = target instanceof Element ? target.closest('.hero-copy') : null;
      if (hero) {
        const bounds = hero.getBoundingClientRect();
        hero.style.setProperty('--hero-x', `${Math.max(0, Math.min(100, (x - bounds.left) / bounds.width * 100)).toFixed(1)}%`);
        hero.style.setProperty('--hero-y', `${Math.max(0, Math.min(100, (y - bounds.top) / bounds.height * 100)).toFixed(1)}%`);
      }
    });
  }

  function resetPointer(event) {
    if (event.target instanceof Element && event.target.closest('.hero-copy')) {
      const hero = event.target.closest('.hero-copy');
      if (event.relatedTarget instanceof Node && hero.contains(event.relatedTarget)) return;
      hero.style.removeProperty('--hero-x');
      hero.style.removeProperty('--hero-y');
    }
  }

  function tiltCards(event) {
    const card = event.target instanceof Element ? event.target.closest('.kpi') : null;
    if (!card || !isFinePointer() || shouldReduce()) return;
    const bounds = card.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - .5;
    const y = (event.clientY - bounds.top) / bounds.height - .5;
    card.style.setProperty('--tilt-x', `${(x * 8).toFixed(2)}deg`);
    card.style.setProperty('--tilt-y', `${(-y * 7).toFixed(2)}deg`);
  }

  function resetTilt(event) {
    const card = event.target instanceof Element ? event.target.closest('.kpi') : null;
    if (!card || event.relatedTarget instanceof Node && card.contains(event.relatedTarget)) return;
    card.style.removeProperty('--tilt-x');
    card.style.removeProperty('--tilt-y');
  }

  function magneticMove(event) {
    const button = event.target instanceof Element ? event.target.closest('[data-magnetic]') : null;
    if (!button || !isFinePointer() || shouldReduce()) return;
    const bounds = button.getBoundingClientRect();
    const x = Math.max(-4, Math.min(4, (event.clientX - bounds.left - bounds.width / 2) * .08));
    const y = Math.max(-4, Math.min(4, (event.clientY - bounds.top - bounds.height / 2) * .08));
    button.style.setProperty('--mag-x', `${x.toFixed(1)}px`);
    button.style.setProperty('--mag-y', `${y.toFixed(1)}px`);
  }

  function resetMagnetic(event) {
    const button = event.target instanceof Element ? event.target.closest('[data-magnetic]') : null;
    if (!button || event.relatedTarget instanceof Node && button.contains(event.relatedTarget)) return;
    button.style.removeProperty('--mag-x');
    button.style.removeProperty('--mag-y');
  }

  function animateMapHover(event, entering) {
    if (!gsapReady || shouldReduce() || !isFinePointer()) return;
    const marker = event.target instanceof Element ? event.target.closest('[data-map-region]') : null;
    if (!marker || event.relatedTarget instanceof Node && marker.contains(event.relatedTarget)) return;
    const tween = {
      scale: entering ? 1.045 : 1,
      y: entering ? -2 : 0,
      transformOrigin: 'center center',
      duration: entering ? .2 : .28,
      ease: entering ? 'power3.out' : 'back.out(1.35)',
      overwrite: 'auto'
    };
    if (!entering) tween.clearProps = 'transform';
    window.gsap.to(marker, tween);
  }

  function animateWelcome() {
    const card = document.querySelector('.welcome-card');
    if (!card || shouldReduce()) return;
    if (window.gsap) {
      window.gsap.fromTo(card, { autoAlpha: 0, y: 20, scale: .94, filter: 'blur(8px)' }, {
        autoAlpha: 1, y: 0, scale: 1, filter: 'blur(0)', duration: .76,
        ease: 'back.out(1.25)', overwrite: 'auto', clearProps: 'filter,transform,opacity'
      });
      window.gsap.fromTo('.welcome-orbit', { autoAlpha: 0, scale: .7, rotate: -12 }, {
        autoAlpha: .75, scale: 1, rotate: 0, duration: .9, stagger: .1,
        ease: 'power3.out', overwrite: 'auto', clearProps: 'transform,opacity'
      });
    } else if (card.animate) {
      const animation = card.animate(
        [{ opacity: 0, transform: 'translate3d(0,20px,0) scale(.94)', filter: 'blur(8px)' }, { opacity: 1, transform: 'translate3d(0,0,0) scale(1)', filter: 'blur(0)' }],
        { duration: 760, easing: 'cubic-bezier(.22,1.22,.36,1)', fill: 'both' }
      );
      animation.onfinish = () => animation.cancel();
    }
  }

  function initParticles() {
    canvas = document.getElementById('particleField');
    if (!canvas || !canvas.getContext || shouldReduce()) return;
    context = canvas.getContext('2d', { alpha: true });
    if (!context) return;
    resizeCanvas();
    runParticles();
  }

  function resizeCanvas() {
    if (!canvas || !context) return;
    const width = Math.max(1, window.innerWidth), height = Math.max(1, window.innerHeight);
    const ratio = Math.min(1.25, window.devicePixelRatio || 1);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    const count = Math.max(8, Math.min(24, Math.round(width / (window.innerWidth < 700 ? 60 : 65))));
    particles = Array.from({ length: count }, (_, index) => ({
      x: ((index * 97 + 23) % 997) / 997 * width,
      y: ((index * 193 + 71) % 991) / 991 * height,
      radius: .45 + (index % 4) * .23,
      speed: .045 + (index % 5) * .012,
      phase: index % 3
    }));
  }

  function runParticles(now = 0) {
    if (!active || shouldReduce() || document.hidden || !context) { rafId = 0; return; }
    if (now - lastFrame >= 1000 / 60) {
      lastFrame = now;
      const width = window.innerWidth, height = window.innerHeight;
      context.clearRect(0, 0, width, height);
      particles.forEach(point => {
        point.y -= point.speed;
        if (point.y < -3) point.y = height + 3;
        const alpha = point.phase === 0 ? .28 : .17;
        context.beginPath();
        context.fillStyle = `rgba(183, 243, 108, ${alpha})`;
        context.arc(point.x, point.y, point.radius, 0, Math.PI * 2);
        context.fill();
      });
    }
    rafId = requestAnimationFrame(runParticles);
  }

  function stopParticles() {
    if (rafId) cancelAnimationFrame(rafId);
    if (resizeRaf) cancelAnimationFrame(resizeRaf);
    rafId = 0;
    resizeRaf = 0;
    context?.clearRect(0, 0, canvas?.width || 0, canvas?.height || 0);
  }

  function handleMotionChange() {
    const reduced = shouldReduce();
    root.classList.toggle('motion-ready', !reduced);
    if (reduced) {
      entranceToken++;
      entranceTimeline?.kill();
      runningAnimations.forEach(animation => animation.cancel());
      runningAnimations.clear();
      window.gsap?.killTweensOf('.sidebar .brand-block, .sidebar .nav-link, .topbar-title, .top-actions > *, .last-updated, .system-health, .hero-grid, .hero-status, #kpiGrid .kpi, .insights-grid .insight-card, .welcome-card, [data-map-region], .seller-row');
      stopRouteTriggers();
      mapRevealTween?.scrollTrigger?.kill();
      mapRevealTween?.kill();
      mapRevealTween = null;
      if (window.gsap) window.gsap.set('.seller-row, [data-map-region], .map-board .map-art', { autoAlpha: 1, scale: 1, x: 0, y: 0, clearProps: 'transform,opacity' });
      candidates().forEach(reveal);
      liveCounters.forEach(id => cancelAnimationFrame(id));
      liveCounters.clear();
      stopParticles();
      document.getElementById('cursorAura')?.classList.remove('is-visible');
      root.classList.remove('motion-gsap');
    } else if (active) {
      if (gsapReady) root.classList.add('motion-gsap');
      refresh();
      initParticles();
      setupMapReveal();
      if (entrancePlayed) scheduleEntrance(true);
    }
  }

  function init() {
    if (active) return;
    active = true;
    controller = new AbortController();
    const { signal } = controller;
    if ('IntersectionObserver' in window) {
      revealObserver = new IntersectionObserver(entries => entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        revealObserver.unobserve(entry.target);
        entry.target.dataset.motionObserved = 'false';
        reveal(entry.target);
      }), { threshold: .12, rootMargin: '0px 0px -5% 0px' });
    }
    root.classList.toggle('motion-ready', !shouldReduce());
    refresh();
    updateScrollProgress();
    initParticles();
    document.addEventListener('pointermove', schedulePointer, { passive: true, signal });
    document.addEventListener('pointerout', resetPointer, { passive: true, signal });
    document.addEventListener('pointerover', event => {
      if (!isFinePointer() || shouldReduce()) return;
      const interactive = event.target instanceof Element && event.target.closest('a,button,[role="button"],input,select');
      document.getElementById('cursorAura')?.classList.toggle('is-interactive', Boolean(interactive));
      document.getElementById('cursorAura')?.classList.add('is-visible');
    }, { passive: true, signal });
    document.addEventListener('pointerleave', () => document.getElementById('cursorAura')?.classList.remove('is-visible'), { passive: true, signal });
    document.addEventListener('pointermove', tiltCards, { passive: true, signal });
    document.addEventListener('pointerout', resetTilt, { passive: true, signal });
    document.addEventListener('pointermove', magneticMove, { passive: true, signal });
    document.addEventListener('pointerout', resetMagnetic, { passive: true, signal });
    ['mapMarkers', 'mapPlaceList'].forEach(id => {
      const host = document.getElementById(id);
      host?.addEventListener('pointerover', event => animateMapHover(event, true), { passive: true, signal });
      host?.addEventListener('pointerout', event => animateMapHover(event, false), { passive: true, signal });
    });
    window.addEventListener('scroll', updateScrollProgress, { passive: true, signal });
    window.addEventListener('resize', updateScrollProgress, { passive: true, signal });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stopParticles();
      else if (!shouldReduce()) { resizeCanvas(); initParticles(); }
    }, { signal });
    window.addEventListener('resize', () => {
      if (resizeRaf) return;
      resizeRaf = requestAnimationFrame(() => { resizeRaf = 0; if (context) resizeCanvas(); updateScrollProgress(); });
    }, { passive: true, signal });
    debug('initialized');
  }

  function destroy() {
    if (!active) return;
    active = false;
    controller?.abort();
    controller = null;
    revealObserver?.disconnect();
    revealObserver?.disconnect();
    revealObserver = null;
    stopParticles();
    if (scrollRaf) cancelAnimationFrame(scrollRaf);
    if (pointerRaf) cancelAnimationFrame(pointerRaf);
    scrollRaf = pointerRaf = 0;
    liveCounters.forEach(id => cancelAnimationFrame(id));
    liveCounters.clear();
    entranceToken++;
    entranceTimeline?.kill();
    runningAnimations.forEach(animation => animation.cancel());
    runningAnimations.clear();
    stopRouteTriggers();
    mapRevealTween?.scrollTrigger?.kill();
    mapRevealTween?.kill();
    mapRevealTween = null;
    root.classList.remove('motion-ready');
    root.classList.remove('motion-gsap');
    root.style.removeProperty('--mx');
    root.style.removeProperty('--my');
    document.getElementById('cursorAura')?.classList.remove('is-visible', 'is-interactive');
    debug('destroyed');
  }

  window.EmaMotion = { init, destroy, refresh, useGSAP, animateWelcome, playEntrance(force = false) {
    entranceScheduled = force ? false : entranceScheduled;
    scheduleEntrance(force);
  }, setReducedMotion(value) {
    const before = shouldReduce();
    root.dataset.motion = value ? 'reduced' : 'full';
    if (before !== shouldReduce()) handleMotionChange();
  } };
})();

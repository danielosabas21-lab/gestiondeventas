'use strict';

/* Unifica los estados de carga del panel y mantiene accesible el modal bloqueante. */
(() => {
  const overlay = document.getElementById('globalLoader');
  const title = document.getElementById('loaderTitle');
  const message = document.getElementById('loaderMessage');
  const detail = document.getElementById('loaderProgressDetail');
  const percentLabel = document.getElementById('loaderPercent');
  const progress = document.getElementById('loaderProgress');
  const progressFill = document.getElementById('loaderProgressFill');
  const cancelButton = document.getElementById('loaderCancel');
  const appShell = document.querySelector('.app-shell');
  const status = document.getElementById('footerState');
  const statusText = document.getElementById('footerStateText');
  const statusSpinner = document.getElementById('footerSpinner');
  const statusProgress = document.getElementById('footerProgress');
  const statusProgressFill = document.getElementById('footerProgressFill');
  let cancelAction = null;
  let previousFocus = null;
  let previousInert = false;
  let statusTimer = 0;
  let statusRevision = 0;

  function setProgress(track, fill, label, value) {
    if (!track || !fill) return;
    const indeterminate = value === null;
    track.classList.toggle('is-indeterminate', indeterminate);
    if (indeterminate) {
      track.removeAttribute('aria-valuenow');
      if (label) label.textContent = '…';
      fill.style.width = '38%';
      return;
    }
    const bounded = Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
    track.setAttribute('aria-valuenow', String(bounded));
    if (label) label.textContent = `${bounded}%`;
    fill.style.width = `${bounded}%`;
  }

  function setStatus(text, options = {}) {
    if (!status || !statusText) return;
    const { busy = false, progress: value, state: stateName = '' } = options;
    statusRevision += 1;
    window.clearTimeout(statusTimer);
    statusText.textContent = String(text || '');
    status.dataset.state = stateName || (busy ? 'busy' : 'idle');
    statusSpinner.hidden = !busy;
    const hasProgress = value !== undefined;
    statusProgress.hidden = !hasProgress;
    if (hasProgress) setProgress(statusProgress, statusProgressFill, null, value);
  }

  function announce(text, duration = 1300) {
    setStatus(text, { busy: true, progress: null, state: 'download' });
    const revision = statusRevision;
    statusTimer = window.setTimeout(() => {
      if (revision === statusRevision) setStatus(text, { busy: false });
    }, Math.max(400, duration));
  }

  function updateOverlay(options = {}) {
    if (!overlay || overlay.classList.contains('hidden')) return;
    if (options.title !== undefined) title.textContent = String(options.title);
    if (options.message !== undefined) message.textContent = String(options.message);
    if (options.detail !== undefined) detail.textContent = String(options.detail);
    if (options.progress !== undefined) setProgress(progress, progressFill, percentLabel, options.progress);
    if (options.cancelable !== undefined) cancelButton.hidden = !options.cancelable;
    if (options.cancelText !== undefined) cancelButton.textContent = String(options.cancelText);
    if (options.cancelDisabled !== undefined) cancelButton.disabled = Boolean(options.cancelDisabled);
  }

  function showOverlay(options = {}) {
    if (!overlay) return;
    previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    previousInert = Boolean(appShell?.hasAttribute('inert'));
    cancelAction = typeof options.onCancel === 'function' ? options.onCancel : null;
    overlay.classList.remove('hidden');
    overlay.setAttribute('aria-busy', 'true');
    if (appShell) appShell.setAttribute('inert', '');
    updateOverlay({
      title: options.title || 'Procesando',
      message: options.message || 'Preparando la tarea…',
      detail: options.detail || 'Espera un momento.',
      progress: options.progress === undefined ? null : options.progress,
      cancelable: Boolean(cancelAction),
      cancelText: options.cancelText || 'Cancelar carga',
      cancelDisabled: false
    });
    requestAnimationFrame(() => (cancelButton.hidden ? overlay : cancelButton).focus());
    return Object.freeze({ update: updateOverlay, close: hideOverlay });
  }

  function hideOverlay() {
    if (!overlay || overlay.classList.contains('hidden')) return;
    overlay.classList.add('hidden');
    overlay.removeAttribute('aria-busy');
    cancelButton.hidden = true;
    cancelButton.disabled = false;
    cancelAction = null;
    if (appShell && !previousInert) appShell.removeAttribute('inert');
    if (previousFocus?.isConnected && typeof previousFocus.focus === 'function') previousFocus.focus({ preventScroll: true });
    previousFocus = null;
  }

  cancelButton?.addEventListener('click', () => {
    if (!cancelAction || cancelButton.disabled) return;
    try {
      cancelAction();
    } catch (error) {
      console.error('No se pudo cancelar el proceso.', error);
    }
  });

  document.addEventListener('keydown', event => {
    if (!overlay || overlay.classList.contains('hidden')) return;
    if (event.key === 'Escape' && cancelAction && !cancelButton.disabled) {
      event.preventDefault();
      cancelButton.click();
      return;
    }
    if (event.key !== 'Tab') return;
    const focusable = [...overlay.querySelectorAll('button:not([disabled]):not([hidden])')];
    if (!focusable.length) {
      event.preventDefault();
      overlay.focus();
    } else if (event.shiftKey && document.activeElement === focusable[0]) {
      event.preventDefault();
      focusable[focusable.length - 1].focus();
    } else if (!event.shiftKey && document.activeElement === focusable[focusable.length - 1]) {
      event.preventDefault();
      focusable[0].focus();
    }
  });

  window.EmaLoaders = Object.freeze({ setStatus, announce, showOverlay, updateOverlay, hideOverlay });
})();

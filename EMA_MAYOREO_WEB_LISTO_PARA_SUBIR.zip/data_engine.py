from __future__ import annotations

import json
import base64
import io
import importlib.util
import mimetypes
import math
import os
import subprocess
import csv
import shutil
import sys
import tempfile
import uuid
import threading
import zipfile
from datetime import datetime, timezone
from email.parser import BytesParser
from email.policy import default
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'web'
DATA = Path(os.environ.get('EMA_DATA_DIR', str(ROOT / 'data'))).expanduser().resolve()
DATA.mkdir(parents=True, exist_ok=True)
JSON_PATH = DATA / 'canonical.json'
AUDIT_PATH = DATA / 'audit.json'
LOCATIONS_PATH = DATA / 'locations.json'
DB = DATA / 'ema.db'
CSV = DATA / 'ventas_consolidado_canonical.csv'
VERSION = (ROOT / 'VERSION.txt').read_text(encoding='utf-8').strip()
DATA_LOCK = threading.RLock()
MAX_IMPORT_BYTES = 30 * 1024 * 1024
IMPORT_AVAILABLE = importlib.util.find_spec('openpyxl') is not None
CSV_FIELDS = [
    'date', 'route_id', 'seller', 'region', 'preventa_gtq',
    'facturacion_gtq', 'diferencia_gtq', 'cumplimiento_pct',
    'active_clients', 'visited_clients', 'buying_clients',
]


def payload(data_dir=DATA):
    with DATA_LOCK:
        return json.loads((data_dir / 'canonical.json').read_text(encoding='utf-8'))


def audit(data_dir=DATA):
    with DATA_LOCK:
        return json.loads((data_dir / 'audit.json').read_text(encoding='utf-8'))


def json_bytes(obj):
    return json.dumps(obj, ensure_ascii=False).encode('utf-8')


def repair_active_data_files():
    """Restaura archivos activos ausentes o dañados sin tocar los meses del historial."""
    bundled = ROOT / 'data'
    validators = {
        'canonical.json': lambda value: isinstance(value, dict) and isinstance(value.get('summary'), dict) and isinstance(value.get('rows'), list),
        'audit.json': lambda value: isinstance(value, dict) and isinstance(value.get('official_summary'), dict),
        'locations.json': lambda value: isinstance(value, dict) and isinstance(value.get('locations'), list) and bool(value['locations']),
    }
    for name, validate in validators.items():
        target = DATA / name
        original = bundled / name
        if not original.is_file() or original.resolve() == target.resolve():
            continue
        valid = False
        if target.is_file():
            try:
                valid = validate(json.loads(target.read_text(encoding='utf-8')))
            except (OSError, UnicodeError, ValueError, TypeError):
                valid = False
        if valid:
            continue
        try:
            if target.exists():
                recovery = DATA / '.recovery'
                recovery.mkdir(parents=True, exist_ok=True)
                timestamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
                backup = recovery / f'{name}.corrupt-{timestamp}'
                shutil.copy2(target, backup)
            temporary = DATA / ('.' + name + '.restore')
            shutil.copy2(original, temporary)
            os.replace(temporary, target)
            print(f'Archivo local reparado: {name}', file=sys.stderr, flush=True)
        except OSError as exc:
            print(f'No se pudo reparar {name}: {type(exc).__name__}: {exc}', file=sys.stderr, flush=True)


repair_active_data_files()


def empty_dataset():
    summary = {
        'source': 'SIN DATOS',
        'official_controls': {
            'preventa_gtq': 0, 'facturacion_gtq': 0, 'diferencia_gtq': 0,
            'cumplimiento_pct': 0,
        },
        'internal_reconciliation': {
            'route_preventa_sum_gtq': 0, 'route_facturacion_sum_gtq': 0,
            'preventa_control_delta_gtq': 0, 'facturacion_control_delta_gtq': 0,
            'adjustment_gtq': 0, 'status': 'OK',
        },
        'period': {'start': None, 'end': None, 'active_days': 0},
        'counts': {'routes': 0, 'sellers': 0, 'regions': 0, 'official_rows': 0},
    }
    summary['daily_reconciliation'] = {
        'daily_preventa_sum_gtq': 0, 'daily_facturacion_sum_gtq': 0,
        'preventa_control_delta_gtq': 0, 'facturacion_control_delta_gtq': 0,
        'unassigned_adjustments_gtq': 0, 'status': 'OK',
    }
    return {'summary': summary, 'routes': [], 'rows': [], 'daily_totals': []}


def empty_audit():
    return {
        'source_file': None,
        'source_of_truth': 'Sin base de datos activa.',
        'daily_sheets_role': None,
        'facturacion_sheet_role': None,
        'label_corrections': [],
        'preventa_discrepancies_vs_daily': [],
        'extra_raw_routes_not_in_consolidado': [],
        'mixed_fact_sources': [],
        'daily_billing_formula_issues': [],
        'period_label_issues': [],
        'unassigned_adjustments': [],
        'official_summary': empty_dataset()['summary'],
        'quality_rules': [],
    }


def atomic_update(staged, remove=(), data_dir=DATA):
    names = set(staged) | set(remove)
    with DATA_LOCK:
        previous = {name: (data_dir / name).read_bytes() if (data_dir / name).exists() else None for name in names}
        replaced = []
        try:
            for name, content in staged.items():
                target = data_dir / name
                temporary = data_dir / ('.' + name + '.updating')
                temporary.write_bytes(content)
                os.replace(temporary, target)
                replaced.append(name)
            for name in remove:
                target = data_dir / name
                if target.exists():
                    target.unlink()
                    replaced.append(name)
        except Exception:
            for name in reversed(replaced):
                target = data_dir / name
                old = previous[name]
                if old is None:
                    target.unlink(missing_ok=True)
                else:
                    temporary = data_dir / ('.' + name + '.rollback')
                    temporary.write_bytes(old)
                    os.replace(temporary, target)
            raise


def csv_bytes(rows):
    output = io.StringIO(newline='')
    writer = csv.DictWriter(output, fieldnames=CSV_FIELDS)
    writer.writeheader()
    writer.writerows({key: row.get(key) for key in CSV_FIELDS} for row in rows)
    return ('\ufeff' + output.getvalue()).encode('utf-8')


HISTORY_DIR = DATA / 'history'
HISTORY_INDEX = HISTORY_DIR / 'index.json'
HISTORY_FILES = ('source.xlsx', 'canonical.json', 'audit.json', 'ventas_consolidado_canonical.csv', 'ema.db')


def valid_month(value):
    if not isinstance(value, str) or len(value) != 7 or value[4] != '-':
        return False
    try:
        datetime.strptime(value, '%Y-%m')
        return True
    except ValueError:
        return False


def analyze_dataset(dataset, audit_data, map_regions):
    """Valida conciliación, periodo e integridad antes de archivar un libro."""
    summary = dataset.get('summary', {}) if isinstance(dataset, dict) else {}
    controls = summary.get('official_controls', {})
    internal = summary.get('internal_reconciliation', {})
    daily_control = summary.get('daily_reconciliation', {})
    period = summary.get('period', {})
    counts = summary.get('counts', {})
    rows = dataset.get('rows', []) if isinstance(dataset, dict) else []
    daily = dataset.get('daily_totals', []) if isinstance(dataset, dict) else []
    rows = rows if isinstance(rows, list) else []
    daily = daily if isinstance(daily, list) else []
    checks = []

    def add(check_id, title, ok, detail, critical=True):
        checks.append({'id': check_id, 'title': title, 'ok': bool(ok), 'detail': detail, 'critical': critical})

    def numeric(value):
        try:
            return math.isfinite(float(value))
        except (TypeError, ValueError, OverflowError):
            return False

    def close(left, right):
        return numeric(left) and numeric(right) and abs(float(left) - float(right)) <= 0.011

    add('has_rows', 'Registros disponibles', len(rows) > 0, f'{len(rows):,} filas válidas.' if rows else 'El libro no generó filas de venta.')

    required = ('date', 'route_id', 'seller', 'region', 'preventa_gtq', 'facturacion_gtq', 'diferencia_gtq')
    missing = sum(1 for row in rows if not isinstance(row, dict) or any(row.get(key) in (None, '') for key in required))
    add('required_fields', 'Campos completos', missing == 0, 'Cada fila contiene fecha, vendedor, región e importes.' if missing == 0 else f'{missing:,} filas tienen datos requeridos vacíos.')

    bad_numbers = sum(1 for row in rows if not isinstance(row, dict) or any(not numeric(row.get(key)) for key in ('preventa_gtq', 'facturacion_gtq', 'diferencia_gtq')))
    add('finite_amounts', 'Importes válidos', bad_numbers == 0, 'No se encontraron importes vacíos o no numéricos.' if bad_numbers == 0 else f'{bad_numbers:,} filas contienen importes inválidos.')

    keys = [(str(row.get('date', '')), str(row.get('route_id', ''))) for row in rows if isinstance(row, dict)]
    duplicates = len(keys) - len(set(keys))
    add('unique_daily_routes', 'Sin filas duplicadas', duplicates == 0, 'Cada vendedor aparece una sola vez por fecha.' if duplicates == 0 else f'Se encontraron {duplicates:,} combinaciones repetidas de fecha y vendedor.')

    month = str(period.get('start') or '')[:7]
    period_ok = valid_month(month) and str(period.get('end') or '')[:7] == month and all(str(row.get('date', ''))[:7] == month for row in rows if isinstance(row, dict))
    add('single_month', 'Periodo de un solo mes', period_ok, f'Las fechas corresponden a {month}.' if period_ok else 'Las fechas no forman un solo mes calendario.')

    actual_regions = {str(row.get('region', '')).strip() for row in rows if isinstance(row, dict) and str(row.get('region', '')).strip()}
    expected_regions = {str(region).strip() for region in map_regions if str(region).strip()}
    add('known_regions', 'Regiones del panel', bool(actual_regions) and actual_regions == expected_regions, f'{len(actual_regions)} regiones reconocidas.' if actual_regions == expected_regions else 'Las regiones del libro no coinciden con las del panel.')

    unique_routes = {str(row.get('route_id', '')).strip() for row in rows if isinstance(row, dict) and str(row.get('route_id', '')).strip()}
    unique_sellers = {str(row.get('seller', '')).strip() for row in rows if isinstance(row, dict) and str(row.get('seller', '')).strip()}
    count_ok = len(rows) == counts.get('official_rows') and len(unique_routes) == counts.get('routes') and len(unique_sellers) == counts.get('sellers')
    add('counts_match', 'Conteos consistentes', count_ok, f'{len(rows):,} filas · {len(unique_sellers):,} vendedores · {len(unique_routes):,} rutas.' if count_ok else 'Los conteos calculados no coinciden con el resumen del libro.')

    row_preventa = sum(float(row['preventa_gtq']) for row in rows if isinstance(row, dict) and numeric(row.get('preventa_gtq')))
    row_billing = sum(float(row['facturacion_gtq']) for row in rows if isinstance(row, dict) and numeric(row.get('facturacion_gtq')))
    add('preventa_control', 'Preventa contra control oficial', close(row_preventa, controls.get('preventa_gtq')), 'La preventa de los vendedores concilia con el total oficial.' if close(row_preventa, controls.get('preventa_gtq')) else 'La suma de preventa no coincide con VENTAS CONSOLIDADO.')
    add('route_billing', 'Facturación de vendedores', close(row_billing, internal.get('route_facturacion_sum_gtq')), 'La facturación asignada concilia con el resumen interno.' if close(row_billing, internal.get('route_facturacion_sum_gtq')) else 'La suma por vendedor no coincide con el resumen interno.')

    audit_ok = isinstance(audit_data, dict) and isinstance(audit_data.get('official_summary'), dict)
    add('audit_available', 'Auditoría disponible', audit_ok, 'El archivo de auditoría del Excel está disponible.' if audit_ok else 'El libro no produjo un resumen de auditoría válido.')

    daily_preventa = sum(float(day['preventa_gtq']) for day in daily if isinstance(day, dict) and numeric(day.get('preventa_gtq')))
    daily_billing = sum(float(day['facturacion_gtq']) for day in daily if isinstance(day, dict) and numeric(day.get('facturacion_gtq')))
    bad_daily_numbers = sum(1 for day in daily if not isinstance(day, dict) or any(not numeric(day.get(key)) for key in ('preventa_gtq', 'facturacion_gtq', 'diferencia_gtq')))
    add('daily_amounts', 'Importes diarios válidos', bool(daily) and bad_daily_numbers == 0, 'Todos los días tienen importes numéricos.' if daily and bad_daily_numbers == 0 else 'Hay importes diarios inválidos o faltantes.')
    daily_ok = bool(daily) and bad_daily_numbers == 0 and close(daily_preventa, controls.get('preventa_gtq')) and close(daily_billing, controls.get('facturacion_gtq')) and daily_control.get('status') == 'OK'
    add('daily_control', 'Totales diarios conciliados', daily_ok, 'La suma diaria coincide con los controles oficiales.' if daily_ok else 'Los totales diarios no concilian con los controles oficiales.')

    difference_ok = numeric(controls.get('facturacion_gtq')) and numeric(controls.get('preventa_gtq')) and close(float(controls.get('facturacion_gtq')) - float(controls.get('preventa_gtq')), controls.get('diferencia_gtq'))
    add('official_difference', 'Diferencia oficial recalculada', difference_ok, 'Facturación menos preventa coincide con la diferencia oficial.' if difference_ok else 'La diferencia no coincide con facturación menos preventa.')

    failed = [check for check in checks if check['critical'] and not check['ok']]
    score = round(100 * sum(1 for check in checks if check['ok']) / max(1, len(checks)))
    status = 'verified' if not failed else 'review'
    if not failed:
        headline = 'Revisión completa: los datos y sus totales están consistentes.'
    else:
        headline = f'No se guardó el mes: hay {len(failed)} validación(es) que revisar.'
    return {
        'status': status,
        'score': score,
        'headline': headline,
        'checks_passed': len(checks) - len(failed),
        'checks_total': len(checks),
        'checks': checks,
        'findings': [check['title'] for check in failed],
    }


def archive_metadata(month, data_dir, filename=None, imported_at=None):
    source = json.loads((data_dir / 'canonical.json').read_text(encoding='utf-8'))
    summary = source.get('summary', {})
    try:
        audit_data = json.loads((data_dir / 'audit.json').read_text(encoding='utf-8'))
        map_regions = [item.get('region') for item in json.loads(LOCATIONS_PATH.read_text(encoding='utf-8')).get('locations', [])]
        quality = analyze_dataset(source, audit_data, map_regions)
    except (OSError, ValueError, TypeError):
        quality = {'status': 'review', 'score': 0, 'headline': 'No se pudo completar la revisión de calidad.', 'checks_passed': 0, 'checks_total': 0, 'checks': [], 'findings': ['No se pudo leer la auditoría o el mapa.']}
    return {
        'month': month,
        'period': summary.get('period', {}),
        'counts': summary.get('counts', {}),
        'official_controls': summary.get('official_controls', {}),
        'quality_report': quality,
        'source_file': filename or 'source.xlsx',
        'imported_at': imported_at or datetime.now(timezone.utc).isoformat(timespec='seconds'),
    }


def read_history_index():
    try:
        index = json.loads(HISTORY_INDEX.read_text(encoding='utf-8'))
        return index if isinstance(index, dict) and isinstance(index.get('months'), list) else {'months': []}
    except (OSError, ValueError):
        return {'months': []}


def save_history_index(index):
    HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    temporary = HISTORY_DIR / '.index.json.updating'
    temporary.write_bytes(json_bytes(index))
    os.replace(temporary, HISTORY_INDEX)


def seed_current_dataset():
    """Guarda la base incluida como primer periodo solo si aún no existe un índice histórico.

    La existencia del índice, incluso vacío, expresa una decisión explícita del usuario;
    así, un mes eliminado o una base reiniciada no reaparecen automáticamente.
    """
    if HISTORY_INDEX.exists():
        return
    if not all((DATA / name).is_file() for name in HISTORY_FILES):
        return
    try:
        source = json.loads(JSON_PATH.read_text(encoding='utf-8'))
        start = source.get('summary', {}).get('period', {}).get('start')
        month = str(start or '')[:7]
        if not valid_month(month):
            return
        HISTORY_DIR.mkdir(parents=True, exist_ok=True)
        with DATA_LOCK:
            index = read_history_index()
            if any(item.get('month') == month for item in index['months']):
                return
            target = HISTORY_DIR / month
            staging = HISTORY_DIR / ('.' + month + '.seed')
            if target.exists():
                return
            staging.mkdir(parents=True, exist_ok=False)
            try:
                for name in HISTORY_FILES:
                    (staging / name).write_bytes((DATA / name).read_bytes())
                os.replace(staging, target)
            except Exception:
                import shutil
                shutil.rmtree(staging, ignore_errors=True)
                raise
            index['months'].append(archive_metadata(month, target, imported_at=datetime.now(timezone.utc).isoformat(timespec='seconds')))
            index['months'].sort(key=lambda item: item.get('month', ''), reverse=True)
            save_history_index(index)
    except Exception as exc:
        print(f'No se pudo inicializar el historial: {type(exc).__name__}', file=sys.stderr)


def month_directory(month):
    if not valid_month(month):
        return None
    candidate = HISTORY_DIR / month
    return candidate if candidate.is_dir() and (candidate / 'canonical.json').is_file() else None



class Handler(BaseHTTPRequestHandler):
    server_version = 'EMA-Panel/64'

    def log_message(self, fmt, *args):
        return

    def send_bytes(self, data, content_type='application/octet-stream', status=200, filename=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'same-origin')
        self.send_header('X-Frame-Options', 'DENY')
        if filename:
            self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
        self.send_header('Content-Security-Policy', "default-src 'self'; base-uri 'none'; form-action 'self'; object-src 'none'; frame-ancestors 'none'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        try:
            if path == '/api/history':
                seed_current_dataset()
                with DATA_LOCK:
                    index = read_history_index()
                months = [item for item in index['months'] if isinstance(item, dict) and valid_month(item.get('month')) and month_directory(item['month'])]
                dirty = False
                map_regions = [item.get('region') for item in json.loads(LOCATIONS_PATH.read_text(encoding='utf-8')).get('locations', [])]
                for item in months:
                    quality = item.get('quality_report')
                    if isinstance(quality, dict) and isinstance(quality.get('checks'), list):
                        continue
                    month_data = month_directory(item['month'])
                    item['quality_report'] = analyze_dataset(payload(month_data), audit(month_data), map_regions)
                    dirty = True
                if dirty:
                    quality_by_month = {item['month']: item['quality_report'] for item in months}
                    with DATA_LOCK:
                        current_index = read_history_index()
                        for stored in current_index['months']:
                            if isinstance(stored, dict) and stored.get('month') in quality_by_month:
                                stored['quality_report'] = quality_by_month[stored['month']]
                        save_history_index(current_index)
                months.sort(key=lambda item: item['month'], reverse=True)
                return self.send_bytes(json_bytes({'months': months}), 'application/json')
            selected_month = query.get('month', [''])[0]
            selected_dir = DATA
            if selected_month:
                selected_dir = month_directory(selected_month)
                if selected_dir is None:
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'Ese mes no existe en el historial.'}), 'application/json', 404)
            p = payload(selected_dir)
            if path == '/api/health':
                return self.send_bytes(json_bytes({
                    'ok': True, 'version': VERSION, 'can_import': IMPORT_AVAILABLE,
                    'can_manage_database': True, 'database_available': (selected_dir / 'ema.db').is_file(),
                    'source_available': (selected_dir / 'source.xlsx').is_file(),
                    'base_database_available': DB.is_file(), 'base_source_available': (DATA / 'source.xlsx').is_file(),
                    'month': selected_month or None,
                }), 'application/json')
            if path == '/api/summary':
                s = p['summary']
                # adjustment is official total minus route-level facturación.
                route_fact = s['internal_reconciliation']['route_facturacion_sum_gtq']
                s['adjustment_gtq'] = round(s['official_controls']['facturacion_gtq'] - route_fact, 4)
                s['official_controls']['diferencia_gtq'] = round(s['official_controls']['facturacion_gtq'] - s['official_controls']['preventa_gtq'], 4)
                return self.send_bytes(json_bytes(s), 'application/json')
            if path == '/api/rows':
                return self.send_bytes(json_bytes({'rows': p['rows']}), 'application/json')
            if path == '/api/daily':
                daily_totals = p.get('daily_totals')
                if not isinstance(daily_totals, list):
                    grouped = {}
                    for row in p.get('rows', []):
                        day = grouped.setdefault(row['date'], {'date': row['date'], 'preventa_gtq': 0.0, 'facturacion_gtq': 0.0})
                        day['preventa_gtq'] += row['preventa_gtq']
                        day['facturacion_gtq'] += row['facturacion_gtq']
                    daily_totals = []
                    for day in sorted(grouped.values(), key=lambda item: item['date']):
                        day['preventa_gtq'] = round(day['preventa_gtq'], 4)
                        day['facturacion_gtq'] = round(day['facturacion_gtq'], 4)
                        day['diferencia_gtq'] = round(day['facturacion_gtq'] - day['preventa_gtq'], 4)
                        day['cumplimiento_pct'] = round(day['facturacion_gtq'] / day['preventa_gtq'] * 100, 4) if day['preventa_gtq'] else (100.0 if day['facturacion_gtq'] == 0 else None)
                        day['adjustment_gtq'] = 0
                        daily_totals.append(day)
                return self.send_bytes(json_bytes({'daily_totals': daily_totals}), 'application/json')
            if path == '/api/routes':
                routes = {}
                for r in p['rows']:
                    x = routes.setdefault(r['route_id'], {'route_id':r['route_id'],'seller':r['seller'],'region':r['region'],'preventa_gtq':0,'facturacion_gtq':0,'diferencia_gtq':0,'days':0})
                    x['preventa_gtq'] += r['preventa_gtq']; x['facturacion_gtq'] += r['facturacion_gtq']; x['diferencia_gtq'] += r['diferencia_gtq']; x['days'] += 1
                return self.send_bytes(json_bytes({'routes':list(routes.values())}), 'application/json')
            if path == '/api/regions':
                regions = {}
                for r in p['rows']:
                    x = regions.setdefault(r['region'], {'region':r['region'],'preventa_gtq':0,'facturacion_gtq':0,'diferencia_gtq':0})
                    x['preventa_gtq'] += r['preventa_gtq']; x['facturacion_gtq'] += r['facturacion_gtq']; x['diferencia_gtq'] += r['diferencia_gtq']
                return self.send_bytes(json_bytes(sorted(regions.values(), key=lambda x:x['facturacion_gtq'], reverse=True)), 'application/json')
            if path == '/api/audit':
                a = audit(selected_dir); a['official_summary']['adjustment_gtq'] = round(p['summary']['official_controls']['facturacion_gtq'] - p['summary']['internal_reconciliation']['route_facturacion_sum_gtq'],4)
                return self.send_bytes(json_bytes(a), 'application/json')
            if path == '/api/locations':
                return self.send_bytes(LOCATIONS_PATH.read_bytes(), 'application/json; charset=utf-8')
            if path == '/ventas_consolidado_canonical.csv':
                with DATA_LOCK:
                    body = (selected_dir / 'ventas_consolidado_canonical.csv').read_bytes()
                return self.send_bytes(body, 'text/csv; charset=utf-8', filename='ventas_consolidado_canonical.csv')
            if path == '/source.xlsx':
                if not (selected_dir / 'source.xlsx').is_file():
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'No hay un Excel de origen disponible.'}), 'application/json', 404)
                with DATA_LOCK:
                    body = (selected_dir / 'source.xlsx').read_bytes()
                suffix = f'-{selected_month}' if selected_month else ''
                return self.send_bytes(body, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filename=f'EMA-MAYOREO-base{suffix}.xlsx')
            if path == '/': path = '/index.html'
            web_root = WEB.resolve()
            target = (web_root / path.lstrip('/')).resolve()
            if target == web_root or web_root not in target.parents or not target.exists() or not target.is_file():
                return self.send_bytes(b'Not found', 'text/plain; charset=utf-8', 404)
            content_type = mimetypes.guess_type(str(target))[0] or 'application/octet-stream'
            return self.send_bytes(target.read_bytes(), content_type)
        except Exception as exc:
            print(f'GET {path} failed: {exc}', file=sys.stderr)
            return self.send_bytes(json_bytes({'ok':False,'error':f'Error local al consultar {path}: {type(exc).__name__}. Revisa los archivos de datos de EMA.'}), 'application/json', 500)

    def management_request_is_local(self):
        if self.headers.get('X-EMA-Management') != 'ema-panel-management':
            self.send_bytes(json_bytes({'ok': False, 'error': 'Solicitud de gestión no válida.'}), 'application/json', 403)
            return False
        origin = self.headers.get('Origin')
        expected_http = f'http://{self.headers.get("Host", "")}'.rstrip('/')
        expected_https = f'https://{self.headers.get("Host", "")}'.rstrip('/')
        if origin and origin.rstrip('/') not in (expected_http, expected_https, 'https://ema.test'):
            self.send_bytes(json_bytes({'ok': False, 'error': 'La gestión solo se permite desde este panel local.'}), 'application/json', 403)
            return False
        return True

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path not in ('/api/import', '/api/history/import', '/api/history/import-binary'):
            return self.send_bytes(json_bytes({'ok': False, 'error': 'Ruta no disponible.'}), 'application/json', 404)
        requested_month = query.get('month', [''])[0]
        import_mode = query.get('mode', ['add'])[0].strip().lower()
        if import_mode not in ('add', 'replace'):
            return self.send_bytes(json_bytes({'ok': False, 'error': 'Elige agregar un mes nuevo o reemplazar el mes guardado.'}), 'application/json', 400)
        if path in ('/api/history/import', '/api/history/import-binary') and not valid_month(requested_month):
            return self.send_bytes(json_bytes({'ok': False, 'error': 'Selecciona un mes válido antes de cargar el Excel.'}), 'application/json', 400)
        if not IMPORT_AVAILABLE:
            return self.send_bytes(json_bytes({'ok': False, 'error': 'La importación requiere Python 3 y openpyxl. Inicia START.bat con una instalación de Python que tenga openpyxl.'}), 'application/json', 501)
        if self.headers.get('X-EMA-Import') != 'ema-panel-import':
            return self.send_bytes(json_bytes({'ok': False, 'error': 'Solicitud de importación no válida.'}), 'application/json', 403)
        origin = self.headers.get('Origin')
        expected_http = f'http://{self.headers.get("Host", "")}'.rstrip('/')
        expected_https = f'https://{self.headers.get("Host", "")}'.rstrip('/')
        if origin and origin.rstrip('/') not in (expected_http, expected_https, 'https://ema.test'):
            return self.send_bytes(json_bytes({'ok': False, 'error': 'La importación solo se permite desde este panel local.'}), 'application/json', 403)
        binary_upload = path == '/api/history/import-binary'
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            length = 0
        maximum_request_bytes = MAX_IMPORT_BYTES if binary_upload else MAX_IMPORT_BYTES + 64 * 1024
        if length <= 0 or length > maximum_request_bytes:
            return self.send_bytes(json_bytes({'ok': False, 'error': 'El archivo debe medir menos de 30 MB.'}), 'application/json', 413)
        content_type = self.headers.get('Content-Type', '')
        try:
            raw = self.rfile.read(length)
            if binary_upload:
                if content_type.split(';', 1)[0].strip().lower() != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'Selecciona un archivo .xlsx para importar.'}), 'application/json', 400)
                filename = unquote(self.headers.get('X-EMA-Filename', 'archivo.xlsx'), encoding='utf-8', errors='replace')
                filename = Path(filename.replace('\\', '/')).name
                uploaded = raw
            else:
                if not content_type.lower().startswith('multipart/form-data;'):
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'Selecciona un archivo .xlsx para importar.'}), 'application/json', 400)
                message = BytesParser(policy=default).parsebytes(
                    b'MIME-Version: 1.0\r\nContent-Type: ' + content_type.encode('latin-1') + b'\r\n\r\n' + raw
                )
                part = next((item for item in message.iter_parts() if item.get_param('name', header='content-disposition') == 'file'), None)
                if not part or not part.get_filename():
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'Elige el libro Excel que quieres importar.'}), 'application/json', 400)
                filename = Path(part.get_filename().replace('\\', '/')).name
                uploaded = part.get_payload(decode=True) or b''
            if len(uploaded) > MAX_IMPORT_BYTES:
                return self.send_bytes(json_bytes({'ok': False, 'error': 'El Excel pesa más de 30 MB. El nombre del archivo no importa; usa un libro mensual compatible de menor tamaño.'}), 'application/json', 413)
            with zipfile.ZipFile(io.BytesIO(uploaded)) as workbook_zip:
                names = set(workbook_zip.namelist())
                total_unpacked = sum(item.file_size for item in workbook_zip.infolist())
                if 'xl/workbook.xml' not in names or total_unpacked > 250 * 1024 * 1024 or workbook_zip.testzip():
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'El Excel está dañado o no es un libro compatible.'}), 'application/json', 422)
            from openpyxl import load_workbook
            # Validate that bytes really contain an Excel workbook, then let the data processor
            # identify report tabs by their contents instead of hard-coded worksheet titles.
            workbook = load_workbook(io.BytesIO(uploaded), read_only=True, data_only=True)
            has_worksheets = bool(workbook.sheetnames)
            workbook.close()
            if not has_worksheets:
                return self.send_bytes(json_bytes({'ok': False, 'error': 'El libro no contiene hojas de datos.'}), 'application/json', 422)

            import_temp_root = DATA / '.tmp'
            import_temp_root.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryDirectory(prefix='ema-import-', dir=str(import_temp_root)) as temp_name:
                temp_root = Path(temp_name)
                candidate = temp_root / 'source.xlsx'
                generated = temp_root / 'generated'
                candidate.write_bytes(uploaded)
                result = subprocess.run(
                    [sys.executable, str(ROOT / 'tools' / 'rebuild_data.py'), '--source', str(candidate), '--output-dir', str(generated)],
                    cwd=ROOT, capture_output=True, text=True, timeout=180, check=False,
                )
                if result.returncode != 0:
                    detail = next((line[len('ERROR: '):].strip() for line in reversed(result.stderr.splitlines()) if line.startswith('ERROR: ')), '')
                    message = detail or 'No pude identificar el reporte mensual dentro del libro. Revisa que incluya las hojas de ventas diarias y el control oficial con importes.'
                    return self.send_bytes(json_bytes({'ok': False, 'error': message}), 'application/json', 422)
                generated_data = json.loads((generated / 'canonical.json').read_text(encoding='utf-8'))
                generated_regions = {str(row['region']) for row in generated_data.get('rows', [])}
                current_regions = {str(row['region']) for row in json.loads((DATA / 'locations.json').read_text(encoding='utf-8')).get('locations', [])}
                summary = generated_data.get('summary', {})
                amounts = summary.get('official_controls', {})
                if not generated_data.get('rows') or generated_regions != current_regions or any(not math.isfinite(float(amounts.get(key, float('nan')))) for key in ('preventa_gtq', 'facturacion_gtq', 'diferencia_gtq')):
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'El Excel no coincide con las cinco regiones del mapa o no tiene cifras completas.'}), 'application/json', 422)
                period = summary.get('period', {})
                actual_month = str(period.get('start') or '')[:7]
                end_month = str(period.get('end') or '')[:7]
                if not valid_month(actual_month) or actual_month != end_month or any(str(row.get('date', ''))[:7] != actual_month for row in generated_data.get('rows', [])):
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'El Excel debe contener datos de un solo mes calendario para archivarlo correctamente.'}), 'application/json', 422)
                month = requested_month or actual_month
                if month != actual_month:
                    return self.send_bytes(json_bytes({'ok': False, 'error': f'El periodo del Excel es {actual_month}; seleccionaste {month}. Elige el mes que indican las fechas del libro.'}), 'application/json', 422)
                audit_data = json.loads((generated / 'audit.json').read_text(encoding='utf-8'))
                quality = analyze_dataset(generated_data, audit_data, current_regions)
                if quality['status'] != 'verified':
                    findings = ', '.join(quality.get('findings', []))
                    return self.send_bytes(json_bytes({'ok': False, 'error': f"El asistente de calidad detectó inconsistencias: {findings}. No guardé el archivo."}), 'application/json', 422)
                HISTORY_DIR.mkdir(parents=True, exist_ok=True)
                target = HISTORY_DIR / month
                with DATA_LOCK:
                    index = read_history_index()
                    existing = target.exists() or any(item.get('month') == month for item in index['months'])
                    if import_mode == 'add' and existing:
                        return self.send_bytes(json_bytes({'ok': False, 'error': f'El mes {month} ya tiene datos. Elige “Reemplazar el mes guardado” si necesitas actualizarlo; no se modificó ningún archivo.'}), 'application/json', 409)
                    if import_mode == 'replace' and not existing:
                        return self.send_bytes(json_bytes({'ok': False, 'error': f'El mes {month} todavía no está guardado. Elige “Agregar como mes nuevo”.'}), 'application/json', 404)
                    staging = Path(tempfile.mkdtemp(prefix=f'.{month}.upload-', dir=HISTORY_DIR))
                    backup = HISTORY_DIR / f'.{month}.backup-{uuid.uuid4().hex}'
                    target_was_moved = False
                    try:
                        (staging / 'source.xlsx').write_bytes(uploaded)
                        for name in HISTORY_FILES[1:]:
                            (staging / name).write_bytes((generated / name).read_bytes())
                        if target.exists():
                            os.replace(target, backup)
                            target_was_moved = True
                        os.replace(staging, target)
                        entry = archive_metadata(month, target, filename=filename)
                        index['months'] = [item for item in index['months'] if item.get('month') != month]
                        index['months'].append(entry)
                        index['months'].sort(key=lambda item: item.get('month', ''), reverse=True)
                        save_history_index(index)
                    except Exception:
                        import shutil
                        shutil.rmtree(staging, ignore_errors=True)
                        if target.exists() and target_was_moved:
                            shutil.rmtree(target, ignore_errors=True)
                        if target_was_moved and backup.exists():
                            os.replace(backup, target)
                        raise
                    else:
                        if backup.exists():
                            import shutil
                            shutil.rmtree(backup, ignore_errors=True)
            return self.send_bytes(json_bytes({'ok': True, 'mode': import_mode, 'filename': filename, 'month': month, 'routes': summary['counts']['routes'], 'rows': summary['counts']['official_rows'], 'official_controls': summary.get('official_controls', {}), 'quality_report': quality}), 'application/json')
        except Exception as exc:
            print(f'POST {path} import failed: {type(exc).__name__}: {exc}', file=sys.stderr)
            return self.send_bytes(json_bytes({'ok': False, 'error': 'El archivo no se pudo validar. Conservé los datos actuales.'}), 'application/json', 422)

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path not in ('/api/database', '/api/history'):
            return self.send_bytes(json_bytes({'ok': False, 'error': 'Ruta no disponible.'}), 'application/json', 404)
        if not self.management_request_is_local():
            return
        try:
            if path == '/api/history':
                month = query.get('month', [''])[0]
                if not valid_month(month):
                    return self.send_bytes(json_bytes({'ok': False, 'error': 'Selecciona un mes válido para eliminar.'}), 'application/json', 400)
                HISTORY_DIR.mkdir(parents=True, exist_ok=True)
                target = HISTORY_DIR / month
                tombstone = HISTORY_DIR / f'.{month}.deleting-{uuid.uuid4().hex}'
                with DATA_LOCK:
                    index = read_history_index()
                    exists_in_index = any(item.get('month') == month for item in index['months'])
                    if not target.is_dir() and not exists_in_index:
                        return self.send_bytes(json_bytes({'ok': False, 'error': f'El mes {month} no existe en el historial.'}), 'application/json', 404)
                    # If this archive mirrors the active base period, clear that duplicate too.
                    active_month = ''
                    try:
                        active_payload = json.loads(JSON_PATH.read_text(encoding='utf-8'))
                        active_month = str(active_payload.get('summary', {}).get('period', {}).get('start') or '')[:7]
                    except (OSError, ValueError, TypeError):
                        pass
                    clear_active = active_month == month
                    moved = False
                    updated_index = {**index, 'months': [item for item in index['months'] if item.get('month') != month]}
                    try:
                        if target.exists():
                            os.replace(target, tombstone)
                            moved = True
                        save_history_index(updated_index)
                        if clear_active:
                            empty = empty_dataset()
                            atomic_update({
                                'canonical.json': json_bytes(empty),
                                'audit.json': json_bytes(empty_audit()),
                                'ventas_consolidado_canonical.csv': csv_bytes([]),
                            }, remove=('ema.db', 'source.xlsx'))
                    except Exception:
                        try:
                            save_history_index(index)
                        except Exception:
                            pass
                        if moved and tombstone.exists():
                            os.replace(tombstone, target)
                        raise
                    if tombstone.exists():
                        shutil.rmtree(tombstone, ignore_errors=True)
                return self.send_bytes(json_bytes({'ok': True, 'deleted': True, 'month': month, 'active_data_cleared': clear_active}), 'application/json')

            scope = query.get('scope', ['active'])[0].strip().lower()
            empty = empty_dataset()
            staged = {
                'canonical.json': json_bytes(empty),
                'audit.json': json_bytes(empty_audit()),
                'ventas_consolidado_canonical.csv': csv_bytes([]),
            }
            if scope == 'all':
                # Move the archive out of the way first. If clearing the active base fails, restore it.
                history_backup = DATA / f'.history-reset-{uuid.uuid4().hex}'
                moved_history = False
                with DATA_LOCK:
                    try:
                        if HISTORY_DIR.exists():
                            os.replace(HISTORY_DIR, history_backup)
                            moved_history = True
                        HISTORY_DIR.mkdir(parents=True, exist_ok=True)
                        save_history_index({'months': []})
                        atomic_update(staged, remove=('ema.db', 'source.xlsx'))
                    except Exception:
                        if HISTORY_DIR.exists():
                            shutil.rmtree(HISTORY_DIR, ignore_errors=True)
                        if moved_history and history_backup.exists():
                            os.replace(history_backup, HISTORY_DIR)
                        raise
                    else:
                        if history_backup.exists():
                            shutil.rmtree(history_backup, ignore_errors=True)
                return self.send_bytes(json_bytes({'ok': True, 'deleted': True, 'scope': 'all', 'months_deleted': True}), 'application/json')
            atomic_update(staged, remove=('ema.db', 'source.xlsx'))
            return self.send_bytes(json_bytes({'ok': True, 'deleted': True, 'scope': 'active'}), 'application/json')
        except Exception as exc:
            print(f'DELETE {path} failed: {type(exc).__name__}: {exc}', file=sys.stderr)
            return self.send_bytes(json_bytes({'ok': False, 'error': 'No se pudo completar el borrado. Revisa los permisos; los datos existentes se conservaron cuando fue posible.'}), 'application/json', 500)

class _MemoryBuffer(io.BytesIO):
    """Flujo en memoria cuyo contenido se puede leer después del cierre HTTP."""

    def close(self):
        self.flush()


class _MemoryConnection:
    """Socket falso para reutilizar las rutas actuales sin abrir ningún puerto."""

    def __init__(self, request_bytes):
        self.input = _MemoryBuffer(request_bytes)
        self.output = _MemoryBuffer()

    def makefile(self, mode, *args, **kwargs):
        return self.input if 'r' in mode else self.output

    def sendall(self, content):
        self.output.write(content)


def dispatch_request(request):
    """Ejecuta una petición de API en memoria y devuelve una respuesta JSON."""
    method = str(request.get('method', 'GET')).upper()
    target = str(request.get('url', '/'))
    if not target.startswith('/') or any(char in target for char in '\r\n'):
        raise ValueError('Ruta local no válida.')
    try:
        body = base64.b64decode(request.get('body', ''), validate=True)
    except (ValueError, TypeError):
        raise ValueError('El cuerpo de la solicitud no es válido.')
    request_path = urlparse(target).path
    maximum_request_bytes = MAX_IMPORT_BYTES + 64 * 1024 if request_path == '/api/history/import' else MAX_IMPORT_BYTES
    if len(body) > maximum_request_bytes:
        return {'status': 413, 'reason': 'Payload Too Large', 'headers': {'Content-Type': 'application/json'}, 'body': base64.b64encode(json_bytes({'ok': False, 'error': 'El archivo debe medir menos de 30 MB.'})).decode('ascii')}

    headers = {
        'Host': 'ema.test',
        'Origin': str(request.get('origin', 'https://ema.test')),
        'Connection': 'close',
        'Content-Length': str(len(body)),
    }
    content_type = str(request.get('content_type', ''))
    management_token = str(request.get('management_token', ''))
    import_token = str(request.get('import_token', ''))
    if content_type:
        headers['Content-Type'] = content_type
    if management_token:
        headers['X-EMA-Management'] = management_token
    if import_token:
        headers['X-EMA-Import'] = import_token
    filename = request.get('filename')
    if filename:
        safe_filename = quote(str(filename), safe='')
        if len(safe_filename) > 1024:
            raise ValueError('Nombre del archivo demasiado largo.')
        headers['X-EMA-Filename'] = safe_filename

    request_line = f'{method} {target} HTTP/1.1\r\n'.encode('ascii')
    header_block = b''.join(f'{name}: {value}\r\n'.encode('latin-1') for name, value in headers.items())
    connection = _MemoryConnection(request_line + header_block + b'\r\n' + body)

    class MemoryHandler(Handler):
        """Adaptador que entrega el formato HTTP directamente a la lógica existente."""
        wbufsize = -1

    MemoryHandler(connection, ('127.0.0.1', 0), object())
    raw_response = connection.output.getvalue()
    head, separator, response_body = raw_response.partition(b'\r\n\r\n')
    if not separator:
        raise RuntimeError('El procesador local devolvió una respuesta incompleta.')
    lines = head.decode('latin-1').split('\r\n')
    status_parts = lines[0].split(' ', 2)
    status = int(status_parts[1])
    reason = status_parts[2] if len(status_parts) > 2 else 'OK'
    response_headers = {}
    for line in lines[1:]:
        name, colon, value = line.partition(':')
        if colon and name.lower() in ('content-type', 'content-disposition', 'x-content-type-options', 'referrer-policy', 'x-frame-options', 'content-security-policy'):
            response_headers[name] = value.strip()
    return {
        'status': status,
        'reason': reason,
        'headers': response_headers,
        'body': base64.b64encode(response_body).decode('ascii'),
    }


def run_bridge():
    """Procesa JSON por stdin/stdout; no abre un servidor ni escucha en red."""
    for line in sys.stdin:
        try:
            request = json.loads(line)
            response = dispatch_request(request)
        except Exception as exc:
            print(f'Error del puente local: {type(exc).__name__}: {exc}', file=sys.stderr, flush=True)
            response = {
                'status': 500,
                'reason': 'Internal Server Error',
                'headers': {'Content-Type': 'application/json; charset=utf-8'},
                'body': base64.b64encode(json_bytes({'ok': False, 'error': 'No se pudo procesar la solicitud local.'})).decode('ascii'),
            }
        print(json.dumps(response, ensure_ascii=False, separators=(',', ':')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['--bridge']:
        run_bridge()
        raise SystemExit(0)
    print('EMA MAYOREO ya no inicia un servidor web. Abre la aplicación de Windows.', file=sys.stderr)
    raise SystemExit(2)

from __future__ import annotations

import sys
import zipfile
from pathlib import Path, PurePosixPath

ARCHIVE = Path("EMA_MAYOREO_WEB_DEPLOY_SEGURO.zip")
DEST = Path(".deploy_src")
REQUIRED = (
    "web_server.py", "data_engine.py", "VERSION.txt", "requirements.txt",
    "web/index.html", "web/app.js", "data/canonical.json", "data/audit.json",
    "data/locations.json", "data/ventas_consolidado_canonical.csv",
)
FORBIDDEN_SUFFIXES = {".xlsx", ".db", ".sqlite", ".sqlite3", ".pyc", ".pyo"}


def main() -> int:
    if not ARCHIVE.is_file():
        print(f"No se encontró {ARCHIVE} en la raíz del repositorio.", file=sys.stderr)
        return 2
    try:
        with zipfile.ZipFile(ARCHIVE) as archive:
            members = archive.infolist()
            for member in members:
                name = member.filename
                path = PurePosixPath(name)
                if path.is_absolute() or ".." in path.parts or "\\" in name:
                    raise ValueError(f"Ruta insegura dentro del ZIP: {name}")
                if any(part.lower() in {"runtime", "__pycache__"} for part in path.parts):
                    raise ValueError(f"El ZIP incluye archivos prohibidos: {name}")
                if Path(name).suffix.lower() in FORBIDDEN_SUFFIXES:
                    raise ValueError(f"El ZIP incluye datos/binarios no permitidos: {name}")
            if DEST.exists():
                import shutil
                shutil.rmtree(DEST)
            DEST.mkdir(parents=True, exist_ok=True)
            archive.extractall(DEST)
        missing = [name for name in REQUIRED if not (DEST / name).is_file()]
        if missing:
            raise ValueError("Faltan archivos requeridos: " + ", ".join(missing))
        print(f"Paquete EMA verificado: {len(members)} archivos listos.")
        return 0
    except (OSError, zipfile.BadZipFile, ValueError) as exc:
        print(f"No se pudo preparar EMA: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

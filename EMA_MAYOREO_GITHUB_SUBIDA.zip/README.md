# EMA MAYOREO WEB — subida a GitHub y despliegue en Render

Este paquete contiene los archivos de raíz que necesita el repositorio y un ZIP limpio de la aplicación. La aplicación se preparó con **datos iniciales vacíos**, autenticación y almacenamiento persistente; el histórico y el Excel originales del paquete personal no se incluyen.

## 1. Subir a GitHub

1. Abre https://github.com/danielosabas21-lab/gestiondeventas
2. Extrae este ZIP en tu computadora.
3. En GitHub, pulsa **Add file → Upload files** y arrastra los seis archivos de este paquete (el archivo `EMA_MAYOREO_WEB_DEPLOY_SEGURO.zip`, `README.md`, `.gitignore`, `prepare_app.py`, `init_persistent_data.py` y `render.yaml`).
4. Pulsa **Commit changes**.

No subas el Excel original ni la carpeta `data` con tus ventas reales a un repositorio público.

## 2. Crear la URL pública

1. Inicia sesión en https://dashboard.render.com/ con tu cuenta.
2. Conecta tu GitHub si Render te lo pide.
3. Selecciona **New → Blueprint** y elige `danielosabas21-lab/gestiondeventas`.
4. Render detectará `render.yaml`. Revisa los recursos y el costo antes de confirmar.
5. Espera que el primer deploy termine en estado **Live**. Render asigna entonces la URL `https://ema-mayoreo-web.onrender.com` o un nombre disponible similar; copia la URL exacta que aparezca en Render.
6. Abre **Environment** del servicio y copia el valor generado de `EMA_ACCESS_PASSWORD`. El usuario configurado por este archivo es `ema-admin`. No compartas esas credenciales públicamente.

El panel está protegido con contraseña. El endpoint `/api/health` se deja sin autenticación para que Render pueda comprobar que el servidor vive; solo devuelve estado técnico, no el contenido de ventas.

## Aviso de costos

El Blueprint configura un servicio de cómputo `starter` y un disco persistente de 1 GB. Render cobra los recursos según su precio vigente; revisa el costo mostrado antes de crear el servicio. El disco es necesario para que los Excel e historiales importados no desaparezcan al reiniciar.

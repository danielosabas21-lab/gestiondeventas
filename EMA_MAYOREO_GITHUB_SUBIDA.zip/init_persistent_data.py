from __future__ import annotations

import os
import shutil
from pathlib import Path

SEED = Path(".deploy_src") / "data"
DATA = Path(os.environ.get("EMA_DATA_DIR", "/var/data")).expanduser().resolve()
FILES = (
    "canonical.json",
    "audit.json",
    "locations.json",
    "ventas_consolidado_canonical.csv",
)


def main() -> int:
    DATA.mkdir(parents=True, exist_ok=True)
    for name in FILES:
        target = DATA / name
        source = SEED / name
        if not target.exists() and source.is_file():
            shutil.copy2(source, target)
    history = DATA / "history"
    history.mkdir(parents=True, exist_ok=True)
    index = history / "index.json"
    seed_index = SEED / "history" / "index.json"
    if not index.exists():
        if seed_index.is_file():
            shutil.copy2(seed_index, index)
        else:
            index.write_text('{"months": []}\n', encoding="utf-8")
    print(f"Datos persistentes inicializados en {DATA}; los datos existentes no se sobrescribieron.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

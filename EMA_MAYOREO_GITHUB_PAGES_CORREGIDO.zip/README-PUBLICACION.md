# EMA MAYOREO WEB — GitHub Pages corregido

Este paquete corrige el 404 de GitHub Pages: `index.html` y sus recursos quedan en la raíz del sitio del repositorio.

## Publicar
1. En el repositorio `danielosabas21-lab/gestiondeventas`, elimina o mueve el ZIP anterior si está en la raíz.
2. Extrae este ZIP en tu computadora.
3. Sube **todos los archivos y carpetas que están dentro** del ZIP a la raíz del repositorio (no subas solo el ZIP).
4. En GitHub: **Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save**.
5. Espera a que el despliegue termine y vuelve a abrir `https://danielosabas21-lab.github.io/gestiondeventas/`.

## Importante sobre el funcionamiento
GitHub Pages solo aloja archivos estáticos. La interfaz original consulta rutas `/api/...` para leer y guardar pedidos, importar Excel e historial. Esas funciones requieren desplegar el backend Python por separado (por ejemplo en Render) y configurar la interfaz para usar la URL del backend. Este paquete arregla la estructura del sitio estático, pero **no convierte GitHub Pages en un servidor Python ni activa por sí solo las funciones de base de datos/importación**. No incluye la base de datos ni el Excel de ventas.
